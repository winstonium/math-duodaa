-- phpMyAdmin SQL Dump
-- version 2.9.0
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2007 年 02 月 02 日 01:31
-- 服务器版本: 5.0.21
-- PHP 版本: 5.1.6
-- 
-- 数据库: 'supesite'
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_ads'
-- 

DROP TABLE IF EXISTS supe_ads;
CREATE TABLE supe_ads (
  adid smallint(6) unsigned NOT NULL auto_increment,
  available tinyint(1) NOT NULL default '1',
  displayorder tinyint(3) NOT NULL default '0',
  title varchar(50) NOT NULL default '',
  adtype enum('echo','js','iframe','text','code','image','flash') NOT NULL default 'text',
  pagetype varchar(20) NOT NULL default '',
  `type` mediumtext NOT NULL default '',
  parameters mediumtext NOT NULL,
  system tinyint(1) NOT NULL default '0',
  style varchar(30) NOT NULL default '',
  PRIMARY KEY  (adid),
  KEY system (system)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_announcements'
-- 

DROP TABLE IF EXISTS supe_announcements;
CREATE TABLE supe_announcements (
  id smallint(6) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  `subject` varchar(80) NOT NULL default '',
  displayorder tinyint(3) unsigned NOT NULL default '0',
  starttime int(10) unsigned NOT NULL default '0',
  endtime int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (id),
  KEY timespan (starttime,endtime)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_attachments'
-- 

DROP TABLE IF EXISTS supe_attachments;
CREATE TABLE supe_attachments (
  aid mediumint(8) unsigned NOT NULL auto_increment,
  isavailable tinyint(1) NOT NULL default '0',
  `type` char(20) NOT NULL default '',
  itemid mediumint(8) unsigned NOT NULL default '0',
  catid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  filename char(150) NOT NULL default '',
  `subject` char(80) NOT NULL default '',
  attachtype char(10) NOT NULL default '',
  isimage tinyint(1) NOT NULL default '0',
  size int(10) unsigned NOT NULL default '0',
  filepath char(200) NOT NULL default '',
  thumbpath char(200) NOT NULL default '',
  downloads mediumint(8) unsigned NOT NULL default '0',
  `hash` char(16) NOT NULL default '',
  PRIMARY KEY  (aid),
  KEY `hash` (`hash`),
  KEY itemid (itemid),
  KEY uid (uid,`type`,dateline),
  KEY `type` (`type`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_attachmenttypes'
-- 

DROP TABLE IF EXISTS supe_attachmenttypes;
CREATE TABLE supe_attachmenttypes (
  id smallint(6) unsigned NOT NULL auto_increment,
  fileext char(10) NOT NULL default '',
  maxsize int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_blocks'
-- 

DROP TABLE IF EXISTS supe_blocks;
CREATE TABLE supe_blocks (
  blockid smallint(6) unsigned NOT NULL auto_increment,
  dateline int(10) unsigned NOT NULL default '0',
  blocktype varchar(20) NOT NULL default '',
  blockname varchar(80) NOT NULL default '',
  blockmodel tinyint(1) NOT NULL default '1',
  blocktext text NOT NULL,
  blockcode text NOT NULL,
  PRIMARY KEY  (blockid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_cache'
-- 

DROP TABLE IF EXISTS supe_cache;
CREATE TABLE supe_cache (
  cachekey varchar(16) NOT NULL default '',
  uid mediumint(8) unsigned NOT NULL default '0',
  cachename varchar(20) NOT NULL default '',
  `value` mediumtext NOT NULL,
  updatetime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (cachekey)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_categories'
-- 

DROP TABLE IF EXISTS supe_categories;
CREATE TABLE supe_categories (
  catid smallint(6) unsigned NOT NULL auto_increment,
  upid smallint(6) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  note text NOT NULL,
  `type` varchar(15) NOT NULL default '',
  ischannel tinyint(1) NOT NULL default '0',
  displayorder mediumint(6) unsigned NOT NULL default '0',
  tpl varchar(80) NOT NULL default '',
  viewtpl varchar(80) NOT NULL default '',
  thumb varchar(150) NOT NULL default '',
  image varchar(150) NOT NULL default '',
  haveattach tinyint(1) NOT NULL default '0',
  bbsmodel tinyint(1) NOT NULL default '0',
  bbsurltype varchar(15) NOT NULL default '',
  blockmodel tinyint(1) NOT NULL default '1',
  blockparameter text NOT NULL,
  blocktext text NOT NULL,
  url varchar(255) NOT NULL default '',
  subcatid text NOT NULL,
  PRIMARY KEY  (catid),
  KEY `type` (`type`),
  KEY upid (upid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_channels'
-- 

DROP TABLE IF EXISTS supe_channels;
CREATE TABLE supe_channels (
  nameid char(30) NOT NULL default '',
  `name` char(50) NOT NULL default '',
  url char(200) NOT NULL default '',
  tpl char(50) NOT NULL default '',
  `type` char(20) NOT NULL default '',
  displayorder smallint(3) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (nameid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_corpus'
-- 

DROP TABLE IF EXISTS supe_corpus;
CREATE TABLE supe_corpus (
  cid mediumint(8) unsigned NOT NULL auto_increment,
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  corpusname varchar(100) NOT NULL default '',
  `resume` text NOT NULL,
  background varchar(15) NOT NULL default '',
  blogs text NOT NULL,
  catalog text NOT NULL,
  cover text NOT NULL,
  prelude text NOT NULL,
  backcover text NOT NULL,
  createdate int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (cid),
  KEY authorid (authorid,createdate)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_crons'
-- 

DROP TABLE IF EXISTS supe_crons;
CREATE TABLE supe_crons (
  cronid smallint(6) unsigned NOT NULL auto_increment,
  available tinyint(1) NOT NULL default '0',
  `type` enum('user','system') NOT NULL default 'user',
  `name` char(50) NOT NULL default '',
  filename char(50) NOT NULL default '',
  lastrun int(10) unsigned NOT NULL default '0',
  nextrun int(10) unsigned NOT NULL default '0',
  weekday tinyint(1) NOT NULL default '0',
  `day` tinyint(2) NOT NULL default '0',
  `hour` tinyint(2) NOT NULL default '0',
  `minute` char(36) NOT NULL default '',
  PRIMARY KEY  (cronid),
  KEY nextrun (available,nextrun)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_customfields'
-- 

DROP TABLE IF EXISTS supe_customfields;
CREATE TABLE supe_customfields (
  customfieldid smallint(6) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  `type` varchar(10) NOT NULL default '',
  `name` varchar(80) NOT NULL default '',
  displayorder smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  isdefault tinyint(1) NOT NULL default '0',
  isshare tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (customfieldid),
  KEY uid (uid,`type`),
  KEY isshare (isshare,`type`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_effects'
-- 

DROP TABLE IF EXISTS supe_effects;
CREATE TABLE supe_effects (
  eid smallint(6) unsigned NOT NULL auto_increment,
  `name` char(50) NOT NULL default '',
  `file` char(200) NOT NULL default '',
  PRIMARY KEY  (eid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_favorites'
-- 

DROP TABLE IF EXISTS supe_favorites;
CREATE TABLE supe_favorites (
  uid mediumint(8) unsigned NOT NULL default '0',
  itemid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid,itemid),
  KEY uid (uid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_friends'
-- 

DROP TABLE IF EXISTS supe_friends;
CREATE TABLE supe_friends (
  uid mediumint(8) unsigned NOT NULL default '0',
  frienduid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  grade tinyint(2) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid,frienduid),
  KEY uid (uid,dateline),
  KEY frienduid (frienduid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_friendlinks'
-- 

DROP TABLE IF EXISTS supe_friendlinks;
CREATE TABLE supe_friendlinks (
    id smallint(6) unsigned NOT NULL auto_increment,
    displayorder tinyint(3) NOT NULL default '0',  
    name varchar(100) NOT NULL default '',     
    url varchar(100) NOT NULL default '',            
    description varchar(100) NOT NULL default '',       
    logo varchar(100) NOT NULL default '',
	PRIMARY KEY  (id)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_goodsprice'
-- 

DROP TABLE IF EXISTS supe_goodsprice;
CREATE TABLE supe_goodsprice (
  priceid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  price float unsigned NOT NULL default '0',
  buynum smallint(6) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  username char(15) NOT NULL default '',
  PRIMARY KEY  (priceid),
  KEY itemid (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_groupfields'
-- 

DROP TABLE IF EXISTS supe_groupfields;
CREATE TABLE supe_groupfields (
  gid mediumint(8) unsigned NOT NULL default '0',
  intro mediumtext NOT NULL,
  announcements mediumtext NOT NULL,
  headerimage varchar(150) NOT NULL default '',
  selfintro mediumtext NOT NULL,
  css mediumtext NOT NULL,
  guide mediumtext NOT NULL,
  PRIMARY KEY  (gid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_groupitems'
-- 

DROP TABLE IF EXISTS supe_groupitems;
CREATE TABLE supe_groupitems (
  gid mediumint(8) unsigned NOT NULL default '0',
  itemid mediumint(8) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (gid,itemid),
  KEY gid (gid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_groups'
-- 

DROP TABLE IF EXISTS supe_groups;
CREATE TABLE supe_groups (
  gid mediumint(8) unsigned NOT NULL auto_increment,
  groupname char(50) NOT NULL default '',
  catid mediumint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  ispublic tinyint(1) NOT NULL default '1',
  flag tinyint(1) NOT NULL default '0',
  `mode` tinyint(1) NOT NULL default '2',
  allowrecommend tinyint(1) NOT NULL default '1',
  allowshare tinyint(1) NOT NULL default '1',
  usernum mediumint(8) NOT NULL default '0',
  `password` char(32) NOT NULL default '',
  logo char(50) NOT NULL default '',
  sharecss tinyint(1) NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (gid),
  KEY catid (catid,flag,lastpost),
  KEY uid (uid),
  KEY sharecss (sharecss,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_groupuid'
-- 

DROP TABLE IF EXISTS supe_groupuid;
CREATE TABLE supe_groupuid (
  uid mediumint(8) unsigned NOT NULL default '0',
  gid mediumint(8) unsigned NOT NULL default '0',
  groupname char(50) NOT NULL default '',
  flag tinyint(1) NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (gid,uid),
  KEY uid (uid,flag,dateline),
  KEY gid (gid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_guestbooks'
-- 

DROP TABLE IF EXISTS supe_guestbooks;
CREATE TABLE supe_guestbooks (
  gid mediumint(8) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  isprivate tinyint(1) NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (gid),
  KEY uid (uid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_groupinvite'
-- 

DROP TABLE IF EXISTS supe_groupinvite;
CREATE TABLE supe_groupinvite (
  gid mediumint(8) unsigned NOT NULL default '0',
  fromid mediumint(8) unsigned NOT NULL default '0',
  fromusername char(15) NOT NULL default '',
  toid mediumint(8) unsigned NOT NULL default '0',
  tousername char(15) NOT NULL default '',
  flag tinyint(1) NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  confirmtime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (gid,toid),
  KEY toid (toid,dateline)
) TYPE=MyISAM;


-- --------------------------------------------------------

-- 
-- 表的结构 'supe_itemtypes'
-- 

DROP TABLE IF EXISTS supe_itemtypes;
CREATE TABLE supe_itemtypes (
  typeid mediumint(8) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  `type` char(10) NOT NULL default '',
  typename char(50) NOT NULL default '',
  viewperm char(15) NOT NULL default '',
  replyperm char(15) NOT NULL default '',
  getattachperm char(15) NOT NULL default '',
  displayorder tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (typeid),
  KEY uid (uid,`type`,displayorder)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_members'
-- 

DROP TABLE IF EXISTS supe_members;
CREATE TABLE supe_members (
  uid mediumint(8) unsigned NOT NULL default '0',
  groupid smallint(6) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  `password` char(32) NOT NULL default '',
  secques char(8) NOT NULL default '',
  timeoffset char(4) NOT NULL default '',
  dateformat char(10) NOT NULL default '',
  timeformat tinyint(1) NOT NULL default '0',
  havespace tinyint(1) NOT NULL default '0',
  newpm tinyint(1) NOT NULL default '0',
  lastsearchtime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_modelcolumns'
-- 

DROP TABLE IF EXISTS supe_modelcolumns;
CREATE TABLE supe_modelcolumns (
  id smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  upid smallint(6) unsigned NOT NULL DEFAULT '0',
  mid smallint(6) unsigned NOT NULL DEFAULT '0',
  fieldname varchar(30) NOT NULL DEFAULT '',
  fieldcomment varchar(60) NOT NULL DEFAULT '',
  fieldtype varchar(20) NOT NULL DEFAULT '',
  fieldlength int(5) unsigned NOT NULL DEFAULT '0',
  fielddefault text NOT NULL,
  formtype varchar(20) NOT NULL DEFAULT '',
  fielddata text NOT NULL,
  displayorder tinyint(2) unsigned NOT NULL DEFAULT '0',
  allowindex tinyint(1) NOT NULL DEFAULT '0',
  allowshow tinyint(1) NOT NULL DEFAULT '0',
  allowlist tinyint(1) NOT NULL DEFAULT '0',
  allowsearch tinyint(1) NOT NULL DEFAULT '0',
  allowpost tinyint(1) NOT NULL DEFAULT '0',
  isfixed tinyint(1) NOT NULL DEFAULT '0',
  isbbcode tinyint(1) NOT NULL DEFAULT '0',
  ishtml tinyint(1) NOT NULL DEFAULT '0',
  isrequired tinyint(1) NOT NULL DEFAULT '0',
  isfile varchar(50) NOT NULL DEFAULT '',
  isimage varchar(50) NOT NULL DEFAULT '',
  isflash varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (id),
  KEY mid (mid,displayorder)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_modelinterval'
-- 

DROP TABLE IF EXISTS supe_modelinterval;
CREATE TABLE supe_modelinterval (
  uid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  `type` tinyint(1) unsigned NOT NULL default '0',
  KEY uid (uid,`type`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_modelperm'
-- 

DROP TABLE IF EXISTS supe_modelperm;
CREATE TABLE supe_modelperm (
  mid smallint(6) unsigned NOT NULL DEFAULT '0',
  uid mediumint(8) unsigned NOT NULL DEFAULT '0',
  flag tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (mid,uid)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_models'
-- 

DROP TABLE IF EXISTS supe_models;
CREATE TABLE supe_models (
  mid smallint(6) unsigned NOT NULL auto_increment,
  modelname char(20) NOT NULL default '',
  modelalias char(60) NOT NULL default '',
  allowpost tinyint(1) NOT NULL default '0',
  allowguest tinyint(1) NOT NULL default '0',
  allowgrade tinyint(1) NOT NULL default '0',
  allowcomment tinyint(1) NOT NULL default '0',
  allowrate tinyint(1) NOT NULL default '0',
  allowguestsearch tinyint(1) NOT NULL default '0',
  allowfeed tinyint(1) NOT NULL default '1',
  searchinterval smallint(6) unsigned NOT NULL default '0',
  allowguestdownload tinyint(1) NOT NULL default '0',
  downloadinterval smallint(6) unsigned NOT NULL default '0',
  allowfilter tinyint(1) NOT NULL default '0',
  listperpage tinyint(3) unsigned NOT NULL default '0',
  seokeywords char(200) NOT NULL default '',
  seodescription char(200) NOT NULL default '',
  thumbsize char(19) NOT NULL default '',
  tpl char(20) NOT NULL default '',
  fielddefault char(255) NOT NULL default '',
  PRIMARY KEY  (mid)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_polls'
-- 

DROP TABLE IF EXISTS supe_polls;
CREATE TABLE supe_polls (
  pollid smallint(6) unsigned NOT NULL auto_increment,
  pollnum mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  updatetime int(10) unsigned NOT NULL default '0',
  ismulti tinyint(1) NOT NULL default '0',
  `subject` varchar(80) NOT NULL default '',
  summary text NOT NULL,
  options text NOT NULL,
  voters text NOT NULL,
  PRIMARY KEY  (pollid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_prefields'
-- 

DROP TABLE IF EXISTS supe_prefields;
CREATE TABLE supe_prefields (
  id smallint(6) unsigned NOT NULL auto_increment,
  `type` char(10) NOT NULL default '',
  field char(20) NOT NULL default '',
  `value` char(50) NOT NULL default '',
  isdefault tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY `type` (`type`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_reports'
-- 

DROP TABLE IF EXISTS supe_reports;
CREATE TABLE supe_reports (
  reportid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  reportuid mediumint(8) unsigned NOT NULL default '0',
  reporter char(15) NOT NULL default '',
  reportdate int(10) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (reportid),
  KEY itemid (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_robotitems'
-- 

DROP TABLE IF EXISTS supe_robotitems;
CREATE TABLE supe_robotitems (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  catid smallint(6) unsigned NOT NULL default '0',
  robotid smallint(6) unsigned NOT NULL default '0',
  robottime int(10) unsigned NOT NULL default '0',
  `subject` char(80) NOT NULL default '',
  author char(35) NOT NULL default '',
  itemfrom char(50) NOT NULL default '',
  dateline char(50) NOT NULL default '',
  isimport tinyint(1) NOT NULL default '0',
  haveattach tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (itemid),
  KEY robotid (robotid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_robotmessages'
-- 

DROP TABLE IF EXISTS supe_robotmessages;
CREATE TABLE supe_robotmessages (
  msgid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  robotid smallint(6) unsigned NOT NULL default '0',
  message text NOT NULL,
  picurls text NOT NULL,
  flashurls text NOT NULL,
  PRIMARY KEY  (msgid),
  KEY itemid (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_robots'
-- 

DROP TABLE IF EXISTS supe_robots;
CREATE TABLE supe_robots (
  robotid smallint(6) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  uid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  lasttime int(10) unsigned NOT NULL default '0',
  importcatid smallint(6) unsigned NOT NULL default '0',
  robotnum smallint(6) unsigned NOT NULL default '0',
  listurltype varchar(10) NOT NULL default '',
  listurl text NOT NULL,
  listpagestart smallint(6) unsigned NOT NULL default '0',
  listpageend smallint(6) unsigned NOT NULL default '0',
  reverseorder tinyint(1) NOT NULL default '1',
  allnum smallint(6) unsigned NOT NULL default '0',
  pernum smallint(6) unsigned NOT NULL default '0',
  savepic tinyint(1) NOT NULL default '0',
  encode varchar(20) NOT NULL default '',
  picurllinkpre text NOT NULL,
  saveflash tinyint(1) NOT NULL default '0',
  subjecturlrule text NOT NULL,
  subjecturllinkrule text NOT NULL,
  subjecturllinkpre text NOT NULL,
  subjectrule text NOT NULL,
  subjectfilter text NOT NULL,
  subjectreplace text NOT NULL,
  subjectreplaceto text NOT NULL,
  subjectkey text NOT NULL,
  subjectallowrepeat tinyint(1) NOT NULL default '0',
  datelinerule text NOT NULL,
  fromrule text NOT NULL,
  authorrule text NOT NULL,
  messagerule text NOT NULL,
  messagefilter text NOT NULL,
  messagepagetype varchar(10) NOT NULL default '',
  messagepagerule text NOT NULL,
  messagepageurlrule text NOT NULL,
  messagepageurllinkpre text NOT NULL,
  messagereplace text NOT NULL,
  messagereplaceto text NOT NULL,
  autotype tinyint(1) NOT NULL default '0',
  wildcardlen tinyint(1) NOT NULL default '0',
  subjecturllinkcancel text NOT NULL,
  subjecturllinkfilter text NOT NULL,
  subjecturllinkpf text NOT NULL,
  subjectkeycancel text NOT NULL,
  messagekey text NOT NULL,
  messagekeycancel text NOT NULL,
  messageformat tinyint(1) NOT NULL default '0',
  messagepageurllinkpf text NOT NULL,
  uidrule text NOT NULL,
  PRIMARY KEY  (robotid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_robotlog'
-- 

DROP TABLE IF EXISTS supe_robotlog;
CREATE TABLE supe_robotlog (
  hash  char(32) NOT NULL default '',
  PRIMARY KEY (hash)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_rss'
-- 

DROP TABLE IF EXISTS supe_rss;
CREATE TABLE supe_rss (
  uid mediumint(8) unsigned NOT NULL default '0',
  `type` varchar(10) NOT NULL default '',
  `data` mediumtext NOT NULL,
  updatetime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid,`type`)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_settings'
-- 

DROP TABLE IF EXISTS supe_settings;
CREATE TABLE supe_settings (
  variable varchar(32) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (variable)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_sitemaplogs'
-- 

DROP TABLE IF EXISTS supe_sitemaplogs;
CREATE TABLE supe_sitemaplogs (
  slogid smallint(6) unsigned NOT NULL auto_increment,
  mapname varchar(50) NOT NULL default '',
  maptype varchar(20) NOT NULL default '',
  mapnum int(10) unsigned NOT NULL default '0',
  createtype tinyint(1) unsigned NOT NULL default '0',
  mapdata mediumtext NOT NULL,
  lastitemid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) NOT NULL default '0',
  changefreq varchar(20) NOT NULL default '',
  lastfileid int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (slogid)
) TYPE=MyISAM ;

-- 
-- 表的结构 'supe_spaceblogs'
-- 

DROP TABLE IF EXISTS supe_spaceblogs;
CREATE TABLE supe_spaceblogs (
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  mood varchar(25) NOT NULL default '',
  weather varchar(25) NOT NULL default '',
  PRIMARY KEY  (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacecache'
-- 

DROP TABLE IF EXISTS supe_spacecache;
CREATE TABLE supe_spacecache (
  uid mediumint(8) unsigned NOT NULL default '0',
  cacheid smallint(6) unsigned NOT NULL default '0',
  `value` mediumtext NOT NULL,
  updatetime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid, cacheid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacecomments'
-- 

DROP TABLE IF EXISTS supe_spacecomments;
CREATE TABLE supe_spacecomments (
  cid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  `type` varchar(10) NOT NULL default '',
  uid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  rates smallint(6) NOT NULL default '0',
  url varchar(150) NOT NULL default '',
  `subject` varchar(100) NOT NULL default '',
  message text NOT NULL,
  PRIMARY KEY  (cid),
  KEY itemid (itemid,dateline),
  KEY uid (uid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacefiles'
-- 

DROP TABLE IF EXISTS supe_spacefiles;
CREATE TABLE supe_spacefiles (
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  filesize varchar(10) NOT NULL default '',
  filesizeunit varchar(5) NOT NULL default '',
  version varchar(100) NOT NULL default '',
  producer varchar(100) NOT NULL default '',
  downfrom varchar(100) NOT NULL default '',
  `language` varchar(100) NOT NULL default '',
  permission varchar(100) NOT NULL default '',
  system varchar(100) NOT NULL default '',
  remoteurl text NOT NULL,
  PRIMARY KEY  (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacegoods'
-- 

DROP TABLE IF EXISTS supe_spacegoods;
CREATE TABLE supe_spacegoods (
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  stocknum smallint(6) unsigned NOT NULL default '0',
  quality varchar(10) NOT NULL default '',
  price float unsigned NOT NULL default '0',
  province varchar(10) NOT NULL default '',
  city varchar(10) NOT NULL default '',
  chargemode varchar(10) NOT NULL default '',
  chargemail float unsigned NOT NULL default '0',
  chargeexpress float unsigned NOT NULL default '0',
  chargeems float unsigned NOT NULL default '0',
  paymenttype varchar(10) NOT NULL default '',
  term smallint(6) unsigned NOT NULL default '0',
  alipay varchar(50) NOT NULL default '',
  markup smallint(6) unsigned NOT NULL default '1',
  starttime int(10) unsigned NOT NULL default '0',
  image varchar(150) NOT NULL default '',
  thumb varchar(150) NOT NULL default '',
  `status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spaceimages'
-- 

DROP TABLE IF EXISTS supe_spaceimages;
CREATE TABLE supe_spaceimages (
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  image varchar(200) NOT NULL default '',
  imagenum smallint(6) NOT NULL default '0',
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  remoteurl text NOT NULL,
  bgmusic varchar(200) NOT NULL default '',
  PRIMARY KEY  (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spaceitems'
-- 

DROP TABLE IF EXISTS supe_spaceitems;
CREATE TABLE supe_spaceitems (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  catid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  itemtypeid mediumint(8) unsigned NOT NULL default '0',
  `type` char(10) NOT NULL default '',
  subtype char(10) NOT NULL default '',
  `subject` char(80) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  viewnum mediumint(8) unsigned NOT NULL default '0',
  replynum mediumint(8) unsigned NOT NULL default '0',
  trackbacknum mediumint(8) unsigned NOT NULL default '0',
  goodrate int(10) unsigned NOT NULL default '0',
  badrate int(10) unsigned NOT NULL default '0',
  digest tinyint(1) NOT NULL default '0',
  top tinyint(1) NOT NULL default '0',
  allowreply tinyint(1) NOT NULL default '1',
  `hash` char(16) NOT NULL default '',
  folder tinyint(1) NOT NULL default '1',
  haveattach tinyint(1) NOT NULL default '0',
  grade tinyint(1) NOT NULL default '0',
  gid mediumint(8) unsigned NOT NULL default '0',
  gdigest tinyint(1) NOT NULL default '0',
  `password` char(10) NOT NULL default '',
  `styletitle` char(11) NOT NULL default '',
  picid mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (itemid),
  KEY uid (uid,`type`,folder,top,dateline),
  KEY catid (catid,folder,dateline),
  KEY `type` (`type`,folder),
  KEY gid (gid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacelinks'
-- 

DROP TABLE IF EXISTS supe_spacelinks;
CREATE TABLE supe_spacelinks (
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  url varchar(255) NOT NULL default '',
  domain varchar(150) NOT NULL default '',
  snaptype tinyint(1) NOT NULL default '0',
  snaptext text NOT NULL,
  PRIMARY KEY  (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacenews'
-- 

DROP TABLE IF EXISTS supe_spacenews;
CREATE TABLE supe_spacenews (
  nid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  newsauthor varchar(20) NOT NULL default '',
  newsfrom varchar(50) NOT NULL default '',
  newsfromurl varchar(150) NOT NULL default '',
  newsurl varchar(255) NOT NULL default '',
  pageorder smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (nid),
  KEY itemid (itemid, pageorder, nid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacetags'
-- 

DROP TABLE IF EXISTS supe_spacetags;
CREATE TABLE supe_spacetags (
  itemid mediumint(8) unsigned NOT NULL default '0',
  tagid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  `type` char(10) NOT NULL default '',
  PRIMARY KEY  (itemid,tagid),
  KEY tagid (tagid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_spacevideos'
-- 

DROP TABLE IF EXISTS supe_spacevideos;
CREATE TABLE supe_spacevideos (
  itemid mediumint(8) unsigned NOT NULL default '0',
  message text NOT NULL,
  videoname varchar(100) NOT NULL default '',
  `file` varchar(100) NOT NULL default '',
  image varchar(200) NOT NULL default '',
  player varchar(10) NOT NULL default '',
  relativetags text NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  customfieldid smallint(6) unsigned NOT NULL default '0',
  customfieldtext text NOT NULL,
  includetags text NOT NULL,
  remoteurl text NOT NULL,
  maketime int(10) unsigned NOT NULL default '0',
  makeaddress varchar(100) NOT NULL default '',
  videosize int(10) NOT NULL default '0',
  PRIMARY KEY  (itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_styles'
-- 

DROP TABLE IF EXISTS supe_styles;
CREATE TABLE supe_styles (
  tplid smallint(6) unsigned NOT NULL auto_increment,
  tplname varchar(80) NOT NULL default '',
  tplnote text NOT NULL,
  tpltype varchar(20) default NULL,
  tplfilepath varchar(80) NOT NULL default '',
  PRIMARY KEY  (tplid),
  KEY tpltype (tpltype)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_tagcache'
-- 

DROP TABLE IF EXISTS supe_tagcache;
CREATE TABLE supe_tagcache (
  cachekey varchar(16) NOT NULL default '',
  uid mediumint(8) unsigned NOT NULL default '0',
  cachename varchar(20) NOT NULL default '',
  `value` mediumtext NOT NULL,
  updatetime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (cachekey)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_topicelements'
-- 

DROP TABLE IF EXISTS supe_topicelements;
CREATE TABLE supe_topicelements (
  id smallint(6) unsigned NOT NULL auto_increment,
  topid smallint(6) unsigned NOT NULL default '0',
  title varchar(50) NOT NULL default '',
  elementno tinyint(3) unsigned NOT NULL default '0',
  ids mediumtext NOT NULL,
  elementtplid tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY topid (topid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_topics'
-- 

DROP TABLE IF EXISTS supe_topics;
CREATE TABLE supe_topics (
  id smallint(6) unsigned NOT NULL auto_increment,
  catid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  `subject` varchar(80) NOT NULL default '',
  displayorder tinyint(3) unsigned NOT NULL default '0',
  starttime int(10) unsigned NOT NULL default '0',
  endtime int(10) unsigned NOT NULL default '0',
  image varchar(150) NOT NULL default '',
  message mediumtext NOT NULL,
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  viewnum mediumint(8) unsigned NOT NULL default '0',
  top tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY timespan (starttime,endtime)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_tags'
-- 

DROP TABLE IF EXISTS supe_tags;
CREATE TABLE supe_tags (
  tagid mediumint(8) unsigned NOT NULL auto_increment,
  tagname char(20) NOT NULL default '',
  uid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  `close` tinyint(1) NOT NULL default '0',
  spaceallnum mediumint(8) unsigned NOT NULL default '0',
  spacenewsnum mediumint(8) unsigned NOT NULL default '0',
  spaceblognum mediumint(8) unsigned NOT NULL default '0',
  spaceimagenum mediumint(8) unsigned NOT NULL default '0',
  spacefilenum mediumint(8) unsigned NOT NULL default '0',
  spacegoodsnum mediumint(8) unsigned NOT NULL default '0',
  spacelinknum mediumint(8) unsigned NOT NULL default '0',
  spacevideonum mediumint(8) NOT NULL default '0',
  relativetags char(255) NOT NULL default '',
  PRIMARY KEY  (tagid),
  KEY tagname (tagname),
  KEY tagid (tagid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_tracks'
-- 

DROP TABLE IF EXISTS supe_tracks;
CREATE TABLE supe_tracks (
  uid mediumint(8) unsigned NOT NULL default '0',
  itemid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid,itemid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_usercss'
-- 

DROP TABLE IF EXISTS supe_usercss;
CREATE TABLE supe_usercss (
  id mediumint(8) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  `name` varchar(20) NOT NULL default '',
  css text NOT NULL,
  dateline int(10) unsigned NOT NULL default '0',
  thumb varchar(150) NOT NULL default '',
  image varchar(150) NOT NULL default '',
  price smallint(6) NOT NULL default '0',
  isshare tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY isshare (isshare),
  KEY uid (uid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_userfields'
-- 

DROP TABLE IF EXISTS supe_userfields;
CREATE TABLE supe_userfields (
  uid mediumint(8) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (uid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_usergroups'
-- 

DROP TABLE IF EXISTS supe_usergroups;
CREATE TABLE supe_usergroups (
  groupid smallint(6) unsigned NOT NULL default '0',
  allowspace tinyint(1) NOT NULL default '0',
  allowspaceblog tinyint(1) NOT NULL default '0',
  allowspaceimage tinyint(1) NOT NULL default '0',
  allowspacefile tinyint(1) NOT NULL default '0',
  allowspacegoods tinyint(1) NOT NULL default '0',
  allowspacelink tinyint(1) NOT NULL default '0',
  allowspacevideo tinyint(1) NOT NULL default '0',
  attachsize int(12) unsigned NOT NULL default '0',
  allownews tinyint(1) NOT NULL default '0',
  needcheck tinyint(1) NOT NULL default '1',
  allowblogimport tinyint(1) NOT NULL default '0',
  allowbbsimport tinyint(1) NOT NULL default '0',
  allowcheckitem tinyint(1) NOT NULL default '0',
  allowundelete tinyint(1) NOT NULL default '0',
  allowdomain tinyint(1) NOT NULL default '0',
  allowcorpus tinyint(1) NOT NULL default '0',
  allowgroups tinyint(1) NOT NULL default '0',
  groupscheck tinyint(1) NOT NULL default '1',
  allowgroupsnum smallint(6) NOT NULL default '0',
  allowjoinnum smallint(6) NOT NULL default '0',
  allowusejs tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (groupid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_userlinks'
-- 

DROP TABLE IF EXISTS supe_userlinks;
CREATE TABLE supe_userlinks (
  linkid smallint(6) unsigned NOT NULL auto_increment,
  uid mediumint(8) unsigned NOT NULL default '0',
  `name` char(50) NOT NULL default '',
  note char(200) NOT NULL default '',
  logo char(100) NOT NULL default '',
  url char(100) NOT NULL default '',
  viewnum smallint(6) unsigned NOT NULL default '0',
  displayorder smallint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (linkid),
  KEY uid (uid,displayorder)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_userprofile'
-- 

DROP TABLE IF EXISTS supe_userprofile;
CREATE TABLE supe_userprofile (
  proid smallint(6) unsigned NOT NULL auto_increment,
  available tinyint(1) NOT NULL default '0',
  invisible tinyint(1) NOT NULL default '0',
  title varchar(50) NOT NULL default '',
  description varchar(255) NOT NULL default '',
  size tinyint(3) unsigned NOT NULL default '0',
  required tinyint(1) NOT NULL default '0',
  selective tinyint(1) NOT NULL default '0',
  choices text NOT NULL,
  displayorder smallint(6) NOT NULL default '0',
  PRIMARY KEY  (proid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_userspacefields'
-- 

DROP TABLE IF EXISTS supe_userspacefields;
CREATE TABLE supe_userspacefields (
  uid mediumint(8) unsigned NOT NULL default '0',
  perpage tinyint(3) unsigned NOT NULL default '0',
  announcement text NOT NULL,
  showblocks varchar(100) NOT NULL default '',
  blocknames text NOT NULL,
  summarylen smallint(6) unsigned NOT NULL default '0',
  attachsize int(12) unsigned NOT NULL default '0',
  customaddfeed tinyint(1) NOT NULL default '3',
  jammer tinyint(1) NOT NULL default '0',
  blogmod tinyint(1) NOT NULL default '1',
  blognum tinyint(3) unsigned NOT NULL default '0',
  imagenum tinyint(3) unsigned NOT NULL default '0',
  goodsnum tinyint(3) unsigned NOT NULL default '0',
  filenum tinyint(3) unsigned NOT NULL default '0',
  linknum tinyint(3) unsigned NOT NULL default '0',
  videonum tinyint(3) unsigned NOT NULL default '0',
  groupnum tinyint(3) unsigned NOT NULL default '0',
  threadnum tinyint(3) unsigned NOT NULL default '0',
  othernum tinyint(3) unsigned NOT NULL default '0',
  flash text NOT NULL,
  music text NOT NULL,
  choiceblockleft text NOT NULL,
  choiceblockright text NOT NULL,
  choiceblockmain text NOT NULL,
  myblock1 text NOT NULL,
  myblock2 text NOT NULL,
  myblock3 text NOT NULL,
  myblock4 text NOT NULL,
  myblock5 text NOT NULL,
  gradenames text NOT NULL,
  layout tinyint(1) unsigned NOT NULL default '1',
  showside tinyint(1) NOT NULL default '0',
  diy text NOT NULL,
  selfintro text NOT NULL,
  bankcredit mediumint(8) NOT NULL default '0',
  banktime int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_userspaces'
-- 

DROP TABLE IF EXISTS supe_userspaces;
CREATE TABLE supe_userspaces (
  uid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  catid smallint(6) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  spacename char(50) NOT NULL default '',
  viewnum int(10) unsigned NOT NULL default '0',
  spaceallnum mediumint(8) unsigned NOT NULL default '0',
  spaceblognum mediumint(8) unsigned NOT NULL default '0',
  spaceimagenum mediumint(8) unsigned NOT NULL default '0',
  spacefilenum mediumint(8) unsigned NOT NULL default '0',
  spacegoodsnum mediumint(8) unsigned NOT NULL default '0',
  spacelinknum mediumint(8) unsigned NOT NULL default '0',
  spacevideonum mediumint(8) NOT NULL default '0',
  province char(15) NOT NULL default '',
  city char(25) NOT NULL default '',
  domain char(20) NOT NULL default '',
  islock tinyint(1) NOT NULL default '0',
  isstar tinyint(1) NOT NULL default '0',
  spacemode char(10) NOT NULL default '',
  photo char(3) NOT NULL default '',
  spacesize int(12) NOT NULL default '0',
  credit mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (uid),
  KEY islock (islock,lastpost),
  KEY catid (catid,islock,lastpost)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_visitors'
-- 

DROP TABLE IF EXISTS supe_visitors;
CREATE TABLE supe_visitors (
  uid mediumint(8) unsigned NOT NULL default '0',
  visitoruid mediumint(8) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (uid,visitoruid),
  KEY uid (uid,dateline)
) TYPE=MyISAM;

-- --------------------------------------------------------

-- 
-- 表的结构 'supe_words'
-- 

DROP TABLE IF EXISTS supe_words;
CREATE TABLE supe_words (
  id smallint(6) unsigned NOT NULL auto_increment,
  admin varchar(15) NOT NULL default '',
  find varchar(255) NOT NULL default '',
  replacement varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) ENGINE=MyISAM;

-- --------------------------------------------------------