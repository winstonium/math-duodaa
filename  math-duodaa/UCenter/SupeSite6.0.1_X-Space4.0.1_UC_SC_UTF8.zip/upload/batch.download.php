<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���ش���

	$RCSfile: batch.download.php,v $
	$Revision: 1.23 $
	$Date: 2007/06/29 14:19:23 $
*/

include_once('./include/main.inc.php');

$aid = empty($_GET['aid'])?0:intval($_GET['aid']);
if(empty($aid)) exit('Access Denied');

include_once(S_ROOT.'./include/common.inc.php');

getcookie(1);

if(empty($_SCONFIG['allowguestdownload']) && empty($_SGLOBAL['supe_uid'])) {
	setcookie('_refer', rawurlencode(S_URL_ALL.'/batch.download.php?'.$_SERVER['QUERY_STRING']));
	messagebox('error', 'no_login', geturl('action/login'));
}

$query = $_SGLOBAL['db']->query('SELECT a.*, i.*, it.typename, it.viewperm, it.replyperm, it.getattachperm FROM '.tname('attachments').' a LEFT JOIN '.tname('spaceitems').' i ON i.itemid=a.itemid LEFT JOIN '.tname('itemtypes').' it ON it.typeid=i.itemtypeid WHERE a.aid=\''.$aid.'\'');
if($item = $_SGLOBAL['db']->fetch_array($query)) {
	if($_SGLOBAL['supe_uid'] != $item['uid']) {
		if($item['folder'] != 1) {
			messagebox('error', 'not_found');
		}
		if(!checkfriend($item['getattachperm'], $item['uid'])) {
			messagebox('error', 'not_found');
		}
	}
} else {
	messagebox('error', 'not_found');
}

//����
if(!empty($_SGLOBAL['supe_uid']) && empty($_SCONFIG['allowguestdownload'])) {
	include_once(S_ROOT.'./language/spacecp.lang.php');
	include_once(S_ROOT.'./function/spacecp.func.php');
	checkcredit('attachment', 1);
	batchcredit($_SGLOBAL['supe_uid'], 'attachment');
}

$_SGLOBAL['db']->query('UPDATE '.tname('attachments').' SET downloads=downloads+1 WHERE aid=\''.$aid.'\'');

$filename = A_DIR.'/'.$item['filepath'];
if(is_readable($filename)) {
	if(!empty($item['isimage'])) {
		echo '<img src="'.A_URL.'/'.$item['filepath'].'" />';
	} else {
		header('Cache-control: max-age=31536000');
		header('Expires: '.gmdate('D, d M Y H:i:s', $_SGLOBAL['timestamp'] + 31536000).' GMT');
		header('Content-Encoding: none');
		$item['filename'] = (strtolower($_SCONFIG['charset']) == 'utf-8' && strexists($_SERVER['HTTP_USER_AGENT'], 'MSIE')) ? urlencode($item['filename']) : $item['filename'];
		header('Content-Disposition: attachment; filename='.$item['filename']);
		header('Content-Type: application/octet-stream');
		
		if(!@readfile($filename)) {
			//����
			@ob_end_clean();
			if($fh = fopen($filename, 'rb')) {
				while(!feof($fh)) {
					echo fread($fh, 4096);
					flush();
					@ob_flush();
				}
				@fclose($fh);
			}
		}
	}
} else {
	messagebox('error', 'not_found');
}

?>