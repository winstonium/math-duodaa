<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	ͶƱ����

	$RCSfile: poll.php,v $
	$Revision: 1.14 $
	$Date: 2007/01/23 05:17:46 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

include_once(S_ROOT.'./include/common.inc.php');

$pollid = empty($_SGET['pollid'])?0:intval($_SGET['pollid']);
if(empty($pollid)) $pollid = intval(postget('pollid'));
if(empty($pollid)) messagebox('error', 'not_found', S_URL);

$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('polls').' WHERE pollid=\''.$pollid.'\'');
if(!$poll = $_SGLOBAL['db']->fetch_array($query)) messagebox('error', 'not_found', S_URL);

if(submitcheck('pollsubmit')) {

	if(empty($_POST['votekey'])) messagebox('error', 'no_votekey');

	getcookie(1);

	if(empty($_SGLOBAL['supe_uid'])) {
		$ip = $_SGLOBAL['onlineip'];
	} else {
		$ip = $_SGLOBAL['supe_uid'];
	}	
	$votekeys = $_POST['votekey'];
	$options = unserialize($poll['options']);
	if(empty($poll['voters'])) {
		$voters = array();
	} else {
		$voters = unserialize($poll['voters']);
	}
	
	if(!empty($voters) && in_array($ip, $voters)) {
		messagebox('error', 'poll_repeat');
	}
	
	$pollnum = 0;
	foreach ($votekeys as $votekey) {
		if(isset($options[$votekey]['num'])) {
			$options[$votekey]['num']++;
			$pollnum++;
		} else {
			messagebox('error', 'no_votekey');
		}
	}
	$options = addslashes(serialize($options));
	
	$voters[] = $ip;
	$voters = addslashes(serialize($voters));

	$_SGLOBAL['db']->query('UPDATE '.tname('polls').' SET pollnum=pollnum+'.$pollnum.', updatetime='.$_SGLOBAL['timestamp'].', options=\''.$options.'\', voters=\''.$voters.'\' WHERE pollid=\''.$pollid.'\'');

	messagebox('ok', 'succeed', geturl('action/poll/pollid/'.$pollid));
}

$poll['options'] = unserialize($poll['options']);
if(empty($poll['voters'])) {
	$poll['voters'] = array();
} else {
	$poll['voters'] = unserialize($poll['voters']);
}
//ͶƱ����
$poll['votersnum'] = count($poll['voters']);
$poll['dateline'] = sgmdate($poll['dateline'],'Y-m-d H:i:s');
$poll['updatetime'] = sgmdate($poll['updatetime'],'Y-m-d H:i:s');

foreach ($poll['options'] as $key => $options) {
	$options['percent'] = @sprintf ("%01.2f", $options['num'] * 100 / $poll['pollnum']);
	$poll['options'][$key] = $options;
}
$poll['votecount'] = count($poll['voters']);

$title = $lang['poll'];

include template('site_poll');

?>