<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��Ϣ����

	$RCSfile: batch.manage.php,v $
	$Revision: 1.26 $
	$Date: 2007/06/13 21:42:30 $
*/

include_once('./include/main.inc.php');
include_once('./include/common.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
$uid = empty($_GET['uid'])?0:intval($_GET['uid']);
if(!empty($itemid)) $uid = 0;
if(!empty($uid)) $itemid = 0;

if(empty($itemid) && empty($uid)) messagebox('error', 'no_normal_management_operation');

//��ʼ��
$item = $iteminf = $commentlist = $space = $itemlist = array();
$guidestr = $nextstart = '';
$theuid = $uid;

getcookie(1);

//�Ƿ��¼
if(empty($_SGLOBAL['supe_uid'])) {
	setcookie('_refer', rawurlencode(S_URL_ALL.'/batch.manage.php?'.$_SERVER['QUERY_STRING']));
	messagebox('error', 'conducting_management_operations_posted_first', geturl('action/login'));
}

//�����Ϣ
if(!empty($itemid)) {
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spaceitems')." WHERE itemid='$itemid'");
	if(!$item = $_SGLOBAL['db']->fetch_array($query)) {
		messagebox('error', 'management_information_has_been_deleted');
	}
	$theuid = $item['uid'];
}

//������ת����̨����
if(!empty($uid) && $uid == $_SGLOBAL['supe_uid']) sheader(S_URL.'/spacecp.php?docp=me');
if(!empty($itemid) && $theuid == $_SGLOBAL['supe_uid']) sheader(S_URL.'/spacecp.php?action='.gettypetablename($item['type']).'&op=edit&itemid='.$item['itemid']);

//����û����Ƿ���Ȩ��
if(empty($_SGLOBAL['group']['allowcheckitem']) && $_SGLOBAL['group']['groupid'] != 1) {
	if(!empty($uid)) {
		sheader(S_URL.'/spacecp.php?docp=me');
	} else {
		messagebox('error', 'the_only_information_on_their_operations');
	}
}

//��ȡ���˿ռ�
$space = getuserspace($theuid);
if(empty($space)) messagebox('error', 'the_management_of_the_space_does_not_exist');

//�ύ����
if(submitcheck('actionsubmit')) {
	switch ($_GET['actionsubmit']) {
		case 'delete':
			if(!empty($itemid)) {
				deleteitems('itemid', $itemid);
				messagebox('ok', 'info_has_been_completely_erased_designated', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'rush':
			if(!empty($itemid)) {
				deleteitems('itemid', $itemid, 1);
				messagebox('ok', 'info_was_placed_in_the_collection_points', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'category':
			$catid = intval($_POST['catid']);
			if(!empty($itemid) && !empty($catid)) {
				updatetable('spaceitems', array('catid'=>$catid), array('itemid'=>$itemid));
				messagebox('ok', 'info_updated_type_system_completed', 'batch.manage.php?itemid='.$itemid);
			}
			break;
		case 'grade':
			$grade = intval($_POST['grade']);
			if(!empty($itemid)) {
				updatetable('spaceitems', array('grade'=>$grade), array('itemid'=>$itemid));
				messagebox('ok', 'info_completion_of_the_examination_grades', 'batch.manage.php?itemid='.$itemid);
			}
			break;
		case 'deletecomment':
			if(!empty($itemid) && !empty($_POST['comments'])) {
				$itemarr = array();
				$sqlwhere = 'cid IN (\''.implode('\', \'', $_POST['comments']).'\')';
				$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spacecomments')." WHERE $sqlwhere");
				while ($comment = $_SGLOBAL['db']->fetch_array($query)) {
					if (!isset($itemarr[$comment['itemid']]['goodrate'])) {
						$itemarr[$comment['itemid']]['goodrate'] = 0;
					}
					if (!isset($itemarr[$comment['itemid']]['badrate'])) {
						$itemarr[$comment['itemid']]['badrate'] = 0;
					}
					if (!isset($itemarr[$comment['itemid']]['replynum'])) {
						$itemarr[$comment['itemid']]['replynum'] = 0;
					}
					if (!isset($itemarr[$comment['itemid']]['trackback'])) {
						$itemarr[$comment['itemid']]['trackback'] = 0;
					}
					if (empty($comment['url'])) {
						$itemarr[$comment['itemid']]['replynum']++;
					} else {
						$itemarr[$comment['itemid']]['trackback']++;
					}
					if ($comment['rates'] > 0) {
						$itemarr[$comment['itemid']]['goodrate'] += $comment['rates'];
					} elseif ($comment['rates'] < 0) {
						$itemarr[$comment['itemid']]['badrate'] += $comment['rates'];
					}
				}
				if($itemarr) {
					$_SGLOBAL['db']->query('DELETE FROM '.tname('spacecomments').' WHERE '.$sqlwhere);
					foreach ($itemarr as $key => $item) {
						$_SGLOBAL['db']->query('UPDATE '.tname('spaceitems').' SET replynum=replynum-'.$item['replynum'].', trackbacknum=trackbacknum-'.$item['trackback'].', goodrate=goodrate-'.$item['goodrate'].', badrate=badrate+'.$item['badrate'].' WHERE itemid=\''.$key.'\'');
					}
				}
				messagebox('ok', 'info_has_been_designated_to_delete_comments', 'batch.manage.php?itemid='.$itemid);
			}
			break;
		case 'isstar':
			if(!empty($theuid)) {
				updatetable('userspaces', array('isstar'=>1), array('uid'=>$theuid));
				messagebox('ok', 'space_has_been_set_up_for_the_space_star', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'unstar':
			if(!empty($theuid)) {
				updatetable('userspaces', array('isstar'=>0), array('uid'=>$theuid));
				messagebox('ok', 'star_has_been_canceled_designated_space', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'islock':
			if(!empty($theuid)) {
				updatetable('userspaces', array('islock'=>1), array('uid'=>$theuid));
				updatetable('spaceitems', array('folder'=>3), array('uid'=>$theuid));
				messagebox('ok', 'space_has_been_designated_lock', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'unlock':
			if(!empty($theuid)) {
				updatetable('userspaces', array('islock'=>0), array('uid'=>$theuid));
				messagebox('ok', 're_opening_of_the_designated_space_success', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'deletelist':
			if(!empty($_POST['items'])) {
				deleteitems('itemid', $_POST['items']);
				messagebox('ok', 'info_has_been_completely_erased_designated', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'rushlist':
			if(!empty($_POST['items'])) {
				deleteitems('itemid', $_POST['items'], 1);
				messagebox('ok', 'info_was_placed_in_the_collection_points', 'batch.manage.php?uid='.$theuid);
			}
			break;
		case 'gradelist':
			$grade = intval($_POST['grade']);
			if(!empty($_POST['items'])) {
				deleteitems('itemid', $_POST['items'], 1);
				$_SGLOBAL['db']->query("UPDATE ".tname('spaceitems')." SET grade='$grade' WHERE itemid IN (".simplode($_POST['items']).")");
				messagebox('ok', 'info_completion_of_the_examination_grades', 'batch.manage.php?uid='.$theuid);
			}
			break;
	}
}

$space['status'] = '';
if($space['isstar']) {
	$space['status'] .= '<button type="submit" name="actionsubmit" value="unstar" onclick="this.form.action+=\'&actionsubmit=unstar\';">'.$blang['space_star_cancellation'].'</button>';
} else {
	$space['status'] .= '<button type="submit" name="actionsubmit" value="isstar" onclick="this.form.action+=\'&actionsubmit=isstar\';">'.$blang['purchase_of_space_star'].'</button>';
}
if($space['islock']) {
	$space['status'] .= '&nbsp;<button type="submit" name="actionsubmit" value="unlock" onclick="this.form.action+=\'&actionsubmit=unlock\';">'.$blang['to_re_open_space'].'</button>';
} else {
	$space['status'] .= '&nbsp;<button type="submit" name="actionsubmit" value="islock" onclick="this.form.action+=\'&actionsubmit=islock\';return confirm(\''.$blang['locked_space_note'].'\');">'.$blang['locked_space'].'</button>';
}

//��˵ȼ�
$gradearr = array(
	'0' => $blang['grade0'],
	'1' => $blang['grade1'],
	'2' => $blang['grade2'],
	'3' => $blang['grade3'],
	'4' => $blang['grade4'],
	'5' => $blang['grade5']
);
if(!empty($_SCONFIG['checkgrade'])) {
	$newgradearr = explode("\t", $_SCONFIG['checkgrade']);
	for($i=0; $i<5; $i++) {
		if(!empty($newgradearr[$i])) $gradearr[$i+1] = $newgradearr[$i];
	}
}

if(!empty($itemid)) {
	//����
	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname(gettypetablename($item['type'])).' WHERE itemid=\''.$itemid.'\'');
	$iteminf = $_SGLOBAL['db']->fetch_array($query);

	//���ݷ�html��
	if(!empty($iteminf['message'])) $iteminf['message'] = shtmlspecialchars($iteminf['message']);
	
	//����
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spacecomments')." WHERE itemid='$itemid' ORDER BY cid DESC LIMIT 0,100");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		if(!empty($value['message'])) $value['message'] = shtmlspecialchars($value['message']);
		$commentlist[] = $value;
	}
	
	//����
	$catstr = '';
	$uplistarr = getcategory($item['type']);
	$catselarr = array($item['catid']=>' selected');
	foreach ($uplistarr as $key => $value) {
		if(empty($catselarr[$key])) $catselarr[$key] = '';
		$catstr .= '<option value="'.$key.'"'.$catselarr[$key].'>'.$value['pre'].$value['name'].'</option>';
	}

	//�ȼ����
	$gradestr = getselectstr('grade', $gradearr, $item['grade']);
}

if(!empty($uid)) {
	
	$perpage = 50;
	$itemlist = array();
	$page = empty($_GET['page'])?1:intval($_GET['page']);
	$page = $page<1?1:$page;
	$start = ($page-1)*$perpage;
	
	$multipage = '';
	
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT COUNT(*) FROM ".tname('spaceitems')." WHERE uid='$uid'"), 0);
	if($count) {
		$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spaceitems')." WHERE uid='$uid' ORDER BY dateline DESC LIMIT $start, $perpage");
		while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			$itemlist[] = $value;
		}
		$multipage = multi($count, $perpage, $page, S_URL.'/batch.manage.php?uid='.$uid);
	}
	
	//�ȼ����
	$gradestr = getselectstr('grade', $gradearr);
}

$title = $lang['manage'].' - '.$space['spacename'];

include template('site_manage');

?>