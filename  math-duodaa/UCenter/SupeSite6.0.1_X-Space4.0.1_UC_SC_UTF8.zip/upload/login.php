<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��Ա��¼ҳ��

	$RCSfile: login.php,v $
	$Revision: 1.19 $
	$Date: 2007/04/10 16:15:40 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

include_once(S_ROOT.'./include/common.inc.php');

getcookie();
if(!empty($_SGLOBAL['supe_uid'])) {
	sheader(geturl('action/site/type/panel'));
}

$registerurl = getbbsurl('register.php', array('referer'=>S_URL.'/?action/login'));
$lostpassword = getbbsurl('member.php', array('action'=>'lostpasswd'));

if(!empty($_COOKIE['_refer'])) {
	$refer = $_COOKIE['_refer'];
} else {
	$refer = geturl('action/site/type/panel', 1);
}

$title = $lang['login'];

include template('site_login');

?>