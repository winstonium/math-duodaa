<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��ҳ

	$RCSfile: index.php,v $
	$Revision: 1.74 $
	$Date: 2007/06/27 17:15:08 $
*/

include_once('./include/main.inc.php');
	
//��ȡ����
if($_SCONFIG['urltype'] == '2' || $_SCONFIG['urltype'] == '5') {
	$parsegetvar = empty($_SERVER['PATH_INFO'])?(empty($_SERVER['ORIG_PATH_INFO'])?'':substr($_SERVER['ORIG_PATH_INFO'], 1)):substr($_SERVER['PATH_INFO'], 1);
}
if(empty($parsegetvar)) $parsegetvar = empty($_SERVER['QUERY_STRING'])?'':$_SERVER['QUERY_STRING'];

//��������
if(!empty($parsegetvar)) {
	$parsegetvar = addslashes($parsegetvar);
	//��׺����ģʽ
	if($_SCONFIG['allowdomain'] == 3) {
		if(preg_match("/^[a-z][0-9a-z]*$/i", $parsegetvar)) mydomain($parsegetvar);
	}
	$_SGET = parseparameter(str_replace(array('-','_'), '/', $parsegetvar));
} else {
	//��������
	if(!empty($_SCONFIG['allowdomain'])) {
		if(strpos(S_URL_ALL, $_SERVER['HTTP_HOST']) === false) {
			$hostarr = explode('.', $_SERVER['HTTP_HOST']);
			if(count($hostarr) > 2) {
				if(count($hostarr) > 3 && $hostarr[0] == 'www') {
					$hostdomain = $hostarr[1];
				} else {
					$hostdomain = $hostarr[0];
				}
			}
		}
		if(!empty($hostdomain)) mydomain(rawurlencode($hostdomain));
	}
}

//��������
if(!empty($_SGET['viewnews'])) {
	$_SGET['action'] = 'viewnews';
	$_SGET['itemid'] = intval($_SGET['viewnews']);
} elseif(!empty($_SGET['viewspace'])) {
	$_SGET['action'] = 'viewspace';
	$_SGET['itemid'] = intval($_SGET['viewspace']);
} elseif(!empty($_SGET['viewthread'])) {
	$_SGET['action'] = 'viewthread';
	$_SGET['tid'] = intval($_SGET['viewthread']);
} elseif(!empty($_SGET['category'])) {
	$_SGET['action'] = 'category';
	$_SGET['catid'] = intval($_SGET['category']);
} elseif(!empty($_SGET['mygroup'])) {
	$_SGET['action'] = 'mygroup';
	$_SGET['gid'] = intval($_SGET['mygroup']);
} elseif(!empty($_SGET['spacelist'])) {
	$_SGET['action'] = 'spacelist';
	$_SGET['type'] = $_SGET['spacelist'];
} elseif(empty($_SGET['action']) && !empty($_SGET['uid'])) {
	$_SGET['action'] = 'space';
	$_SGET['uid'] = intval($_SGET['uid']);
} else {
	$_SGET['action'] = empty($_SGET['action'])?'index':trim(preg_replace("/[^a-z0-9\-\_]/i", '', trim($_SGET['action'])));
}

//վ��ر�
if(!empty($_SCONFIG['closesite']) && $_SGET['action'] != 'login') {
	getcookie(1);
	if(empty($_SGLOBAL['group']['groupid']) || $_SGLOBAL['group']['groupid'] != 1) {
		if(empty($_SCONFIG['closemessage'])) $_SCONFIG['closemessage'] = $lang['site_close'];
		messagebox('error', $_SCONFIG['closemessage'].'<p style="font-size:12px;"><a href="'.geturl("action/login").'">'.$lang['admin_login'].'</a></p>');
	}
}

//���Ʒ�ҳ500
if(!empty($_SGET['page'])) {
	if($_SGET['page'] > 500) {
		messagebox('error', 'page_limit');
	}
}

//�ؼ��֡�����������������
$keywordarr = $descriptionarr = $guidearr = $titlearr = array();

//�Զ���Ƶ��
if($_SGET['action'] == 'channel') {
	$_SGET['name'] = empty($_SGET['name'])?'':trim(preg_replace("/[^a-z0-9\-\_]/i", '', trim($_SGET['name'])));
	if(!empty($_SGET['name'])) {
		$scriptfile = S_ROOT.'./channel/channel_'.$_SGET['name'].'.php';
		if(file_exists($scriptfile)) {
			include_once($scriptfile);
			exit();
		}
	}
}

//�Զ���ģ��
if($_SGET['action'] == 'model') {
	$_SGET['name'] = empty($_SGET['name'])?'':trim(preg_replace("/[^a-z0-9\-\_]/i", '', trim($_SGET['name'])));
	if(!empty($_SGET['name'])) {
		if(!empty($_SGET['itemid'])) {
			$scriptfile = S_ROOT.'./modelview.php';
		} else {
			$scriptfile = S_ROOT.'./modelindex.php';
		}
		if(file_exists($scriptfile)) {
			include_once($scriptfile);
			exit();
		}
	}
}

//ϵͳƵ��
if($_SGET['action'] != 'index') {
	$scriptfile = S_ROOT.'./'.$_SGET['action'].'.php';
	if(file_exists($scriptfile)) {
		include_once($scriptfile);
		exit();
	}
}

//Ĭ����ҳ
if(!empty($channels['default']) && $channels['default'] != 'index.php') {
	if(strpos($channels['default'], '?')) {
		sheader(S_URL.'/'.$channels['default']);
		exit();
	} else {
		include_once(S_ROOT.'./'.$channels['default']);
	}
	
} else {

	if(!empty($_SCONFIG['htmlindex'])) {
		$_SHTML['action'] = 'index';
		$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
		ehtml('get', $_SCONFIG['htmlindextime']);
		$_SCONFIG['debug'] = 0;
	}

	include_once(S_ROOT.'./include/common.inc.php');

	$title = $_SCONFIG['sitename'];
	$keywords = $_SCONFIG['sitename'];
	$description = $_SCONFIG['sitename'];
	
	include template('index');

	ob_out();
	
	if(!empty($_SCONFIG['htmlindex'])) {
		ehtml('make');
	} else {
		maketplblockvalue('cache');
	}
}

?>