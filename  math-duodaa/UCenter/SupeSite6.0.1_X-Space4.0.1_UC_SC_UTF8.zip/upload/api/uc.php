<?php

error_reporting(7);
define('UC_VERSION', '1.0.0');		//note UCenter 版本标识

define('API_DELETEUSER', 1);		//note 用户删除 API 接口开关
define('API_RENAMEUSER', 1);		//note 用户改名 API 接口开关
define('API_GETTAG', 1);		//note 获取标签 API 接口开关
define('API_SYNLOGIN', 1);		//note 同步登录 API 接口开关
define('API_SYNLOGOUT', 1);		//note 同步登出 API 接口开关
define('API_UPDATEPW', 1);		//note 更改用户密码 开关
define('API_UPDATEBADWORDS', 1);	//note 更新关键字列表 开关
define('API_UPDATEHOSTS', 1);		//note 更新域名解析缓存 开关
define('API_UPDATEAPPS', 1);		//note 更新应用列表 开关
define('API_UPDATECLIENT', 1);		//note 更新客户端缓存 开关
define('API_UPDATECREDIT', 1);		//note 更新用户积分 开关
define('API_GETCREDITSETTINGS', 1);	//note 向 UCenter 提供积分设置 开关
define('API_UPDATECREDITSETTINGS', 1);	//note 更新应用积分设置 开关

define('API_RETURN_SUCCEED', '1');
define('API_RETURN_FAILED', '-1');
define('API_RETURN_FORBIDDEN', '-2');

define('IN_SUPESITE', TRUE);
define('S_ROOT', substr(dirname(__FILE__), 0, -3));
define('UC_CLIENT_ROOT', S_ROOT.'./uc_client/');
include_once(S_ROOT.'./config.php');
include_once(S_ROOT.'./function/main.func.php');
@include_once(S_ROOT.'./data/system/config.cache.php');
$_SGLOBAL = array();
$_SCONFIG = $_SSCONFIG;
$_SCONFIG['ucmode'] = $ucmode;	//UC开关
if(!empty($_SCONFIG['ucmode'])) {
	$cookiepre = "xs".$cookiepre;
}


$code = $_GET['code'];
parse_str(authcode($code, 'DECODE', UC_KEY), $get);
if(time() - $get['time'] > 3600) {
	exit('Authracation has expiried');
}
if(empty($get)) {
	exit('Invalid Request');
}
$action = $get['action'];
$_SGLOBAL['timestamp'] = $timestamp = time();

if($action == 'test') {

	exit(API_RETURN_SUCCEED);

} elseif($action == 'deleteuser') {
	
	//note 用户删除 API 接口
	!API_DELETEUSER && exit(API_RETURN_FORBIDDEN);
	
	exit(API_RETURN_SUCCEED);

} elseif($action == 'renameuser') {
	
	//note 用户改名
	!API_RENAMEUSER && exit(API_RETURN_FORBIDDEN);

	exit(API_RETURN_SUCCEED);

} elseif($action == 'gettag') {

	//note 获取标签 API 接口
	!API_GETTAG && exit(API_RETURN_FORBIDDEN);
	
	exit(API_RETURN_SUCCEED);

} elseif($action == 'synlogin') {

	//note 同步登录 API 接口
	
	!API_SYNLOGIN && exit(API_RETURN_FORBIDDEN);

	header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');
	$uid = intval($get['uid']);
	
	$cookietime = 2592000;
	$ss_auth_key = md5($_SCONFIG['sitekey'].$_SERVER['HTTP_USER_AGENT']);
	include_once(S_ROOT.'./class/db_mysql.class.php');
	//链接数据库
	dbconnect();
	
	$query = $_SGLOBAL['db'] -> query("SELECT * FROM ".tname('members')." WHERE uid='$uid'");
	if($member = $_SGLOBAL['db'] -> fetch_array($query)) {
		ssetcookie('sid', '', -86400 * 365);
		ssetcookie('cookietime', $cookietime, 31536000);
		ssetcookie('auth', authcode("$member[password]\t$member[secques]\t$member[uid]", 'ENCODE', $ss_auth_key), $cookietime);
	} else {
		ssetcookie('cookietime', $cookietime, 31536000);
		ssetcookie('loginuser', $get['username'], $cookietime);
		ssetcookie('activationauth', authcode($get['username'], 'ENCODE', $ss_auth_key), $cookietime);
	}

} elseif($action == 'synlogout') {
	
	//note 同步登出 API 接口
	!API_SYNLOGOUT && exit(API_RETURN_FORBIDDEN);

	header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');
	ssetcookie('auth', '', -86400 * 365);
	ssetcookie('sid', '', -86400 * 365);
	ssetcookie('loginuser', '', -86400 * 365);
	ssetcookie('activationauth', '', -86400 * 365);

} elseif($action == 'updatepw') {
	
	//修改密码
	!API_UPDATEPW && exit(API_RETURN_FORBIDDEN);

	exit(API_RETURN_SUCCEED);

} elseif($action == 'updatebadwords') {

	!API_UPDATEBADWORDS && exit(API_RETURN_FORBIDDEN);

	$post = uc_unserialize(file_get_contents('php://input'));
	$cachefile = UC_CLIENT_ROOT.'./data/cache/badwords.php';
	$fp = fopen($cachefile, 'w');
	$s = "<?php\r\n";
	$s .= '$_CACHE[\'badwords\'] = '.var_export($post, TRUE).";\r\n";
	fwrite($fp, $s);
	fclose($fp);
	exit(API_RETURN_SUCCEED);

} elseif($action == 'updatehosts') {

	!API_UPDATEHOSTS && exit(API_RETURN_FORBIDDEN);

	$post = uc_unserialize(file_get_contents('php://input'));
	$cachefile = UC_CLIENT_ROOT.'./data/cache/hosts.php';
	$fp = fopen($cachefile, 'w');
	$s = "<?php\r\n";
	$s .= '$_CACHE[\'hosts\'] = '.var_export($post, TRUE).";\r\n";
	fwrite($fp, $s);
	fclose($fp);
	exit(API_RETURN_SUCCEED);

} elseif($action == 'updateapps') {

	!API_UPDATEAPPS && exit(API_RETURN_FORBIDDEN);

	$post = uc_unserialize(file_get_contents('php://input'));
	$UC_API = $post['UC_API'];
	unset($post['UC_API']);
	$cachefile = UC_CLIENT_ROOT.'./data/cache/apps.php';
	$fp = fopen($cachefile, 'w');
	$s = "<?php\r\n";
	$s .= '$_CACHE[\'apps\'] = '.var_export($post, TRUE).";\r\n";
	fwrite($fp, $s);
	fclose($fp);
	if(is_writeable(S_ROOT.'./config.php')) {
		foreach($post as $appdata) {
			if($appdata['appid'] == UC_APPID) {
				$fp = fopen(S_ROOT.'./config.php', 'r');
				$configfile = fread($fp, filesize(S_ROOT.'./config.php'));
				$configfile = trim($configfile);
				$configfile = substr($configfile, -2) == '?>' ? substr($configfile, 0, -2) : $configfile;
				fclose($fp);
				$configfile = preg_replace("/define\('UC_API',\s*'.*?'\);/i", "define('UC_API', '$UC_API');", $configfile);
				$configfile = preg_replace("/define\('UC_IP',\s*'.*?'\);/i", "define('UC_IP', '$appdata[ip]');", $configfile);

				if($fp = @fopen(S_ROOT.'./config.php', 'w')) {
					@fwrite($fp, trim($configfile));
					@fclose($fp);
				}
			}
		}
	}
	exit(API_RETURN_SUCCEED);

} elseif($action == 'updateclient') {

	!API_UPDATECLIENT && exit(API_RETURN_FORBIDDEN);

	$post = uc_unserialize(file_get_contents('php://input'));
	$cachefile = UC_CLIENT_ROOT.'./data/cache/settings.php';
	$fp = fopen($cachefile, 'w');
	$s = "<?php\r\n";
	$s .= '$_CACHE[\'settings\'] = '.var_export($post, TRUE).";\r\n";
	fwrite($fp, $s);
	fclose($fp);
	exit(API_RETURN_SUCCEED);

} elseif($action == 'updatecredit') {
	
	//积分
	!UPDATECREDIT && exit(API_RETURN_FORBIDDEN);
	
	exit(API_RETURN_SUCCEED);

} elseif($action == 'getcreditsettings') {

	!API_GETCREDITSETTINGS && exit(API_RETURN_FORBIDDEN);
	
	exit(API_RETURN_SUCCEED);

} elseif($action == 'updatecreditsettings') {

	//积分设置
	!API_UPDATECREDITSETTINGS && exit(API_RETURN_FORBIDDEN);

	exit(API_RETURN_SUCCEED);

} else {

	exit(API_RETURN_FAILED);

}

function uc_unserialize($s) {
	include_once UC_CLIENT_ROOT.'./lib/xml.class.php';
	return xml_unserialize($s);
}
?>