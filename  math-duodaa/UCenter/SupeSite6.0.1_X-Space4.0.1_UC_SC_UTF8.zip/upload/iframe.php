<?php
/*
[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
���ֺп�ҳ�沥�ŵĿ�ܳ���

$RCSfile: iframe.php,v $
$Revision: 1.3 $
$Date: 2007/08/01 08:11:21 $
*/
include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');
dbconnect();
$_GET['uid'] = intval($_GET['uid']);
$reauthcode = md5($_SCONFIG['sitekey'].$_GET['uid']);
$s_url = S_URL;
if($_GET['passpage'] == 1) {
	echo '<script language="javascript" type="text/javascript">location.href="'.S_URL.'/index.php?uid-'.$_GET['uid'].'-noframe-1";</script>';
	exit;
}else {
	$newurl =  S_URL."/batch.common.php?action=musicpasspage&uid=$_GET[uid]&hash=$reauthcode";
}
if(empty($newurl)) {
	$display = 'none';
} else {
	$display = '';
}
$space = getuserspace($_GET['uid']);
print <<<EOF
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset];">
<title>$space[spacename] Power by X-Space</title>
<script>
function framebutton(){
	var obj = document.getElementById('navigation');
	var musicobj = document.getElementById('topFrame');
	var frameswitch = document.getElementById('frameswitch');
	var switchbar = document.getElementById('switchbar');
	if(obj.style.width == '1px'){
		obj.style.width = '192px';
		musicobj.style.width = '192px';
		switchbar.style.left = '192px';
		frameswitch.style.backgroundPosition = '0';
		frameswitch.src = '$s_url/images/flashplayer/btn_hide.jpg';
	}else{
		obj.style.width = '1px';
		musicobj.style.width = '1px';
		switchbar.style.left = '1px';
		frameswitch.style.backgroundPosition = '-11';
		frameswitch.src = '$s_url/images/flashplayer/btn_show.jpg';
	}
}

if(top != self) {
	top.location = self.location;
}
</script>
</head>
<body style="height: 100%; margin: 0; padding: 0;"  scroll="no">
<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
  <td id="navigation" style="width:1px; height:200px; url($s_url/images/flashplayer/bg_framebottom.jpg) no-repeat left bottom; vertical-align:top; ">
  	<iframe src="$newurl" frameborder="0" scrolling="no" style="width:1px; height:100% ;" name="topFrame" id="topFrame"></iframe>
  </td>
  <td style="height: 100%;width: 100%;">
		<table id="switchbar" width="14" height="100%" cellspacing="0" cellpadding="0" border="0" style="position: absolute; left: 1px; background-repeat: repeat-y; background-position: -192px; repeat-y left center;">
			<tbody>
				<tr>
					<td onClick="framebutton()" style="display:$display"><img  id="frameswitch" border="0" src="images/flashplayer/btn_show.jpg" style="background-position: 0pt 50%;"/></a></td>
				</tr>
			</tbody>
		</table>
  	<iframe style="height: 100%; width: 100%; " src="$s_url/index.php?uid-$_GET[uid]-noframe-1" name="mainFrame" frameborder="0" scrolling="yes"></iframe>
  </td>
  </tr>
  </table>
</body>
</html>
EOF;
?>
