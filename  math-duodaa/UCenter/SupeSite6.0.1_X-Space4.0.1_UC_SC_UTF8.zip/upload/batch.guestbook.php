<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���Դ���

	$RCSfile: batch.guestbook.php,v $
	$Revision: 1.20 $
	$Date: 2007/07/05 17:52:16 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./include/common.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$action = empty($_GET['action'])?'':$_GET['action'];
$page = empty($_GET['page'])?1:intval($_GET['page']);

if(!empty($_POST['btncomment'])) {
	if(!submitcheck('btncomment', 1)) {
		messagebox('error', 'seccode_error');
	}
	if(empty($_POST['uid'])) $_POST['uid'] = 0;
	$_POST['uid'] = intval($_POST['uid']);
	if(empty($_POST['uid'])) {
		messagebox('error', 'system_error');
	}

	getcookie(1);
	$author = $_SGLOBAL['supe_username'];
	if(empty($_SGLOBAL['supe_uid'])) {
		if(empty($_SCONFIG['allowguest'])) {
			messagebox('error', 'no_login', geturl('action/login'));
		}
		if(!empty($_POST['nickname'])) {
			$author = addslashes(cutstr(shtmlspecialchars(stripslashes($_POST['nickname'])), 15));
		}
	}

	$_POST['message'] = shtmlspecialchars(trim($_POST['message']));
	if(strlen($_POST['message']) < 2 || strlen($_POST['message']) >5000) {
		messagebox('error', 'message_length_error');
	}

	$_POST['message' ] = censor($_POST['message']);

	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('userspaces').' WHERE uid=\''.$_POST['uid'].'\' AND islock=\'0\'');
	if(!$space = $_SGLOBAL['db']->fetch_array($query)) messagebox('error', 'system_error');

	$setsqlarr = array(
		'uid' => $space['uid'],
		'isprivate' => intval($_POST['isprivate']),
		'authorid' => $_SGLOBAL['supe_uid'],
		'author' => $author,
		'ip' => $_SGLOBAL['onlineip'],
		'dateline' => $_SGLOBAL['timestamp'],
		'message' => $_POST['message']
	);
	inserttable('guestbooks', $setsqlarr);
	if(allowfeed() && !empty($_POST['addfeed']) && $space['uid'] != $_SGLOBAL['supe_uid']) {
		$feed['icon'] = 'post';
		$feed['title_template'] = 'feed_guestbook_title';
		$feed['title_data'] = array(
			'host' => "<a href=\"".geturl('uid/'.$space['uid'].'/action/viewpro', 1)."\" >{$space['username']}</a>" );
		postfeed($feed);
	}
	clearspacecache($space['uid'], 'guestbook');

	$url = geturl("uid/$space[uid]/action/viewpro/php/1");
	messagebox('ok', 'succeed', $url);

} elseif ($action == 'reply') {

	$allow = false;
	$gid = empty($_GET['gid'])?intval($_POST['gid']):intval($_GET['gid']);
	$itemarr = array();
	if(!empty($gid)) {
		getcookie(1);
		if(!empty($_SGLOBAL['supe_uid'])) {
			include_once(S_ROOT.'./include/common.inc.php');
			$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('guestbooks').' WHERE gid=\''.$gid.'\' AND uid=\''.$_SGLOBAL['supe_uid'].'\'');
			if($itemarr = $_SGLOBAL['db']->fetch_array($query)) {
				$allow = true;
			}
		}
	}

	if(!$allow) showxml('<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['mail_close'].'</a>'.$blang['guestbooks_title'].'</h5><div class="xspace-ajaxcontent" style="text-align: center; padding: 3em 0;">'.$blang['guestbooks_reply_error'].'</div>');

	if(submitcheck('replysubmit')) {
		$wheresqlarr = $setsqlarr = array();

		$_POST['replymsg'] = saddslashes($itemarr['message']).'<div class="xspace-guestbookreply"><p>'.sgmdate($_SGLOBAL['timestamp']).'</p>'.saddslashes(trim(shtmlspecialchars($_POST['replymsg']))).'</div>';
		$setsqlarr = array(
			'message'=>$_POST['replymsg']
		);
		$wheresqlarr = array(
			'gid'=>$gid,
			'uid'=>$_SGLOBAL['supe_uid']
		);
		updatetable('guestbooks', $setsqlarr, $wheresqlarr);
		messagebox('ok', 'guestbooks_reply_succeed', geturl("uid/$itemarr[uid]/action/viewpro/page/$page"));
	} else {
		$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['mail_close'].'</a>'.$blang['guestbooks_title'].'</h5>
		<div class="xspace-ajaxcontent">
			<form method="post" action="'.S_URL.'/batch.guestbook.php?action=reply&page='.$page.'" target="_self">
				<table width="100%" summary="" cellpadding="0" cellspacing="0" border="0" style="height: 100%; text-align: center;">
					<tr>
						<td style="padding: 3em 0;"><textarea id="xspace-commentmsg" name="replymsg"></textarea></td>
					</tr>
					<tr><td><button type="submit" name="replysubmit" value="true">'.$blang['guestbooks_title'].'</button></td></tr>
				</table><input type="hidden" name="gid" value="'.$gid.'" /></form>
		</div>';

		showxml($html);
	}

} elseif ($action == 'delete') {

	getcookie(1);
	$gid = empty($_GET['gid'])?0:intval($_GET['gid']);
	if(empty($gid) || empty($_SGLOBAL['supe_uid'])) showxml($blang['message_no_permission']);

	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('guestbooks').' WHERE gid=\''.$gid.'\'');
	if($value = $_SGLOBAL['db']->fetch_array($query)) {

		//���Ȩ��
		if($value['uid'] != $_SGLOBAL['supe_uid'] && empty($_SGLOBAL['group']['allowcheckitem'])) showxml($blang['message_no_permission']);

		deletetable('guestbooks', array('gid'=>$gid));

		clearspacecache($_SGLOBAL['supe_uid'], 'guestbooks');
		showxml($blang['message_delete_ok']);
	} else {
		showxml($blang['message_no_permission']);
	}
}

?>