<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads2 = getad('system',$modelsinfoarr[modelname], 2)}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div class="models-content">
	<div class="models-main">
		<div class="models-nav">
			您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</div>
		<div class="models-articletitle">
			<!--{if !empty($item[subjectimage])}-->
			<div class="subjectimage">
			<a href="$item[subjectimage]" target="_blank"><img src="$item[subjectimage]"></a>
			</div>
			<!--{/if}-->
			<h1>$item[subject]</h1>
			<!--{if strlen($columnsallinfoarr[corporation][value])>0}-->
			<p>{$columnsallinfoarr[corporation][fieldcomment]}：<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_corporation=<!--{eval echo rawurlencode($columnsallinfoarr[corporation][value]);}-->">$columnsallinfoarr[corporation][value]</a></p>
			<!--{/if}-->
			<!--{if strlen($columnsallinfoarr[corpsize][value])>0}-->
			<p>{$columnsallinfoarr[corpsize][fieldcomment]}：<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_corpsize=<!--{eval echo rawurlencode($columnsallinfoarr[corpsize][value]);}-->">$columnsallinfoarr[corpsize][value]</a></p>
			<!--{/if}-->
			<!--{if strlen($columnsallinfoarr[industry][value])>0}-->
			<p>{$columnsallinfoarr[industry][fieldcomment]}：<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_industry=<!--{eval echo rawurlencode($columnsallinfoarr[industry][value]);}-->">$columnsallinfoarr[industry][value]</a></p>
			<!--{/if}-->
			<!--{if strlen($item[message])>0}-->
			<p>$item[message]</p>
			<!--{/if}-->
		</div>
		<!--{if !empty($ads2['pagecenterad'])}-->
		<div class="admiddle">
			$ads2[pagecenterad]
		</div>
		<!--{/if}-->
		<div class="models-minfield">
			<ul>
				<!--{if strlen($columnsallinfoarr[quantity][value])>0}-->
				<li><strong>{$columnsallinfoarr[quantity][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_quantity=<!--{eval echo rawurlencode($columnsallinfoarr[quantity][value]);}-->">$columnsallinfoarr[quantity][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[seniority][value])>0}-->
				<li><strong>{$columnsallinfoarr[seniority][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_seniority=<!--{eval echo rawurlencode($columnsallinfoarr[seniority][value]);}-->">$columnsallinfoarr[seniority][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[language][value])>0}-->
				<li><strong>{$columnsallinfoarr[language][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_language=<!--{eval echo rawurlencode($columnsallinfoarr[language][value]);}-->">$columnsallinfoarr[language][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[education][value])>0}-->
				<li><strong>{$columnsallinfoarr[education][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_education=<!--{eval echo rawurlencode($columnsallinfoarr[education][value]);}-->">$columnsallinfoarr[education][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[salary][value])>0}-->
				<li><strong>{$columnsallinfoarr[salary][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_salary=<!--{eval echo rawurlencode($columnsallinfoarr[salary][value]);}-->">$columnsallinfoarr[salary][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[jobtype][value])>0}-->
				<li><strong>{$columnsallinfoarr[jobtype][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_jobtype=<!--{eval echo rawurlencode($columnsallinfoarr[jobtype][value]);}-->">$columnsallinfoarr[jobtype][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[province][value])>0}-->
				<li><strong>{$columnsallinfoarr[province][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_province=<!--{eval echo rawurlencode($columnsallinfoarr[province][value]);}-->">$columnsallinfoarr[province][value]</a>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_city=<!--{eval echo rawurlencode($columnsallinfoarr[city][value]);}-->">
				$columnsallinfoarr[city][value]</a></li>
				<!--{/if}-->
				<!--{if strlen($columnsallinfoarr[jobparticular][value])>0}-->
				<li><strong>{$columnsallinfoarr[jobparticular][fieldcomment]}：</strong>
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_jobparticular=<!--{eval echo rawurlencode($columnsallinfoarr[jobparticular][value]);}-->">$columnsallinfoarr[jobparticular][value]</a></li>
				<!--{/if}-->
				<li><strong>发布时间：</strong>#date('Y-n-d', $item["dateline"])#</li>
			</ul>
		</div>

		<!--{if !empty($moreurl)}-->
		<dl class="models-maxfield">
			<dt><a href="$moreurl">查看详情</a></dt>
		</dl>
		<!--{/if}-->

		<!--{if strlen($columnsallinfoarr[introduce][value])>0}-->
		<dl class="models-maxfield">
			<dt>{$columnsallinfoarr[introduce][fieldcomment]}</dt>
			<dd>$columnsallinfoarr[introduce][value]</dd>
		</dl>
		<!--{/if}-->
		<!--{if strlen($columnsallinfoarr[corpinfo][value])>0}-->
		<dl class="models-maxfield">
			<dt>{$columnsallinfoarr[corpinfo][fieldcomment]}</dt>
			<dd>$columnsallinfoarr[corpinfo][value]</dd>
		</dl>
		<!--{/if}-->
		<!--{if strlen($columnsallinfoarr[contactus][value])>0}-->
		<dl class="models-maxfield">
			<dt>{$columnsallinfoarr[contactus][fieldcomment]}</dt>
			<dd>$columnsallinfoarr[contactus][value]</dd>
		</dl>
		<!--{/if}-->

		<!--{if !empty($modelsinfoarr[allowcomment]) && !empty($item[allowreply])}-->
			<!--{if !empty($commentlist)}-->
			<dl class="models-commentlist">
				<h3>最新评论</h3>
				<!--{loop $commentlist $value}-->
				<dt>
					<span style="float: right;">
					<a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#">删除</a> 
					<!--{if !empty($value['message'])}-->
					<a href="javascript:;" onclick="getModelQuote('$modelsinfoarr[modelname]', '$value[cid]')">引用</a>
					<!--{/if}-->
					</span>
					<!--{if empty($value[authorid])}-->
					$value[author]
					<!--{else}-->
					<a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a>
					<!--{/if}-->
					&nbsp; 评论时间 #date("Y-n-d H:i:s", $value["dateline"])#
				</dt>
				<dd>
					<!--{if !empty($value['message'])}-->
					$value[message]
					<!--{/if}-->
				</dd>
				<!--{/loop}-->
			</dl>
			<p class="more"><a href="#action/modelcomment/name/$modelsinfoarr[modelname]/itemid/$item[itemid]#">查看全部评论……</a>(共$item[replynum]条)</p>
			<!--{/if}-->

			<div class="models-commentwrite">
				<h3>我来说两句</h3>
				<form id="postcomm" action="#action/modelcomment/itemid/$item[itemid]/name/$modelsinfoarr[modelname]/php/1#" method="post">
					<p><label for="messagecomm">内 容：</label><textarea id="messagecomm" name="messagecomm"  cols="100%" rows="5"></textarea></p>
					<!--{if empty($_SCONFIG['noseccode'])}-->
					<p><label for="seccode">验 证：</label><input type="text" id="seccode" name="seccode" class="submitcode" value="" size="5" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" /></p>
					<!--{/if}-->
					<!--{if !empty($_SCONFIG['ucmode']) && !empty($_SGLOBAL['supe_uid'])}-->
					<p>加入事件
					<input type="checkbox" name="addfeed"  $addfeedcheck>					
					</p>
					<!--{/if}-->
					<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" class="submitcomm">发表评论</button>
					<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
					<input type="hidden" id="name" name="name" value="nxnaown" /></p>
				</form>
			</div>
		<!--{/if}-->
	</div>
	<div class="models-side">
		<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
		<div class="models-sideblock">
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="信息管理"><img src="$siteurl/$tpldir/images/models_btn_admin.jpg" title="信息管理" /></a>
		</div>
		<!--{/if}-->
		<!--{if $modelsinfoarr[allowpost]}-->
		<div class="models-sideblock">
			<a href="$posturl" title="发布信息"><img src="$siteurl/$tpldir/images/models_btn_vote.jpg" alt="发布信息"/></a>
		</div>
		<!--{/if}-->
		<!-- 用户面板 -->
		<div class="models-sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		<!--{if !empty($gatherarr)}-->
		<!--{loop $gatherarr $key $value}-->
		<!--{if !empty($value)}-->
		<div class="models-sidetags">
			<h3>$cacheinfo[columns][$key][fieldcomment]</h3>
			<p>
				<!--{loop $value $tmpvalue}-->
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$key=<!--{eval echo rawurlencode($tmpvalue);}-->">$tmpvalue</a>
				<!--{/loop}-->
			</p>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
	</div>
</div>
<!--{if !empty($ads2['pagefootad'])}-->
<div class="adfooter">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<!--{if !empty($ads2['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads2['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads2[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads2['pageoutindex'])}-->
$ads2[pageoutindex]
<!--{/if}-->
<!--{eval include template($tpldir.'/footer.html.php', 1);}-->