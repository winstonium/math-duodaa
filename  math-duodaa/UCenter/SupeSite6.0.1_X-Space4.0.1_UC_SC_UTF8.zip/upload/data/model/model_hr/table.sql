DROP TABLE IF EXISTS supe_hritems;
CREATE TABLE supe_hritems (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  catid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  `subject` char(80) NOT NULL default '',
  subjectimage char(80) NOT NULL default '',
  rates smallint(6) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  viewnum mediumint(8) unsigned NOT NULL default '0',
  replynum mediumint(8) unsigned NOT NULL default '0',
  allowreply tinyint(1) NOT NULL default '0',
  grade tinyint(1) NOT NULL default '0',
  corporation char(100) NOT NULL,
  corpsize char(20) NOT NULL,
  industry char(100) NOT NULL,
  province char(9) NOT NULL,
  city char(30) NOT NULL,
  quantity tinyint(3) NOT NULL,
  seniority char(20) NOT NULL,
  `language` char(20) NOT NULL,
  education char(12) NOT NULL,
  salary char(15) NOT NULL,
  introduce char(255) NOT NULL,
  jobtype char(60) NOT NULL,
  PRIMARY KEY  (itemid),
  KEY catid (catid,itemid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_hrmessage;
CREATE TABLE supe_hrmessage (
  nid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  message mediumtext NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  corpinfo mediumtext NOT NULL,
  contactus mediumtext NOT NULL,
  jobparticular varchar(100) NOT NULL,
  PRIMARY KEY  (nid),
  KEY itemid (itemid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_hrcomments;
CREATE TABLE supe_hrcomments (
  cid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (cid),
  KEY itemid (itemid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_hrrates;
CREATE TABLE supe_hrrates (
  rid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (rid),
  KEY itemid (itemid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_hrcategories;
CREATE TABLE supe_hrcategories (
  catid smallint(6) unsigned NOT NULL auto_increment,
  upid smallint(6) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  note text NOT NULL,
  displayorder mediumint(6) unsigned NOT NULL default '0',
  url varchar(200) NOT NULL default '',
  subcatid varchar(200) NOT NULL default '',
  PRIMARY KEY  (catid),
  KEY upid (upid),
  KEY displayorder (displayorder)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_hrfolders;
CREATE TABLE supe_hrfolders (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  uid smallint(8) unsigned NOT NULL default '0',
  `subject` char(80) NOT NULL default '',
  message text NOT NULL,
  dateline int(10) unsigned NOT NULL default '0',
  folder tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (itemid),
  KEY folder (folder,dateline)
) TYPE=MyISAM;

