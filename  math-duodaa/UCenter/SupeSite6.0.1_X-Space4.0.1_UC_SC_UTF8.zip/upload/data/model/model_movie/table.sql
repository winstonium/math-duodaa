DROP TABLE IF EXISTS supe_movieitems;
CREATE TABLE supe_movieitems (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  catid smallint(6) unsigned NOT NULL default '0',
  uid mediumint(8) unsigned NOT NULL default '0',
  tid mediumint(8) unsigned NOT NULL default '0',
  username char(15) NOT NULL default '',
  `subject` char(80) NOT NULL default '',
  subjectimage char(80) NOT NULL default '',
  rates smallint(6) unsigned NOT NULL default '0',
  dateline int(10) unsigned NOT NULL default '0',
  lastpost int(10) unsigned NOT NULL default '0',
  viewnum mediumint(8) unsigned NOT NULL default '0',
  replynum mediumint(8) unsigned NOT NULL default '0',
  allowreply tinyint(1) NOT NULL default '0',
  grade tinyint(1) NOT NULL default '0',
  starring char(40) NOT NULL,
  issue char(20) NOT NULL,
  `language` char(10) NOT NULL,
  region char(20) NOT NULL,
  `time` char(10) NOT NULL,
  color char(12) NOT NULL default '彩色',
  introduction char(255) NOT NULL,
  PRIMARY KEY  (itemid),
  KEY catid (catid,itemid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_moviemessage;
CREATE TABLE supe_moviemessage (
  nid mediumint(8) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  message mediumtext NOT NULL,
  postip varchar(15) NOT NULL default '',
  relativeitemids varchar(255) NOT NULL default '',
  translation varchar(100) NOT NULL,
  director varchar(50) NOT NULL,
  otherstarring varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  stills_1 varchar(150) NOT NULL,
  stills_2 varchar(150) NOT NULL,
  stills_3 varchar(150) NOT NULL,
  url varchar(255) NOT NULL,
  evaluation mediumtext NOT NULL,
  snapshots mediumtext NOT NULL,
  PRIMARY KEY  (nid),
  KEY itemid (itemid)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_moviecomments;
CREATE TABLE supe_moviecomments (
  cid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  message text NOT NULL,
  PRIMARY KEY  (cid),
  KEY itemid (itemid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_movierates;
CREATE TABLE supe_movierates (
  rid int(10) unsigned NOT NULL auto_increment,
  itemid mediumint(8) unsigned NOT NULL default '0',
  authorid mediumint(8) unsigned NOT NULL default '0',
  author varchar(15) NOT NULL default '',
  ip varchar(15) NOT NULL default '',
  dateline int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (rid),
  KEY itemid (itemid,dateline)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_moviecategories;
CREATE TABLE supe_moviecategories (
  catid smallint(6) unsigned NOT NULL auto_increment,
  upid smallint(6) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  note text NOT NULL,
  displayorder mediumint(6) unsigned NOT NULL default '0',
  url varchar(200) NOT NULL default '',
  subcatid varchar(200) NOT NULL default '',
  PRIMARY KEY  (catid),
  KEY upid (upid),
  KEY displayorder (displayorder)
) TYPE=MyISAM;

DROP TABLE IF EXISTS supe_moviefolders;
CREATE TABLE supe_moviefolders (
  itemid mediumint(8) unsigned NOT NULL auto_increment,
  uid smallint(8) unsigned NOT NULL default '0',
  `subject` char(80) NOT NULL default '',
  message text NOT NULL,
  dateline int(10) unsigned NOT NULL default '0',
  folder tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (itemid),
  KEY folder (folder,dateline)
) TYPE=MyISAM;

