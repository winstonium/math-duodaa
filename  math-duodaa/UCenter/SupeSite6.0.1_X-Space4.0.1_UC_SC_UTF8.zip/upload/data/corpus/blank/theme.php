<?php

$themes = array(
	'name'		=> '白底黑字',
	'preview'	=> ''
);

?>