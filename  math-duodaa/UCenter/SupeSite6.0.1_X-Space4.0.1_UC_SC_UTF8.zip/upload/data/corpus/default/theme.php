<?php

$themes = array(
	'name'		=> '蓝色经典',
	'thumb'	=> 'header.jpg'
);

?>