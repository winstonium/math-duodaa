<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	�ҵ�Ȧ��

	$RCSfile: mygroup.php,v $
	$Revision: 1.38 $
	$Date: 2007/06/27 17:15:08 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

//NO HTML
$_SCONFIG['htmlmygroup'] = 0;
$_SCONFIG['htmlmygrouptime'] = 7200;

$gid = $_SGET['gid'] = empty($_SGET['gid'])?0:intval($_SGET['gid']);

$grouparr = array();
if(!empty($gid)) {
	dbconnect();
	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('groups').' g LEFT JOIN '.tname('groupfields').' gf ON gf.gid=g.gid WHERE g.gid=\''.$gid.'\'');
	$grouparr = $_SGLOBAL['db']->fetch_array($query);
	$grouparr['intro'] = tobr($grouparr['intro']);
	$grouparr['announcements'] = tobr($grouparr['announcements']);
	$grouparr['selfintro'] = tobr($grouparr['selfintro']);
}
if(empty($grouparr)) messagebox('error', 'not_found');

if($grouparr['flag'] == 0) {
	getcookie(1);
	if($_SGLOBAL['group']['groupid'] != 1) messagebox('error', 'group_being_audited');
}

//ֻ��Ȧ���˽���
if($grouparr['ispublic'] == 0 ) {
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) {
		setcookie('_refer', geturl('action/mygroup/gid/'.$gid));
		messagebox('error', 'no_login', geturl('action/login'));
	}
	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groupuid').' WHERE gid=\''.$_SGET['gid'].'\' AND uid=\''.$_SGLOBAL['supe_uid'].'\' AND flag>\'0\'');
	$count = $_SGLOBAL['db']->result($query, 0);
	if($_SGLOBAL['member']['groupid'] != 1 && !$count) {
		messagebox('error', $lang['open_to_restrictions'].'<br><a href="javascript:;" id="msg-joingroup" onclick="javascript:joingroup(\''.$_SGET['gid'].'\');">'.$lang['join_group'].'</a>');
	}
	$_SCONFIG['htmlmygroup'] = 0;

//��Ҫ����
} elseif($grouparr['ispublic'] == 2) {
	getcookie(1);
	if($_SGLOBAL['member']['groupid'] != 1 && (empty($_COOKIE[$cookiepre.'gidpw'.$_SGET['gid']]) || $_COOKIE[$cookiepre.'gidpw'.$_SGET['gid']] != $grouparr['password'])) {
		$showtext = '<table>
			<form action="'.S_URL.'/batch.common.php?action=checkgwd" method="post">
			<tr><td>'.$lang['visit_input_passwords'].':</td></tr>
			<tr><td>
			<input type="password" name="pwd" size="12" />
			<input type="hidden" name="gid" value="'.$_SGET['gid'].'" />
			<button type="submit" name="pwdsubmit" value="true">'.$lang['enter_the_group'].'</button>
			</td></tr>
			</form>
			</table>';
		messagebox('error', $showtext);
	}
	$_SCONFIG['htmlmygroup'] = 0;
}

//logo
if(empty($grouparr['logo'])) {
	$grouparr['logo'] = S_URL.'/images/base/nopic.gif';
} else {
	$grouparr['logo'] = A_URL.'/'.$grouparr['logo'];
}
if(empty($grouparr['headerimage'])) {
	$grouparr['headerimage'] = S_URL.'/images/base/groupnopic.gif';
} else {
	$grouparr['headerimage'] = A_URL.'/'.$grouparr['headerimage'];
}

if($_SCONFIG['urltype'] == 3) {
	$grouparr['domain'] = S_URL_ALL.'/mygroup-'.$_SGET['gid'];
} else {
	$grouparr['domain'] = S_URL_ALL.'/?mygroup-'.$_SGET['gid'];
}

//��������
$_SGET['op'] = empty($_SGET['op'])?'':'list';
if(empty($_SGET['op'])) {
	//��ҳ
	$_SGET['type'] = $_SGET['page'] = '';
} else {
	//�б�
	$_SGET['op'] = 'list';
	if(empty($_SGET['type'])) $_SGET['type'] = '';
	if(!in_array($_SGET['type'], array('recommend', 'digest', 'members', 'bbs'))) $_SGET['type'] = '';
	$_SGET['page'] = empty($_SGET['page'])?1:intval($_SGET['page']);
	if(!empty($_SCONFIG['ucmode']) && $_SGET['type'] == 'bbs') $_SGET['type'] = '';
	if(empty($_SCONFIG['ucmode']) && $_SGET['type'] == 'bbs') {
		//��̳���
		$_SGET['fid'] = empty($_SGET['fid'])?0:intval($_SGET['fid']);
		if(empty($_SGET['fid'])) {
			$_SGET['page'] = 0;
		} else {
			dbconnect(1);
			$query = $_SGLOBAL['db_bbs']->query("SELECT fid, name FROM ".tname('forums', 1)." WHERE fid='$_SGET[fid]' AND status='2'");
			$forum = $_SGLOBAL['db_bbs']->fetch_array($query);
			if(!$forum) {
				$_SGET['fid'] = 0;
			}
		}
	} else {
		$_SGET['fid'] = 0;
	}
}

//htmlԤ����
if(!empty($_SCONFIG['htmlmygroup'])) {
	$_SHTML['action'] = 'mygroup';
	$_SHTML['gid'] = $gid;
	if(!empty($_SGET['op'])) {
		$_SHTML['op'] = 'list';
		if(!empty($_SGET['type'])) $_SHTML['type'] = $_SGET['type'];
		if(!empty($_SGET['fid'])) $_SHTML['fid'] = $_SGET['fid'];
		if(!empty($_SGET['page'])) $_SHTML['page'] = intval($_SGET['page']);
	}
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SHTML, $_SCONFIG['htmlmygrouptime']);
	$_SCONFIG['debug'] = 0;
}

include_once('./include/common.inc.php');

$title = $grouparr['groupname'].' - '.$_SCONFIG['sitename'];
$keywords = $grouparr['groupname'];
$description = $grouparr['groupname'];

if($_SGET['op'] == 'list') {
	$tplname = 'mygroup_list';
} else {
	$tplname = 'mygroup_index';
}
include template($tplname);

ob_out();

if(!empty($_SCONFIG['htmlmygroup'])) {
	ehtml('make');
} else {
	maketplblockvalue('cache');
}

function tobr($message) {
	return preg_replace("/(\r\n|\r|\n)/s", '<br>', $message);
}
?>
