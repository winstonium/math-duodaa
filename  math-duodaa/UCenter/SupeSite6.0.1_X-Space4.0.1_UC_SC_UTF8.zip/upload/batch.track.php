<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���½�ӡ

	$RCSfile: batch.track.php,v $
	$Revision: 1.11 $
	$Date: 2007/03/16 22:10:25 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
if(empty($itemid)) exit('Access Denied');

if(!empty($_GET['action'])) {
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) showxml($blang['the_operation_can_be_carried_out_by_logging']);
	$_SGLOBAL['db']->query('DELETE FROM '.tname('tracks').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\' AND itemid=\''.$itemid.'\'');
	showxml($blang['footprints_were_removed']);
}

include_once(S_ROOT.'./include/common.inc.php');

dbconnect();
$trackarr = array();
//���500
$query = $_SGLOBAL['db']->query('SELECT u.*, tr.dateline, tr.uid FROM '.tname('tracks').' tr LEFT JOIN '.tname('userspaces').' u ON u.uid=tr.uid WHERE tr.itemid=\''.$itemid.'\' LIMIT 0,500');
while ($value = $_SGLOBAL['db']->fetch_array($query)) {
	$value['photo'] = getphoto($value['uid'], $value['photo']);
	if(empty($value['username'])) {
		$value['username'] = "member({$value[uid]})";
	}
	$value['url'] = geturl("uid/$value[uid]");
	$trackarr[] = $value;
}

$guidearr = array();
$guidearr[] = array('url' => S_URL.'/batch.track.php?itemid='.$itemid, 'name' => $blang['detect_footprints']);
$channelmenu = $showmenu = array();

$title = $blang['detect_footprints'];

include template('site_track');

?>