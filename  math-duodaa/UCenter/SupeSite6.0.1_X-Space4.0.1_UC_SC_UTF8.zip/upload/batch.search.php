<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��������

	$RCSfile: batch.search.php,v $
	$Revision: 1.36 $
	$Date: 2007/06/19 20:04:39 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./include/common.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$perpage = 100;
$urlplus = $wheresql = $message = $multipage = '';
$wherearr = $iarr = array();

empty($_GET['page'])?$page = 1:$page = intval($_GET['page']);
$start = ($page-1)*$perpage;

$subjectsearch = postget('subjectsearch');	//��ȡ����������ťֵ
$authorsearch = postget('authorsearch');	//��ȡ����������ťֵ
$messagesearch = postget('messagesearch');	//��ȡ����������ťֵ
$usersearch = postget('usersearch');	//��ȡ��Ա������ťֵ
$groupsearch = postget('groupsearch');	//��ȡȦ��������ťֵ
$goodscitysearch = postget('goodscitysearch');

if($subjectsearch || $authorsearch || $messagesearch || $usersearch || $goodscitysearch || $groupsearch) {
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid']) && empty($_SCONFIG['allowguestsearch'])) {
		messagebox('error', 'the_system_does_not_allow_searches', geturl('action/login'));
	}
	if(!empty($_SCONFIG['searchinterval']) && $_SGLOBAL['group']['groupid'] != 1) {
		if($_SGLOBAL['timestamp'] - $_SGLOBAL['member']['lastsearchtime'] < $_SCONFIG['searchinterval']) {
			messagebox('error', 'inquiries_about_the_short_time_interval');
		}
	}
}

if(!empty($subjectsearch) || !empty($authorsearch)) {
	$searchkey = checkkey('searchkey', 1);
	$type = postget('type');
	if(!in_array($type, $_SGLOBAL['type'])) $type = '';
	//��Ϸ�ҳ�Ĳ���
	$urlplus = 'searchkey='.rawurlencode($searchkey).'&type='.rawurlencode($type);

	if(!empty($type)) $wherearr[] = 'type=\''.$type.'\'';
	$wherearr[] = 'folder=\'1\'';
	if(!empty($subjectsearch)) {
		$wherearr[] = 'subject LIKE \'%'.$searchkey.'%\'';
		$urlplus .= '&subjectsearch=1';
	} else {
		$wherearr[] = 'username LIKE \'%'.$searchkey.'%\'';
		$urlplus .= '&authorsearch=1';
	}
	$wheresql = implode(' AND ', $wherearr);	//������������
	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('spaceitems').' WHERE '.$wheresql);	//ͳ�Ƽ�¼��
	$listcount = $_SGLOBAL['db']->result($query, 0);
	if($listcount) {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' WHERE '.$wheresql.' LIMIT '.$start.','.$perpage);
		while ($item = $_SGLOBAL['db']->fetch_array($query)) {
			if($item['type'] == 'news') {
				$item['url'] = geturl('action/viewnews/itemid/'.$item['itemid']);
			} else {
				$item['url'] = geturl('uid/'.$item['uid'].'/action/viewspace/itemid/'.$item['itemid']);
			}
			$iarr[] = $item;
		}
		$multipage = multi($listcount, $perpage, $page, S_URL.'/batch.search.php?'.$urlplus);	//��ҳ
	} else {
		messagebox('ok', 'not_find_relevant_data');
	}
} else if(!empty($messagesearch)) {
	$searchkey = checkkey('searchkey', 1);

	$type = postget('type');
	if(empty($type) || !in_array($type, $_SGLOBAL['type'])) {
		messagebox('error', 'search_types_of_incorrect_information');
	}
	//��Ϸ�ҳ�Ĳ���
	$urlplus = 'searchkey='.rawurlencode($searchkey).'&type='.rawurlencode($type).'&messagesearch=1';

	$wherearr[] = 'i.type=\''.$type.'\'';
	$wherearr[] = 't.itemid = i.itemid';
	$wherearr[] = 't.message LIKE \'%'.$searchkey.'%\'';

	$tablename = gettypetablename($type);
	
	$wheresql = implode(' AND ', $wherearr);	//������������
	
	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('spaceitems').' i, '.tname($tablename).' t WHERE '.$wheresql);
	$listcount = $_SGLOBAL['db']->result($query, 0);
	if($listcount) {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' i, '.tname($tablename).' t WHERE '.$wheresql.' LIMIT '.$start.','.$perpage);
		while ($item = $_SGLOBAL['db']->fetch_array($query)) {
			if($item['type'] == 'news') {
				$item['url'] = geturl('action/viewnews/itemid/'.$item['itemid']);
			} else {
				$item['url'] = geturl('uid/'.$item['uid'].'/action/viewspace/itemid/'.$item['itemid']);
			}
			$iarr[] = $item;
		}
		$multipage = multi($listcount, $perpage, $page, S_URL.'/batch.search.php?'.$urlplus);
	} else {
		messagebox('ok', 'not_find_relevant_data');
	}
}else if(!empty($usersearch)) {

	$interest = $native = array();
	$username = checkkey('username');
	$spacename = checkkey('spacename');
	$province = checkkey('province');
	$city = checkkey('city');

	
	$plusarr = $where1arr = array();
	
	if(!empty($username)) {
		$plusarr[] = 'username='.rawurlencode($username);
		$where1arr[] = 'u.username LIKE \'%'.$username.'%\'';
	}
	if(!empty($spacename)) {
		$plusarr[] = 'spacename='.rawurlencode($spacename);
		$where1arr[] = 'u.spacename LIKE \'%'.$spacename.'%\'';
	}
	if(!empty($province)) {
		$plusarr[] = 'province='.rawurlencode($province);
		$where1arr[] = 'u.province = \''.$province.'\'';
	}
	if(!empty($city)) {
		$plusarr[] = 'city='.rawurlencode($city);
		$where1arr[] = 'u.city = \''.$city.'\'';
	}

	//ȡ���Զ��ֶ�
	$query = $_SGLOBAL['db']->query('SELECT proid,selective FROM '.tname('userprofile').' WHERE available > 0 ORDER BY displayorder');
	while ($fields = $_SGLOBAL['db']->fetch_array($query)) {
		$proval = checkkey('profile_'.$fields['proid']);
		if(!empty($proval)) {
			if(is_array($proval)) {
				$proval = implode(',', $proval);
			}
			$plusarr[] = 'profile_'.$fields['proid'].'='.rawurlencode($proval);
			if($fields['selective'] == 2) {
				if(!empty($_POST['profile_'.$fields['proid']])) {
					$profilearr = array();
					$profile = explode(',', $proval);
					foreach($profile as $val) {
						$profilearr[] = 'f.profile_'.$fields['proid'].' LIKE \'%'.$val.'%\'';
					}
					if(!empty($profilearr)) $wherearr[] = '('.implode(' OR ', $profilearr).')';
					
				}
			} else {
				$wherearr[] = 'f.profile_'.$fields['proid'].' = \''.$proval.'\'';
			}
		}
	}
	$countsql = $listsql = '';

	if(!empty($wherearr)) {
		$wherearr = array_merge ($wherearr, $where1arr);
		if(empty($wherearr)) messagebox('error', 'at_least_one_of_the_conditions_for_inquiry');
		$wherearr[] = 'f.uid=u.uid';
		$wheresql = implode(' AND ', $wherearr);
		$countsql = 'SELECT COUNT(*) FROM '.tname('userspaces').' u, '.tname('userfields').' f WHERE '.$wheresql;
		$listsql = 'SELECT * FROM '.tname('userspaces').' u, '.tname('userfields').' f WHERE '.$wheresql.' LIMIT '.$start.','.$perpage;
	} else {
		if(empty($where1arr)) messagebox('error', 'at_least_one_of_the_conditions_for_inquiry');
		$wheresql = implode(' AND ', $where1arr);
		$countsql = 'SELECT COUNT(*) FROM '.tname('userspaces').' u  WHERE '.$wheresql;
		$listsql = 'SELECT * FROM '.tname('userspaces').' u WHERE '.$wheresql.' LIMIT '.$start.','.$perpage;
	}

	$plusarr[] = 'usersearch=1';
	if(!empty($plusarr)) {
		$urlplus = implode('&', $plusarr);
	}
	$query = $_SGLOBAL['db']->query($countsql);
	$listcount = $_SGLOBAL['db']->result($query, 0);
	if($listcount) {
		$query = $_SGLOBAL['db']->query($listsql);
		while ($item = $_SGLOBAL['db']->fetch_array($query)) {
			$item['url'] = geturl('uid/'.$item['uid']);
			$iarr[] = $item;
		}
		$multipage = multi($listcount, $perpage, $page, S_URL.'/batch.search.php?'.$urlplus);
	} else {
		messagebox('ok', 'not_find_relevant_data');
	}
	
}else if(!empty($goodscitysearch)) {
	
	$province = checkkey('province');
	$city = checkkey('city');
	$plusarr = array();
	$wherearr[] = 'i.type=\'goods\'';
	$wherearr[] = 'g.itemid=i.itemid';
	if(!empty($province)) {
		$plusarr[] = 'province='.rawurlencode($province);
		$wherearr[] = 'g.province = \''.$province.'\'';
	}
	if(!empty($city)) {
		$plusarr[] = 'city='.rawurlencode($city);
		$wherearr[] = 'g.city = \''.$city.'\'';
	}
	$plusarr[] = 'goodscitysearch=1';
	$wheresql = implode(' AND ', $wherearr);

	if(!empty($plusarr)) {
		$urlplus = implode('&', $plusarr);
	}
	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('spaceitems').' i, '.tname('spacegoods').' g WHERE '.$wheresql);
	$listcount = $_SGLOBAL['db']->result($query, 0);
	if($listcount) {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' i, '.tname('spacegoods').' g WHERE '.$wheresql.' LIMIT '.$start.','.$perpage);
		while ($item = $_SGLOBAL['db']->fetch_array($query)) {
			$item['url'] = geturl('uid/'.$item['uid'].'/action/viewspace/itemid/'.$item['itemid']);
			$iarr[] = $item;
		}
		$multipage = multi($listcount, $perpage, $page, S_URL.'/batch.search.php?'.$urlplus);
	} else {
		messagebox('ok', 'not_find_relevant_data');
	}
} elseif (!empty($groupsearch)) {
	$searchkey = checkkey('searchkey', 1);


	//��Ϸ�ҳ�Ĳ���
	$urlplus = 'searchkey='.rawurlencode($searchkey);
	
	if(!empty($groupsearch)) {
		$wherearr[] = 'groupname LIKE \'%'.$searchkey.'%\'';
		$urlplus .= '&groupsearch=1';
	}
	$wherearr[] = 'flag=\'1\'';
	$wheresql = implode(' AND ', $wherearr);	//������������
	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groups').' WHERE '.$wheresql);	//ͳ�Ƽ�¼��
	$listcount = $_SGLOBAL['db']->result($query, 0);
	if($listcount) {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('groups').' WHERE '.$wheresql.' LIMIT '.$start.','.$perpage);
		while ($item = $_SGLOBAL['db']->fetch_array($query)) {
			$item['url'] = geturl('action/mygroup/gid/'.$item['gid']);
			$iarr[] = $item;
		}
		$multipage = multi($listcount, $perpage, $page, S_URL.'/batch.search.php?'.$urlplus);	//��ҳ
	} else {
		messagebox('ok', 'not_find_relevant_data');
	}
}

if(empty($iarr)) {
	$requiredselect = $requiredtext = '';
	$fieldarr = $requiredjs = array();
	$query = $_SGLOBAL['db']->query('SELECT proid, title, description, selective, choices, required FROM '.tname('userprofile').' WHERE available > 0 ORDER BY displayorder');
	while ($fields = $_SGLOBAL['db']->fetch_array($query)) {
		$fieldarr['profile_'.$fields['proid']] = array(
		'title' => $fields['title'],
		'description' => $fields['description'],
		'selective' => $fields['selective'],
		'choices' => $fields['choices'],
		'required' => $fields['required']
		);
	}
	if ($fieldarr) {
		foreach ($fieldarr as $key => $fields) {

			if ($fields['selective']) {
				if($fields['selective'] == 1) {
					$selective = '<select name="'.$key.'" id="'.$key.'">';
					$selective .= '<option value="">------------</option>';
					foreach (explode("\n", $fields['choices']) as $item) {
						list($index, $choice) = explode('=', $item);
						$selective .='<option value="'.trim($index).'">'.trim($choice).'</option>';
					}
					$selective .= '</select>';
				} elseif ($fields['selective'] == 2) {
					$selective = '';
					foreach (explode("\n", $fields['choices']) as $item) {
						list($index, $choice) = explode('=', $item);

						$selective .='<input name="'.$key.'[]" type="checkbox" value="'.trim($index).'" />'.trim($choice).'&nbsp;';
					}
				}
				$requiredselect .= '<div><label for="'.$key.'">'.$fields['title'].'</label>'.$selective.'</div>';
			} else {
				unset($fields['choices']);
				$requiredtext .= '<div><label for="'.$key.'">'.$fields['title'].'</label><input type="text" value="" id="'.$key.'" name="'.$key.'" /></div>';
			}
		}
	}
} else {
	//��������ʱ��
	$_SGLOBAL['db']->query('UPDATE '.tname('members').' SET lastsearchtime=\''.$_SGLOBAL['timestamp'].'\' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
}

//����������ʾ
$title = $blang['search'];

//Ƶ��
$channels = getchannels();
if(!empty($channels['types']['topic'])) unset($channels['types']['topic']);
include_once(template('site_search'));

function checkkey($str, $ischeck=0) {
	$str = stripsearchkey(postget($str));
	if($ischeck) {
		if(empty($str)) {
			messagebox('error', 'keyword_import_inquiry', S_URL.'/batch.search.php');
		}elseif(strlen($str) < 2) {
			messagebox('error', 'kwyword_import_short', S_URL.'/batch.search.php');
		}
	}
	return $str;
}
?>