<?php
$siteurl = $_GET['siteurl'];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Face</TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<meta http-equiv="content-type" content="text/html; charset=gb2312">
<style type="text/css">
body{
	overflow:hidden;
	margin:0px;
	padding:0px;
	padding-top:1px;
	background:url("bgcolor.gif")
}
</style>
<script language="JavaScript">
<!--
function insertStr(sAction) {
	var siteUrl = unescape("<?=$siteurl?>");
	var FacePath = siteUrl + "/images/edit/face/";
	if(window.Event){
		var oRTE = opener.getFrameNode(opener.sRTE);
	}
	else {
		var oRTE = dialogArguments.getFrameNode(dialogArguments.sRTE);
		
	}
	oRTE.focus();
	oRTE.document.execCommand("InsertImage", false, FacePath + sAction +".gif");
	oRTE.focus();
	window.close();
}
//-->
</script>
</HEAD>
<BODY>
<center>
  <img border="0" src="ubb.gif" usemap="#Map" align="center" />
</center>
<map name="Map">
  <area shape="rect" coords="246,83,272,107" onclick="insertStr('040');">
  <area shape="rect" coords="219,83,245,107" onclick="insertStr('039');">
  <area shape="rect" coords="192,83,218,107" onclick="insertStr('038');">
  <area shape="rect" coords="165,83,191,107" onclick="insertStr('037');">
  <area shape="rect" coords="138,83,164,107" onclick="insertStr('036');">
  <area shape="rect" coords="111,83,137,107" onclick="insertStr('035');">
  <area shape="rect" coords="84,83,110,107" onclick="insertStr('034');">
  <area shape="rect" coords="57,83,83,107" onclick="insertStr('033');">
  <area shape="rect" coords="30,83,56,107" onclick="insertStr('032');">
  <area shape="rect" coords="3,83,29,107" onclick="insertStr('031');">
  <area shape="rect" coords="246,56,272,80" onclick="insertStr('030');">
  <area shape="rect" coords="219,56,245,80" onclick="insertStr('029');">
  <area shape="rect" coords="192,56,218,80" onclick="insertStr('028');">
  <area shape="rect" coords="165,56,191,80" onclick="insertStr('027');">
  <area shape="rect" coords="138,56,164,80" onclick="insertStr('026');">
  <area shape="rect" coords="111,56,137,80" onclick="insertStr('025');">
  <area shape="rect" coords="84,56,110,80" onclick="insertStr('024');">
  <area shape="rect" coords="57,56,83,80" onclick="insertStr('023');">
  <area shape="rect" coords="30,56,56,80" onclick="insertStr('022');">
  <area shape="rect" coords="3,56,29,80" onclick="insertStr('021');">
  <area shape="rect" coords="246,30,272,54" onclick="insertStr('020');">
  <area shape="rect" coords="219,30,245,54" onclick="insertStr('019');">
  <area shape="rect" coords="192,30,218,54" onclick="insertStr('018');">
  <area shape="rect" coords="165,30,191,54" onclick="insertStr('017');">
  <area shape="rect" coords="138,30,164,54" onclick="insertStr('016');">
  <area shape="rect" coords="111,30,137,54" onclick="insertStr('015');">
  <area shape="rect" coords="84,30,110,54" onclick="insertStr('014');">
  <area shape="rect" coords="57,30,83,54" onclick="insertStr('013');">
  <area shape="rect" coords="30,30,56,54" onclick="insertStr('012');">
  <area shape="rect" coords="3,30,29,54" onclick="insertStr('011');">
  <area shape="rect" coords="246,4,272,28" onclick="insertStr('010');">
  <area shape="rect" coords="219,4,245,28" onclick="insertStr('009');">
  <area shape="rect" coords="192,4,218,28" onclick="insertStr('008');">
  <area shape="rect" coords="165,4,191,28" onclick="insertStr('007');">
  <area shape="rect" coords="138,4,164,28" onclick="insertStr('006');">
  <area shape="rect" coords="111,4,137,28" onclick="insertStr('005');">
  <area shape="rect" coords="84,4,110,28" onclick="insertStr('004');">
  <area shape="rect" coords="57,4,83,28" onclick="insertStr('003');">
  <area shape="rect" coords="30,4,56,28" onclick="insertStr('002');">
  <area shape="rect" coords="3,4,29,28" onclick="insertStr('001');">
</map>
</BODY>
</HTML>
