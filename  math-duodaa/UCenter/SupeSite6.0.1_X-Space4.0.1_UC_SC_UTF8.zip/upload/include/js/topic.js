var userAgent = navigator.userAgent.toLowerCase();
var is_opera = (userAgent.indexOf('opera') != -1);
var is_saf = ((userAgent.indexOf('applewebkit') != -1) || (navigator.vendor == 'Apple Computer, Inc.'));
var is_webtv = (userAgent.indexOf('webtv') != -1);
var is_ie = ((userAgent.indexOf('msie') != -1) && (!is_opera) && (!is_saf) && (!is_webtv));
var is_ie4 = ((is_ie) && (userAgent.indexOf('msie 4.') != -1));
var is_moz = ((navigator.product == 'Gecko') && (!is_saf));
var is_kon = (userAgent.indexOf('konqueror') != -1);
var is_ns = ((userAgent.indexOf('compatible') == -1) && (userAgent.indexOf('mozilla') != -1) && (!is_opera) && (!is_webtv) && (!is_saf));
var is_ns4 = ((is_ns) && (parseInt(navigator.appVersion) == 4));
var is_mac = (userAgent.indexOf('mac') != -1);
var is_ff = (userAgent.indexOf('firefox') != -1);

var _Event = new Moz_event();
var Drag = new Drag_Events();
is_moz = is_moz || is_opera;

var t_i = t_no = t_col = t_lastelement = t_lasttpltype = 0;

function Moz_event() {
	this.srcElement = null,
	this.setEvent = function(e) {
		_Event.srcElement = e.target;
		_Event.clientX = e.clientX;
		_Event.clientY = e.clientY;
	}
}

function Drag_Events() {
	this.dragged = false;
	this.obj = null;
	this.tdiv = null;
	this.rootTable = null;
	this.layout = null;
	this.disable = null;
	this.getEvent = function() {
		if(is_ie) {
			return event;
		} else if(is_moz) {
			return _Event;
		}
	}

	this.init = function() {
		if(is_moz) {
			document.body.setAttribute("onMouseMove", "_Event.setEvent(event);");
			document.body.setAttribute("onMouseUp", "_Event.setEvent(event);");
		}
	}

	this.getInfo = function(o) {
		var to = new Object();
		to.left = to.right = to.top = to.bottom = 0;
		var twidth = o.offsetWidth;
		var theight = o.offsetHeight;
		while(o) {
			to.left += o.offsetLeft;
			to.top += o.offsetTop;
			o = o.offsetParent;
		}

		to.right = to.left + twidth;
		to.bottom = to.top + theight;
		return to;
	}
}

function $(id){
	return document.getElementById(id);
}

function setdisplay(id, elementid, tpltype) {
	dobj = $('setlayoutstyle');
	if(id != null) {
		t_col = id;
		t_no = id.split('_');
		t_no = t_no[1];
	}
	if(dobj.style.display == 'none') {
		dobj.style.display = '';
		dobj.style.left = Drag.getInfo(Drag.getEvent().srcElement).left+300 > document.body.scrollWidth ? (Drag.getInfo(Drag.getEvent().srcElement).left-350) + 'px' : (Drag.getInfo(Drag.getEvent().srcElement).left+5) + 'px';
		dobj.style.top = (Drag.getInfo(Drag.getEvent().srcElement).top+10) + 'px';
		if(elementid != null) {	//编辑
			$('step_2_4').style.display = '';
			$('step_2').style.display = '';
			$('title').value = $(elementid+'_t').innerHTML;
			$('step_1').style.display = 'none';

			t_lastelement = elementid;
			t_lasttpltype = tpltype;
		}
	} else {
		lastelement = t_lastelement;
		
		if(window.parent.$(lastelement) != null) {
			idarr = window.parent.$(lastelement).value.split(',');
			newid = '';
			elementinfo = idarr[0].split('|');
			newid += elementinfo[0] + '|' + elementinfo[1] + '|' + $(lastelement+'_t').innerHTML;
			for(i = 1; i < idarr.length; i++) {
				newid += ','+idarr[i];
			}
			window.parent.$(lastelement).value = newid;
		}

		dobj.style.display = 'none';
		displaystep(1, 1);
		$('step_2_4').style.display = 'none';
		$('title').value = '';
		$('searchkey').value = '';
		$('searchresult').innerHTML = '';
		$('searchpage').innerHTML = '';
	}
	window.parent.loadwindow();
}

function removeelement(elementid, id) {
	obj = $(elementid);
	obj.parentNode.removeChild(obj);
	
	if(id == null) {
		obj = window.parent.$(elementid);
		obj.parentNode.removeChild(obj);
	} else {
		elementid = elementid.slice(0, elementid.lastIndexOf('_'));
		obj = window.parent.$(elementid);
		idarr = obj.value.split(',');
		newid = '';
		for(i = 1; i < idarr.length; i++) {
			if(idarr[i] != id) newid += ',' + idarr[i];
		}
		obj.value = idarr[0] + newid;
	}
	
	window.parent.loadwindow();
}

function elementtitle() {
	lastelement = t_lastelement;
	obj = $(lastelement+'_t');
	obj.innerHTML = $('title').value;
}

//通过提交按钮的搜索
function searchsubmit(obj) {
	getdata = 'searchkey=' + encodeURIComponent(obj.searchkey.value) + '&channel=' + obj.channel.value + '&type=' + obj.ss_type.value + '&page=1';
	return search(getdata);
}

function searchclick(getdata) {
	return search(getdata);
}

function search(getdata) {
	var x = new Ajax('statusid', 'XML');
	if(getdata == null) getdata = '';
	displaystep(3, 1);
	$('step_4').style.display = '';
	$('step_img_4').src = siteUrl + '/admin/images/btn_open.gif';
	x.get(siteUrl+'/admincp.php?action=topics&op=search&' + getdata, function(s) {
		var result = '<ul class="search">';
		var searchpage = '';
		if(gettagvalue(s, 'totail', 0) != 0) {
			for(i = 0; i < s.getElementsByTagName('subject').length; i++) {
				var objinfo = {
					itemid: gettagvalue(s, 'itemid', i),
					catid: gettagvalue(s, 'catid', i),
					catname: gettagvalue(s, 'catname', i),
					uid: gettagvalue(s, 'uid', i),
					username: gettagvalue(s, 'username', i),
					type: gettagvalue(s, 'type', i),
					typename: gettagvalue(s, 'typename', i),
					subject: gettagvalue(s, 'subject', i),
					dateline: gettagvalue(s, 'dateline', i),
					lastpost: gettagvalue(s, 'lastpost', i),
					viewnum: gettagvalue(s, 'viewnum', i),
					replynum: gettagvalue(s, 'replynum', i),
					hash: gettagvalue(s, 'hash', i),
					haveattach: gettagvalue(s, 'haveattach', i),
					haveimg: gettagvalue(s, 'haveimg', i),
					link: gettagvalue(s, 'link', i),
					img: gettagvalue(s, 'img', i)
				};
				var info = '';
				for(var itm in objinfo) {
					info += '' +itm + '#@#' + objinfo[itm] + '#|#';
				}
				info = info.replace(/\"/g, '&quot;');
				result += '<li>';
				if(parseInt(objinfo.haveimg) == 1) result += '<img src="'+siteUrl+'/images/base/image.gif">';
				result += '<a href="javascript:;" onclick="elementcontent(\''+info+'\');">'+objinfo.subject+'</a></li>';
			}
			var totail = parseInt(gettagvalue(s, 'totail', 0));
			var currently = parseInt(gettagvalue(s, 'currently', 0));
			var begin = parseInt(gettagvalue(s, 'begin', 0));
			var end = parseInt(gettagvalue(s, 'end', 0));
			var urlplus = gettagvalue(s, 'urlplus', 0);
			var currentlystyle = '';
			
			searchpage += '<a href="javascript:;" onclick="return searchclick(\''+urlplus+'&page='+(currently-1)+'\');">上页</a> ';
			for(i = begin; i <= end; i++) {
				currentlystyle = '';
				if(i == currently) currentlystyle = 'style="font-weight: bold;"';
				searchpage += '<a href="javascript:;" onclick="return searchclick(\''+urlplus+'&page='+i+'\');" '+currentlystyle+'>'+i+'</a> ';
			}
			searchpage += '<a href="javascript:;" onclick="return searchclick(\''+urlplus+'&page='+(currently+1)+'\');">下页</a> ';
			searchpage += '共'+totail+'页';
			
		} else {
			result += '<li>'+gettagvalue(s, 'info', 0)+'</li>';
		}

		result += '</ul>';
		$('searchresult').innerHTML = result;
		$('searchpage').innerHTML = searchpage;
	});
	return false;
}

function gettagvalue(html, tagname, element) {
	if(html.getElementsByTagName(tagname)[element].firstChild != null) return html.getElementsByTagName(tagname)[element].firstChild.nodeValue;
	else return '';
}

//元素面板步骤
function displaystep(id, open) {
	for(i = 1; i <= 4; i++) {
		if(i != id || ($('step_' + id).style.display == '' && open == null)) {
			$('step_' + i).style.display = 'none';
			$('step_img_' + i).src = siteUrl + '/admin/images/btn_close.gif';
		} else {
			$('step_' + id).style.display = '';
			$('step_img_' + id).src = siteUrl + '/admin/images/btn_open.gif';
		}
	}
}

function drag(o){
    o.onmousedown = function(a){
        var d = document;
        if(!a) a = window.event;
        if(o.setCapture)
            o.setCapture();
        else if(window.captureEvents)
            window.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);

		var re = new RegExp("px","ig");
		//计算当前鼠标的坐标点离日期采集器层的零点坐标的Ｘ间距
        var x = (a.pageX?a.pageX:a.x) - parseInt(o.style.left.replace(re,""));
        //计算当前鼠标的坐标点离日期采集器层的零点坐标的Y间距
        var y = (a.pageY?a.pageY:a.y) - parseInt(o.style.top.replace(re,""));
        
        d.onmousemove = function(a){
            if(!a)a=window.event;
            if(!a.pageX)a.pageX=a.clientX;
            if(!a.pageY)a.pageY=a.clientY;
            var tx=a.pageX-x,ty=a.pageY-y;
            o.style.left = tx + "px";
            o.style.top = ty + "px";
        };
        
        d.onmouseup=function(){
            if(o.releaseCapture)
                o.releaseCapture();
            else if(window.captureEvents)
                window.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);
            d.onmousemove=null;
            d.onmouseup=null;
        };
    };
}

function addselectnodebyclass(nodename, valuearr, textarr, selected) {
	obj = document.getElementById(nodename);
	ii = 0;
	if(valuearr.length > 0) {
		for(i = 0; i < valuearr.length; i++) {
			objopt = document.createElement('option');
			obj.options.add(objopt);
			objopt.value = valuearr[i];
			objopt.text = textarr[i];
			if(valuearr[i] == selected) {
				ii = i;
			}
		}
		obj.options[ii].selected = true;
	}
}

function removenodebyclass(nodename, tag) {
	var nodes = document.getElementsByTagName(tag);
	if(nodes) {
		for(i = nodes.length-1; i>=0; i--) {
			var node = nodes[i];
			if (node.parentNode.name == nodename) {
				node.parentNode.removeChild(node);
			}
		}
	}
}