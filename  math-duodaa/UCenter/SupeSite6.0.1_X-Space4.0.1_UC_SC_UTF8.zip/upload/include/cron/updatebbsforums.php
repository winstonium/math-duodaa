<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��ʱ������̳������¼

	$Id: updatebbsforums.php 8978 2008-10-16 06:59:39Z zhaofei $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}
include_once(S_ROOT.'./function/cron.func.php');
if(!empty($_SCONFIG['ucmode'])) {

	dbconnect(1);
	
	$updatesql = 'SELECT i.fid, ii.supe_pushsetting  FROM '.tname('forums', 1).' i, '.tname('forumfields',1).' ii WHERE i.fid=ii.fid AND i.fup<>\'0\' ORDER BY i.supe_updateline ASC';
	$query = $_SGLOBAL['db_bbs']->query($updatesql);
	$updateid = array();
	$i = 0;
	
	while($forum = $_SGLOBAL['db']->fetch_array($query)) {
		if(!empty($forum['supe_pushsetting'])) {
			$forum['supe_pushsetting'] = unserialize($forum['supe_pushsetting']);
			if($forum['supe_pushsetting']['status'] == 1 || $forum['supe_pushsetting']['status'] == 3) {
				$updateid[$i++] = $forum['fid'];
				$_SGLOBAL['bbsforumarr'][$forum['fid']] = getbbsforumarr($forum['supe_pushsetting'], $forum['fid']);
				if($i == 2) break;
			}
		}
	}
	if(!empty($_SGLOBAL['bbsforumarr']) && !empty($updateid)) {
		$_SGLOBAL['db_bbs']->query('UPDATE '.tname('threads', 1).' SET supe_pushstatus=\'1\' WHERE (fid =\''.$updateid[0].'\' AND special=\'0\' AND supe_pushstatus<>\'1\'  '.$_SGLOBAL['bbsforumarr'][$updateid[0]]['plussql'].') OR (fid =\''.$updateid[1].'\' AND special=\'0\' AND supe_pushstatus<>\'1\' '.$_SGLOBAL['bbsforumarr'][$updateid[1]]['plussql'].')');
		$_SGLOBAL['db_bbs']->query('UPDATE '.tname('forums', 1).' SET supe_updateline='.$_SGLOBAL['timestamp'].' WHERE fid=\''.$updateid[0].'\' OR fid=\''.$updateid[1].'\'');
	}

}
?>