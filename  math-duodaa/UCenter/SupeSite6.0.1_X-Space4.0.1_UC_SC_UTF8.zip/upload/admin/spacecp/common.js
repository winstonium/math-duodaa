

var isIE = navigator.userAgent.toLowerCase().indexOf('ie');

function getbyid(id) {
	if (document.getElementById) {
		return document.getElementById(id);
	} else if (document.all) {
		return document.all[id];
	} else if (document.layers) {
		return document.layers[id];
	} else {
		return null;
	}
}

/*Cookie操作*/
function CreatCookie(sName,sValue){
	var expires = function(){ //Cookie保留时间
		var mydate = new Date();
		mydate.setTime(mydate.getTime + 3*30*24*60*60*1000);
		return mydate.toGMTString();
	}
	document.cookie = sName + "=" + sValue + ";expires=" + expires;
}
function GetCookieVal(offset) {//获得Cookie解码后的值
	var endstr = document.cookie.indexOf (";", offset);
	if (endstr == -1)
	endstr = document.cookie.length;
	return unescape(document.cookie.substring(offset, endstr));
}
function GetCookie(sName) {//获得Cookie
	var arg = sName + "=";
	var alen = arg.length;
	var clen = document.cookie.length;
	var i = 0;
	while (i < clen)
	{
		var j = i + alen;
		if (document.cookie.substring(i, j) == arg)
		return GetCookieVal (j);
		i = document.cookie.indexOf(" ", i) + 1;
		if (i == 0) break;
	}
	return null;
}

function DelCookie(sName,sValue){ //删除Cookie
	document.cookie = sName + "=" + escape(sValue) + ";expires=Fri, 31 Dec 1999 23:59:59 GMT;";
}

//添加Select选项
function addoption(obj) {
	if (obj.value=='addoption') {
		var newOption=prompt('请输入:','');
		if (newOption!=null && newOption!='') {
			var newOptionTag=document.createElement('option');
			newOptionTag.text=newOption;
			newOptionTag.value=newOption;
			try {
				obj.add(newOptionTag, obj.options[0]); // doesn't work in IE
			}
			catch(ex) {
				obj.add(newOptionTag, obj.selecedIndex); // IE only
			}
			obj.value=newOption;
		} else {
			obj.value=obj.options[0].value;
		}
	}
}

//显示/隐藏内容
function showContent(contentid,ctrlid,opentext,closetext) {
	var content=document.getElementById(contentid);
	if (ctrlid!='') {var ctrl=document.getElementById(ctrlid);}
	if (content.style.display=='') {
		content.style.display='none';
		if (ctrlid!='') {ctrl.innerHTML=opentext;}
		CreatCookie('ss_openmenu', '0');
	} else {
		content.style.display='';
		if (ctrlid!='') {ctrl.innerHTML=closetext;}
		CreatCookie('ss_openmenu', '1');
	}
}

//getElementsByTagNameS
function getElementsByTagNames(list,obj) {
	if (!obj) var obj = document;
	var tagNames = list.split(',');
	var resultArray = new Array();
	for (var i=0;i<tagNames.length;i++) {
		var tags = obj.getElementsByTagName(tagNames[i]);
		for (var j=0;j<tags.length;j++) {
			resultArray.push(tags[j]);
		}
	}
	var testNode = resultArray[0];
	if (!testNode) return [];
	if (testNode.sourceIndex) {
		resultArray.sort(function (a,b) {
				return a.sourceIndex - b.sourceIndex;
		});
	}
	else if (testNode.compareDocumentPosition) {
		resultArray.sort(function (a,b) {
				return 3 - (a.compareDocumentPosition(b) & 6);
		});
	}
	return resultArray;
}

function findPosX(obj)
{
	var curleft = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curleft += obj.offsetLeft
			obj = obj.offsetParent;
		}
	}
	else if (obj.x)
		curleft += obj.x;
	return curleft;
}
function findPosY(obj)
{
	var curtop = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curtop += obj.offsetTop
			obj = obj.offsetParent;
		}
	}
	else if (obj.y)
		curtop += obj.y;
	return curtop;
}

function addMouseEvent() {
	//为输入框添加焦点效果
	var inputs=getElementsByTagNames('input,textarea');
	for (i=0;i<inputs.length;i++) {
		var inputtype = inputs[i].type.toLowerCase();
		if(inputtype == 'checkbox' || inputtype == 'radio') continue;
		inputs[i].onfocus=function() {
			this.className='focus';
			var temptips=document.getElementById(this.id+'tips');
			if (temptips && GetCookie('spTips')!=1) {
				temptips.style.display='block';
				temptips.style.top=findPosY(this)-4+'px';
				temptips.style.left=findPosX(this)+this.offsetWidth+3+'px';
			}
		}
		inputs[i].onblur=function() {
			this.className='';
			if(this.id == 'subject') {
				relatekw();
			}
			var temptips=document.getElementById(this.id+'tips');
			if (temptips) {
				myTimeout = window.setTimeout(function() {temptips.style.display='none';}, 0);
			}
		}
	}
	//为信息列表添加选中效果
	var articleList=document.getElementById('articlelist');
	var temstatus='';
	var temclassname = '';
	if (articleList) {
		var articleRows=articleList.getElementsByTagName('tr');
		for(i=1;i<articleRows.length;i++){
			for(j=1;j<articleRows[i].cells.length;j++) {
				articleRows[i].cells[j].onclick=function() {
					var tempCheckbox=this.parentNode.getElementsByTagName('input')[0];
					var tempTh=this.parentNode.getElementsByTagName('th')[0];
					if (tempCheckbox && !tempTh) {
						if(tempCheckbox.checked!=true){
							tempCheckbox.checked=true;
							this.parentNode.style.background='#F8F5E5';
							temstatus=this.parentNode.style.background;
						} else {
							tempCheckbox.checked=false;
							this.parentNode.style.background='';
							temstatus=this.parentNode.style.background;
						}
					}
				}
			}

			articleRows[i].onmouseover=function() {
				temclassname=this.className;
				if(this.style.background!='#F8F5E5') {
					this.style.background='#F8F5E5';
				}
			}

			articleRows[i].onmouseout=function() {
				if(this.cells[0].getElementsByTagName('input')[0] == undefined || !this.cells[0].getElementsByTagName('input')[0].checked) {
					if(temclassname.length == 0) {
						this.style.background = '';
					} else {
						this.style.background = '#FCFCF2';
						this.className=temclassname;
					}
				}
			}
		}
	}
	//为IE下的Checkbox和Radio去处背景色
	if (isIE>-1) {
		minputs=document.getElementsByTagName('input');
		for(i=0;i<minputs.length;i++){
			if(minputs[i].type!='text'&&minputs[i].type!='file'&&inputs[i].type!='password'){
				minputs[i].style.backgroundColor='transparent';
				minputs[i].style.backgroundImage='none';
				minputs[i].style.border='none';
			}
		}
	}
}

function addTag(tag, id) {
	var tagInput=document.getElementById(id);
	if (tagInput) {
		tagInput.value+=tag+' ';
	}
}


function checkall(form, prefix, checkall) {
	var checkall = checkall ? checkall : 'chkall';
	for(var i = 0; i < form.elements.length; i++) {
		var e = form.elements[i];
		if(e.name != checkall && (!prefix || (prefix && e.name.match(prefix)))) {
			e.checked = form.elements[checkall].checked;
		}
	}
}

function divshow(show, hide) {
	for(i=0;i<show.length;i++){
		document.getElementById(show[i]).style.display = '';
	}
	for(i=0;i<hide.length;i++){
		document.getElementById(hide[i]).style.display = 'none';
	}
}

function unbutton(btn) {
	for(i=0;i<btn.length;i++){
		document.getElementById(btn[i]).disabled=true;
	}
}

function ischeck(id, prefix) {
	form = document.getElementById(id);
	for(var i = 0; i < form.elements.length; i++) {
		var e = form.elements[i];
		if(e.name.match(prefix) && e.checked) {
			if(confirm("您确定要执行本操作吗？")) {
				return true;
			} else {
				return false;
			}
		}
	}
	alert('请选择要操作的对象');
	return false;
}


function checkall(form, prefix, checkall) {
	var checkall = checkall ? checkall : 'chkall';
	for(var i = 0; i < form.elements.length; i++) {
		var e = form.elements[i];
		if(e.name != checkall && (!prefix || (prefix && e.name.match(prefix)))) {
			e.checked = form.elements[checkall].checked;
		}
	}
}


function getid(id) {
	return document.getElementById(id);
}

function uploadFile(mode) {
	var theform = document.getElementById("theform");
	var msg = document.getElementById("divshowuploadmsg");
	var msgok = document.getElementById("divshowuploadmsgok");
	var oldAction = theform.action;
	var oldonSubmit = theform.onSubmit;
	msgok.style.display = 'none';
	msg.style.display = '';
	msg.innerHTML = "正在上传中，请您稍等......";
	theform.action = siteUrl + "/batch.upload.php?mode=" + mode;
	theform.onSubmit = "";
	theform.target = "phpframe";
	theform.submit();
	theform.action = oldAction;
	theform.onSubmit = oldonSubmit;
	theform.target = "";
	if(mode ==2) {
		delpic();
	}
	return false;
}

function attacheditsubmit(aid) {
	var theform = document.getElementById("theform");
	var oldAction = theform.action;
	var oldonSubmit = theform.onSubmit;
	theform.action = siteUrl + "/batch.upload.php?editaid=" + aid;
	theform.onSubmit = "";
	theform.target = "phpframe";
	theform.submit();
	theform.action = oldAction;
	theform.onSubmit = oldonSubmit;
	theform.target = "";
	return false;
}

/**
 * 隐藏并显示上传DIV中的指定标签
 * @param string id: 待显示的标签ID
 */
function hideshowtags(upid,id) {
	//获取上传DIV对象
	var uploadobj = getbyid(upid).getElementsByTagName('div');
	for(var i=0; i< uploadobj.length; i++) {
		if(uploadobj[i].id.indexOf('upload') != -1) {
			uploadobj[i].style.display = "none";
		}
	}
	var showtagobj = getbyid(id);
	showtagobj.style.display = "block";

	var tags = getbyid(upid).getElementsByTagName('div')[0].getElementsByTagName('a');
	for(var i=0; i< tags.length; i++) {
		tags[i].className = "";
	}
	if (getbyid(id+'tab')) { getbyid(id+'tab').className = "current"; }
}
/**
 * 计算字符串长度
 * @param str checkStr:要计算的字符串长度
 */
function chklength(checkStr) {
	var n = 0;
	for (i = 0; i<checkStr.length; i++) {
		chcode = checkStr.charCodeAt(i);
		if (chcode>=0 && chcode<=255) {
			n++;
		} else {
			n += 2;
		}
	}
	return n;
}
/***************批量上传调用开始***********************/
/**
 * 插入一个预览图片
 * @param object obj: 上传文本框对象
 */
function insertimg(obj) {
	var childnum = getbyid("batchdisplay").getElementsByTagName("input");	//获取上传控制个数
	var upallowmax = getbyid("uploadallowmax").value;
	//判断是否超过限制
	if(upallowmax < childnum.length ) {
		alert("一次允许最多上传"+ upallowmax +"个");
		return false;
	}
	//获取最高ID
	var id =getmaxid();
	//添加默认的DIV
	var pichtml = '';
	var src = obj.value;

	//判断文件类型
	var patn = /\.jpg$|\.jpeg$|\.gif$|\.png$|\.bmp$/i;
	var filetype = 'file';
	if(patn.test(src)){
		filetype = 'image';

	}

	var temp_title = src.substr(src.lastIndexOf('\\')+1);
	if(src.lastIndexOf('.') != -1){
		temp_title = temp_title.substr(0,(src.substr(src.lastIndexOf('\\')+1)).lastIndexOf('.'));
	}
	pichtml += '<div class="picspace" id="pic_space_' + id + '" onmouseover="mouseoverpic(' + id + ', 0)" onmouseout="mouseoutpic(' + id + ', 0)">';
	pichtml += '<a href="javascript:;" onclick="delpic('+id+');" style="float: right; margin: 10px 5px 0 0;">删除</a>';
	if (navigator.userAgent.toLowerCase().indexOf('ie') < 0 || filetype != 'image') {
		pichtml += '<img src="admin/images/upload_file.gif" alt="upload file" class="nopreview" align="absmiddle" />';
	} else {
		pichtml += '<img src="' + src + '" id="pic_item_id_' + id + '" align="absmiddle" />';
	}
	pichtml += '<span class="pictext" id="pic_text_' + id + '">';
	pichtml += '<label id="label_pic_' + id + '" title="'+getStrbylen(temp_title,40)+'"><span id="pic_' + id + '">'+getStrbylen(temp_title,16)+'</span><input  id="pic_input_' + id + '" type="text" name="picname[]" value="'+temp_title+'" style="display: none;" /></label>';
	pichtml += '</span><div style="display:none;"><input type="text" name="title[]" value="'+ temp_title +'" id="pic_title_' + id + '" /><input type="text" name="thumb[]" value="'+ (getbyid('uploadthumb2') == null?"":getbyid('uploadthumb2').value) +'"/></div>';
	pichtml += '</div>';

	// 把图片框加到pic_space_main中去
	var picmain = getbyid("batchpreview");
	picmain.innerHTML = picmain.innerHTML + pichtml;
	obj.style.display = 'none';	//隐藏当前的上传对象
	var newid = id+1;	//获取下一个最大的上传ID并创建新的上传控件
	addupload(newid);	//创建一个新的上传控制
}
/**
 * 添加一个新的上传对象控件
 * @param int newid: 新的上传控件ID后缀
 */
function addupload(newid) {
	//两种生成方式，解决浏览器之间的兼容性问题
	try{
		//IE模式下的创建方式,解决常规setAttribute设置属性带来的一些未知的错误
		var uploadHTML = document.createElement("<input type=\"file\" id=\"batch_" + newid + "\" name=\"batchfile[]\" onchange=\"insertimg(this)\" class=\"fileinput\">");
		getbyid("batchdisplay").appendChild(uploadHTML);
	}catch(e) {
		//非IE模式则须要用下列的常规setAttribute设置属性，否则生成的结果不能正常初始化
		var uploadobj = document.createElement("input");
		uploadobj.setAttribute("name", "batchfile[]");
		uploadobj.setAttribute("onchange", "insertimg(this)");
		uploadobj.setAttribute("type", "file");
		uploadobj.setAttribute("id", "batch_" + newid);
		uploadobj.setAttribute("class", "fileinput");
		getbyid("batchdisplay").appendChild(uploadobj);
	}
}
/**
 * 得到页面中可用的最大ID号
 * 写这个函数主要是因为不能通过图片的个数来计算可用的最大ID号.
 * 图片是可以取消的,如果取消,则通过图片个数算出的最大ID号会与已有图片的ID号重叠.
 */
function getmaxid() {
	var items = getbyid("batchdisplay").getElementsByTagName("input");
	var count = items.length;
	var id = 0;
	for (var i=0; i<count; i++) {
		if(items[i].id.substr(0, 6) == "batch_") {
			tmp_id = new Number(items[i].id.substr(6));
			if(id < tmp_id) {
				id = tmp_id;
			}
		}
	}
	if(id == 0) {
		return 1;
	}
	id = new Number(id);
	return id;
}
/**
 * 截取指定字符串长度
 * @param string str: 要截取的字符串
 * @param int len: 要截取的长度
 * @return
 */
function getStrbylen(str, len) {
	var num = 0;
	var strlen = 0;
	var newstr = "";
	var laststrlen = 1;
	var obj_value_arr = str.split("");
	for(var i = 0; i < obj_value_arr.length; i ++) {
		if(i < len && num + byteLength(obj_value_arr[i]) <= len) {
			num += byteLength(obj_value_arr[i]);
			strlen = i + 1;
		}
	}
	if(str.length > strlen) {
		if(byteLength(str.charAt(strlen-1)) == 1){
			laststrlen = 2;
		}
		newstr = str.substr(0, strlen-laststrlen) + '…';
	} else {
		newstr = str;
	}
	return newstr;
}
/**
 * 判断中英问混排时候的长度
 * @param string sStr: 混排的字符串
 */
function byteLength (sStr) {
	aMatch = sStr.match(/[^\x00-\x80]/g);
	return (sStr.length + (! aMatch ? 0 : aMatch.length));
}
/**
 * 鼠标移到预览图事件
 * @param int id: 操作对象ID反缀
 * @param int optype: 操作类型
 */
function mouseoverpic(id,optype) {
	if(optype == 1) {
		var delpicbutton = getbyid("del_pic_button" + id);
		if(delpicbutton.style.display != "inline") {
			delpicbutton.style.display="inline";
		}
	} else if(optype == 0) {
		getbyid("pic_" + id).style.display = "none";
		getbyid("pic_input_" + id).style.display = "inline";
	}
}
/**
 * 鼠标移出预览图事件
 * @param int id: 操作对象ID反缀
 * @param int optype: 操作类型
 */
function mouseoutpic(id, optype) {
	if(optype == 1) {
		var delpicbutton = getbyid("del_pic_button" + id);
		delpicbutton.style.display="none";
	} else if(optype == 0) {
		var picobj = getbyid("pic_" + id);
		var inputobj = getbyid("pic_input_" + id);
		var labelobj = getbyid("label_pic_" + id);
		picobj.style.display = "inline";
		inputobj.style.display = "none";
		//判断是否为空，如果为空则取默认的文件名称
		var re = /\s/ig;
   		var result = inputobj.value.replace(re, "");
		if(result == "") {
			inputobj.value = getbyid("pic_title_" + id).value;
		}
		picobj.innerText = inputobj.value;
		labelobj.title = inputobj.value;
	}
}
/**
 * 删除全部预览图或其中的某一张
 * @param int pid: 要删除的预览图ID后缀，如没有填写则删除全部的预览图
 */
function delpic(pid) {
	//判断是否有传删除的图片ID，如果没有则删除全部的图片
	if(typeof pid != "undefined") {
		getbyid("batchpreview").removeChild(getbyid("pic_space_"+pid));
		//删除相对应的上传控件
		getbyid("batchdisplay").removeChild(getbyid("batch_" + pid));
	} else {
		//获取全部图片对象
		var previewobj = getbyid("batchpreview");
		var allobj = previewobj.getElementsByTagName("div");
		for(var i = allobj.length - 1; 0<=i; i--) {
			if(allobj[i].id.indexOf("pic_space_") != -1) {
				previewobj.removeChild(allobj[i]);
			}
		}
		var bdisplay = getbyid("batchdisplay");
		var allupobj = bdisplay.getElementsByTagName("input");
		for(var i = allupobj.length - 1; 0<=i; i--) {
			bdisplay.removeChild(allupobj[i]);
		}
		addupload(1);
	}
	return false;
}
/***************批量上传调用结束***********************/

function listsubmitconfirm(theform) {
	theform.listsubmit.disabled = true;
	if(confirm("您确定要执行本操作吗？")) {
		theform.listsubmit.disabled = false;
		return true;
	} else {
		theform.listsubmit.disabled = false;
		return false;
	}
}