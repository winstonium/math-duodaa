<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	个人管理页面首页

	$RCSfile: spacecp_home.php,v $
	$Revision: 1.50 $
	$Date: 2007/03/31 01:39:59 $
*/

if(!defined('IN_SUPESITE_SPACECP')) {
	exit('Access Denied');
}

//用户信息与论坛进行自动同步
dbconnect(1);
$query = $_SGLOBAL['db_bbs']->query('SELECT * FROM '.tname('members', 1).' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');

if($member = $_SGLOBAL['db_bbs']->fetch_array($query)) {
	$setsqlarr = array(
		'groupid' => $member['groupid'],
		'username' => addslashes($member['username']),
		'password' => addslashes($member['password']),
		'secques' => addslashes($member['secques']),
		'timeoffset' => addslashes($member['timeoffset']),
		'dateformat' => addslashes($member['dateformat']),
		'timeformat' => addslashes($member['timeformat']),
		'havespace' => '1',
		'newpm' => $member['newpm']
	);
	updatetable('members', $setsqlarr, array('uid'=>$member['uid']));

	if(empty($member['xspacestatus'])) {
		$_SGLOBAL['db']->query('UPDATE '.tname('members', 1).' SET xspacestatus=\'1\' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
	}
}

if(!empty($_COOKIE[$cookiepre.'sauth']) && !empty($_GET['docp']) && $_GET['docp'] == 'me') {
	ssetcookie('sauth', '');
	messagebox('ok', 'change_user', S_URL.'/spacecp.php');
}

setcookie('ss_openmenu', '1');

?>

<div id="nav">
当前位置: <a href="<?=$siteurl?>/?<?=$_SGLOBAL['supe_uid']?>">我的空间</a> <span>&gt;</span> <a href="<?=$siteurl?>/spacecp.php">空间管理</a> <span>&gt;</span> 面板首页
</div>
<?php

//短消息
$pmmsg = '';
if(empty($_SCONFIG['ucmode']) && $member['newpm']) {
	$query = $_SGLOBAL['db_bbs']->query("SELECT * FROM ".tname('pms', 1)." WHERE msgtoid='$_SGLOBAL[supe_uid]' AND folder='inbox' AND new='1' ORDER BY dateline DESC LIMIT 0,6");
	while ($value = $_SGLOBAL['db_bbs']->fetch_array($query)) {
		$value['dateline'] = sgmdate($value['dateline'], 'n-d H:i');
		$pmmsg .= '<li><a href="'.B_URL.'/pm.php?action=view&folder=inbox&pmid='.$value['pmid'].'" target="_blank">'.$value['subject'].'</a> <span class="smalltxt time">(<a href="'.geturl("uid/$value[msgfromid]").'" target="_blank">'.$value['msgfrom'].'</a>, '.$value['dateline'].')</span></li>';
	}
}

//公告
if (strpos('str_'.$_SCONFIG['allowannounce'], 'back')) {
	@include_once(S_ROOT.'./data/system/announcement.cache.php');
	$sitemsg = '';
	if (!empty($_SGLOBAL['announcement'])) {
		foreach ($_SGLOBAL['announcement'] as $key => $listvalue) {
			if(!empty($listvalue['endtime']) && $listvalue['endtime'] < $_SGLOBAL['timestamp']) continue;
			if($key>9) break;//最多10条
			$listvalue['starttime'] = sgmdate($listvalue['starttime'], 'n-d');
			$sitemsg .= '<li><a href="'.geturl('action/announcement/id/'.$listvalue['id']).'" target="_blank">'.$listvalue['subject'].'</a> <span class="smalltxt time">'.$listvalue['starttime'].'</span></li>';
		}
	}
}			
if (!empty($pmmsg)) {
?>
<div class="notice">
	<a href="<?=B_URL?>/pm.php" style="float: right; margin-top: 3px;" target="_blank">查看所有短消息</a>
	<h3>您有新的短消息</h3>
	<ul>
		<?=$pmmsg?>
	</ul>
</div>
<?php }
if (!empty($sitemsg)) {
?>
<div class="notice">
	<a href="<?=$siteurl?>/?action_announcement" style="float: right; margin-top: 3px;" target="_blank">查看所有公告</a>
	<h3>最新站点公告</h3>
	<ul>
		<?=$sitemsg?>
	</ul>
</div>
<?php }?>

<div class="block">
	<h3>快速发布</h3>
	<ul class="welcomepanel">
		<?if(!empty($channels['menus']['blog'])) {?><li><a href="<?=CPURL?>?action=spaceblogs&op=add">日志</a></li><?}?>
		<?if(!empty($channels['menus']['image'])) {?><li><a href="<?=CPURL?>?action=spaceimages&op=add">图片</a></li><?}?>
		<?if(!empty($channels['menus']['goods'])) {?><li><a href="<?=CPURL?>?action=spacegoods&op=add">商品</a></li><?}?>
		<?if(!empty($channels['menus']['link'])) {?><li><a href="<?=CPURL?>?action=spacelinks&op=add">书签</a></li><?}?>
		<?if(!empty($channels['menus']['file'])) {?><li><a href="<?=CPURL?>?action=spacefiles&op=add">文件</a></li><?}?>
		<?if(!empty($channels['menus']['video'])) {?><li><a href="<?=CPURL?>?action=spacevideos&op=addplayer">影音</a></li><?}?>
	</ul>
	<h3>常用功能</h3>
	<ul class="welcomepanel">
		<?if(!empty($channels['menus']['group'])) {?><li><a href="<?=CPURL?>?action=groups">我的圈子</a></li><?}?>
		<?if(!empty($channels['menus']['image'])) {?><li><a href="<?=CPURL?>?action=spaceimages&op=add">大头贴</a></li><?}?>
		<li><a href="<?=CPURL?>?action=usertemplates">我的模板</a></li>
		<li><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>">浏览我的空间首页</a></li>
		<?if($_SGLOBAL['group']['groupid'] == 1) {?><li><a href="<?=S_URL?>/admincp.php" style="color:red;">进入站点管理平台</a></li><?}?>
	</ul>
	</div>
</div>
