<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	个人管理页面页头

	$RCSfile: spacecp_header_space.php,v $
	$Revision: 1.21 $
	$Date: 2007/03/27 23:12:46 $
*/

if(!defined('IN_SUPESITE_SPACECP')) {
	exit('Access Denied');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$_SCONFIG['charset']?>" />
<title>个人空间管理</title>
<link href="<?=IMG_DIR?>/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var siteUrl = "<?=S_URL?>";
</script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/images/edit/edit.js"></script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/ajax.js"></script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/common.js"></script>
<script language="javascript" type="text/javascript" src="<?=S_URL?>/include/js/menu.js"></script>
<script language="javascript" type="text/javascript" src="<?=IMG_DIR?>/common.js"></script>
<script type="text/javascript">
	var spTips = GetCookie('spTips');
	var tipText = '显示帮助与提示信息';
	if (spTips!=1) {
		tipText = '隐藏帮助与提示信息';
	}
	function showHideTips() {
		var shTips = getbyid('shtips');
		spTips = GetCookie('spTips');
		if (spTips!=1) {
			shTips.innerHTML = '显示帮助与提示信息'
			CreatCookie('spTips','1');
		} else {
			shTips.innerHTML = '隐藏帮助与提示信息';
			DelCookie('spTips','0')
			
		}
	}
</script>
</head>

<body onload="addMouseEvent();">
<div class="wrap">

<table id="header" summary="header" cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr>
		<td>
			<div id="headertitle">
				<h1><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>" title="回到<?=$space['spacename']?>首页"><?=$space['spacename']?></a></h1>
				<p><?=$guide?></p>
			</div>
		</td>
		<td>
			<ul id="topmenu">
				<li>欢迎您，<a href="<?=CPURL?>?action=userspaces&op=photo"><?=stripslashes($_SGLOBAL['supe_username'])?></a> |</li>
				<li><a href="<?=S_URL?>/?<?=$_SGLOBAL['supe_uid']?>" target="_blank">我的空间首页</a> |</li>
				<li><a href="<?=S_URL?>/" target="_blank">站点首页</a> |</li>
				<li><a href="<?=B_URL?>/" target="_blank">进入论坛</a> |</li>
				<li><a href="<?=S_URL?>/batch.login.php?action=logout">退出</a></li>
			</ul>
			<ul id="actions">
				<li><a href="javascript:;" id="sidectrl" onclick="showContent('sidebar','sidectrl','打开侧边栏','关闭侧边栏');"><?=$sidetitle?></a></li>
				<li><a id="shtips" href="javascript:showHideTips();"><script type="text/javascript">document.write(tipText);</script></a></li>
			</ul>
		</td>
	</tr>
	<tr>
		<td colspan="2" id="menu">
			<ul>
				<?=$menustr?>
			</ul>
			<?=$popupmenustr?>
		</td>
	</tr>
</table>

<?php
$menucurrents = array('spacename'=>'',
	'spacemode'=>'',
	'userfield'=>'',
	'domain'=>'',
	'flash'=>'',
	'music'=>'',
	'menu' => '',
	'property'=>''
);
if(!empty($_GET['op'])) {
	$menucurrents[$_GET['op']] = ' class="current"';
} else {
	$menucurrents['spacename'] = ' class="current"';
}
?>
<table summary="content" cellpadding="0" cellspacing="0" border="0" width="100%" align="center">
<tr>
	<td id="sidebar" style="display:<?=$sidedisplay?>;">
		<div>
			<ul>
				<li><a href="<?=CPURL?>?action=userspaces&op=spacename"<?=$menucurrents['spacename']?>>修改头像/空间名/公告</a></li>
				<li><a href="<?=CPURL?>?action=userspaces&op=spacemode"<?=$menucurrents['spacemode']?>>切换空间模式</a></li>
				<li><a href="<?=CPURL?>?action=userspaces&op=userfield"<?=$menucurrents['userfield']?>>修改个人资料</a></li>
<?php
if(!empty($_SGLOBAL['group']['allowdomain']) && !empty($_SCONFIG['allowdomain'])) {
?>				
				<li><a href="<?=CPURL?>?action=userspaces&op=domain"<?=$menucurrents['domain']?>>个性域名</a></li>
<?php
}
?>	
				<li><a href="<?=CPURL?>?action=userspaces&op=flash"<?=$menucurrents['flash']?>>页面FLASH特效</a></li>
				<li><a href="<?=CPURL?>?action=userspaces&op=music"<?=$menucurrents['music']?>>我的音乐盒</a></li>
				<li><a href="<?=CPURL?>?action=userspaces&op=menu"<?=$menucurrents['menu']?>>修改菜单</a></li>
				<li><a href="<?=CPURL?>?action=userspaces&op=property"<?=$menucurrents['property']?>>配置空间属性</a></li>
				
			</ul>
		</div>
	</td>
	<td id="mainarea">

