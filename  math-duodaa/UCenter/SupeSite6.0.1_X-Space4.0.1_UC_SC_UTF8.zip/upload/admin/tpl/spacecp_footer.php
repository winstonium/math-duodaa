<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	个人管理页面页脚

	$RCSfile: spacecp_footer.php,v $
	$Revision: 1.20 $
	$Date: 2007/03/12 22:31:02 $
*/

if(!defined('IN_SUPESITE_SPACECP')) {
	exit('Access Denied');
}
?>

		</td>
	</tr>
</table>

<div id="footer">
	<p class="copyright">Powered by <a href="http://www.supesite.com" target="_blank"><strong>X-<span>Space</span></strong></a> <em><?=X_VER?></em> &copy; 2001-2008 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a></p>
</div>
</div>
<iframe id="phpframe" name="phpframe" width="0" height="0" marginwidth="0" frameborder="0" src="about:blank"></iframe>
</body>
</html>
<?
if(D_BUG) include_once(S_ROOT.'./include/debug.inc.php');
?>