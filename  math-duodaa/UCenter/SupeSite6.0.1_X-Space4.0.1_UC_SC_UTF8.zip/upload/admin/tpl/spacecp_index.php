<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?=$_SCONFIG['charset']?>" />
<title><?=$alang['spacecp_header_title']?></title>
</head>

<frameset rows="30,*" frameborder="no" border="0" framespacing="0">
  <frame src="<?=CPURL?>?action=toolbar" name="topframe" scrolling="No" id="topframe" title="topframe" />
  <frameset id="mainframeset" cols="160,8,*" frameborder="no" border="0" framespacing="0">
    <frame src="<?=CPURL?>?action=sidemenu" name="leftframe" noresize="noresize" id="leftframe" title="leftframe" />
	<frame src="admin/frameborder.htm" name="frameborder" scrolling="No" noresize="noresize" id="frameborder" title="frameborder" />
    <frame src="<?=CPURL?>?action=home" name="mainframe" id="mainframe" title="mainframe" />
  </frameset>
</frameset>
<noframes>
<body>
</body>
</noframes>
</html>