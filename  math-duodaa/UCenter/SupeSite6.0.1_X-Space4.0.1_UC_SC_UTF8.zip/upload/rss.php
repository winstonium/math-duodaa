<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	RSS����

	$RCSfile: rss.php,v $
	$Revision: 1.37 $
	$Date: 2007/06/04 13:45:53 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

include_once(S_ROOT.'./include/common.inc.php');

$_SGET['uid'] = empty($_SGET['uid'])?0:intval($_SGET['uid']);
if(empty($_SGET['uid'])) {
	//baidu sitemap���
	$nowtime = sgmdate($_SGLOBAL['timestamp'], 'Y-m-d H:i:s');
	$xsver = X_VER;
	print<<<EOF
<?xml version="1.0" encoding="$_SCONFIG[charset]"?>
<document>
<webSite>$_SCONFIG[sitename]</webSite>
<webMaster>$adminemail</webMaster>
<urlset xmlns:blog="$newsiteurl"></urlset>
<updatePeri>1</updatePeri>
<updatetime>$nowtime</updatetime>
<version>X-space $xsver</version>
EOF;
	$thedateline = $_SGLOBAL['timestamp'] - 3600;//1Сʱ
	$query = $_SGLOBAL['db']->query("SELECT itemid, uid, username, subject, viewnum, replynum, dateline FROM ".tname('spaceitems')." WHERE type='blog' AND folder='1' AND dateline>'$thedateline' ORDER BY dateline DESC");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$link = geturl("uid/$value[uid]/action/viewspace/itemid/$value[itemid]", 1);
		$pubdate = sgmdate($value['dateline'], 'Y-m-d H:i:s');
		$bloghome = geturl("uid/$value[uid]", 1);
		print<<<EOF

<item>
<link>$link</link>
<title>$value[subject]</title>
<pubDate>$pubdate</pubDate>
<blog_reply>$value[replynum]</blog_reply>
<blog_view>$value[viewnum]</blog_view>
<blog_user>$value[username]</blog_user>
<blog_home>$bloghome</blog_home>
</item>
EOF;
	}
	print<<<EOF

</document>
EOF;
	exit();
}

$rssdateformat = 'D, d M Y H:i:s T';

$itemsarr = $wherearr = array();
$rssarr = array(
	'charset' => $_SCONFIG['charset'],
	'title' => $_SCONFIG['sitename'],
	'link' => S_URL_ALL,
	'description' => $_SCONFIG['sitename'],
	'copyright' => 'Copyright(C) '.$_SCONFIG['sitename'],
	'generator' => 'SupeSite/X-Space',
	'lastBuildDate' => sgmdate($_SGLOBAL['timestamp'], $rssdateformat),
	'items' => array()
);

$wherearr[] = 'uid=\''.$_SGET['uid'].'\'';

$type = 'blog';
if(!empty($_SGET['type']) && in_array ($_SGET['type'], $_SGLOBAL['type'])) {
	$type = $_SGET['type'];
}
$wherearr[] = 'type=\''.$type.'\'';

$space = getuserspace($_SGET['uid']);
if(empty($space)) {
	$rssarr['title'] = 'rss_url_error';
	$rssarr['link'] = S_URL_ALL;
	showrss($rssarr);
	exit;
}

$rssarr['title'] = $space['spacename'];
$rssarr['link'] = geturl('uid/'.$_SGET['uid'], 1);
$rssarr['description'] = $space['announcement'];
$rssarr['copyright'] = 'Copyright(C) '.$space['spacename'];

$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('rss').' WHERE '.implode(' AND ',$wherearr));
$items = $_SGLOBAL['db']->fetch_array($query);

if(empty($items) || $items['updatetime'] < $_SGLOBAL['timestamp']) {
	$itemsarr = updaterss($_SGET['uid'], $type);
} else {
	$itemsarr = unserialize($items['data']);
}

if(!empty($itemsarr)) {
	foreach($itemsarr as $key => $value) {
		$rssarr['items'][] = array(
			'title' => $value['subject'],
			'link' => geturl('uid/'.$_SGET['uid'].'/action/viewspace/itemid/'.$value['itemid'], 1),
			'description' => $value['message'],
			'category' => $value['type'],
			'author' => $value['username'],
			'pubDate' => sgmdate($value['dateline'], $rssdateformat)
		);	
	}
}

showrss($rssarr);

function showrss($rssarr) {
	header("Content-type: application/xml");
	echo '<?xml version="1.0" encoding="'.$rssarr['charset'].'"?>
			<?xml-stylesheet type="text/css" href="'.S_URL_ALL.'/css/rss.css"?>
			<rss version="2.0">
			  <channel>
			    <title>'.$rssarr['title'].'</title>
			    <link>'.$rssarr['link'].'</link>
			    <description>'.$rssarr['description'].'</description>
			    <copyright>'.$rssarr['copyright'].'</copyright>
			    <generator>'.$rssarr['generator'].'</generator>
			    <lastBuildDate>'.$rssarr['lastBuildDate'].'</lastBuildDate>';
			    if(!empty($rssarr['items'])) {
				    foreach($rssarr['items'] as $key => $value) {
				    	echo '<item>
								<title>'.$value['title'].'</title>
								<link>'.$value['link'].'</link>
								<description><![CDATA['.$value['description'].']]></description>
								<category>'.$value['category'].'</category>
								<author>'.$value['author'].'</author>
								<pubDate>'.$value['pubDate'].'</pubDate>
							</item>
							';
				    }
			    }
	echo '
		</channel>
	</rss>';
}

function updaterss($uid, $type) {
	global $_SGLOBAL, $_SGET, $_SCONFIG, $lang;

	$rssarr = array();
	$attacharr = array();
	if(empty($_SCONFIG['rssnum'])) $_SCONFIG['rssnum'] = 10;
	$sql = 'SELECT i.subject, i.itemid, i.type, i.username, i.dateline, i.hash, b.* FROM '.tname('spaceitems').' i LEFT JOIN '.tname(gettypetablename($type)).' b ON b.itemid=i.itemid WHERE i.uid=\''.$uid.'\' AND i.type=\''.$type.'\''.' AND i.folder=\'1\' ORDER BY i.dateline DESC LIMIT 0,'.$_SCONFIG['rssnum'];
	$query = $_SGLOBAL['db']->query($sql);
	while($items = $_SGLOBAL['db']->fetch_array($query)) {
		$othermsgarr = array();
		$items['message'] = cutstr($items['message'], 255, 1);

		if($type == 'goods') {
			$othermsgarr[] = $lang['commodity_description'].':'.$items['subject'];
			$othermsgarr[] = $lang['deciding_new_or_old'].':'.($items['quality'] == 'new'?$lang['new']:$lang['old']);
			$othermsgarr[] = $lang['commodity_prices'].':'.$items['price'].$lang['yuan'];
			$othermsgarr[] = $lang['charge'].':'.($items['chargemode'] == 'buy'?$lang['buyers_assume_freight'].','.$lang['surface'].':'.$items['chargemail'].$lang['yuan'].','.$lang['sam'].$items['chargeexpress'].$lang['yuan'].',EMS:'.$items['chargeems'].$lang['yuan']:$lang['sellers_bear_freight']);
			$othermsgarr[] = $lang['location'].':'.$items['province'].'  '.$items['city'];
		} elseif($type == 'link') {
			$othermsgarr[] = $lang['subject'].': '.'<a href="'.$items['url'].'" target="_blank">'.$items['subject'].'</a>';
			$othermsgarr[] = 'URL: <a href="'.$items['url'].'" target="_blank">'.$items['url'].'</a>';
		}

		if(!empty($othermsgarr)) $items['message'] = implode('<br>', $othermsgarr).'<br>'.$items['message'];
		if(!empty($items['hash'])) $attacharr[] = trim($items['hash']);
		$rssarr[$items['itemid']] = $items;
	}
	
	if(!empty($rssarr)) {
		if($_SCONFIG['rssupdatetime'] < 300) $_SCONFIG['rssupdatetime'] = 300;
		$insertsqlarr = array(
			'uid' => $uid,
			'type' => $type,
			'data' => addslashes(serialize($rssarr)),
			'updatetime' => $_SGLOBAL['timestamp'] + $_SCONFIG['rssupdatetime']
		);
		replacetable('rss', $insertsqlarr);
	}
	return $rssarr;
}

?>
