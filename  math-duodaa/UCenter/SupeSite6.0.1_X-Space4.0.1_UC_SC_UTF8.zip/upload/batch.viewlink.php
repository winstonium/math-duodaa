<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	ϵͳ���õ���һЩ����

	$RCSfile: batch.viewlink.php,v $
	$Revision: 1.21 $
	$Date: 2007/04/06 20:28:24 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$action = empty($_GET['action'])?'':$_GET['action'];
$itemid = empty($_GET['itemid'])?'':intval($_GET['itemid']);
$item = array();
if($itemid) {
	dbconnect();
	$query = $_SGLOBAL['db']->query("SELECT ii.*, i.* FROM ".tname('spaceitems')." i LEFT JOIN ".tname('spacelinks')." ii ON ii.itemid=i.itemid WHERE i.itemid='$itemid' AND i.folder='1' AND i.type='link'");
	$item = $_SGLOBAL['db']->fetch_array($query);
	if($item['itemtypeid']) {
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('itemtypes').' WHERE typeid=\''.$item['itemtypeid'].'\'');
		if($value = $_SGLOBAL['db']->fetch_array($query)) {
			if($value['viewperm']) {
				getcookie(1);
				$_SCONFIG['htmlviewspace'] = 0;
				if($item['uid'] != $_SGLOBAL['supe_uid']) {
					$query2 = $_SGLOBAL['db']->query('SELECT * FROM '.tname('friends').' WHERE uid=\''.$item['uid'].'\' AND frienduid=\''.$_SGLOBAL['supe_uid'].'\' AND grade IN ('.$value['viewperm'].') LIMIT 1');
					if(!$_SGLOBAL['db']->fetch_array($query2)) {
						messagebox('error', 'not_friend');
					}
				}
			}
			$item['itemtypename'] = $value['typename'];
		}
	}
}

if(empty($action)) {

	if(empty($item)) messagebox('error', 'not_found', S_URL);
	getcookie(1);	
	$code = rawurlencode(authcode($item['uid'].'|'.$item['itemid'], 'ENCODE'));

	print<<<END
	<html>
	<head>
	<meta http-equiv="content-type" content="text/html; charset=$charset">
	<title>$item[subject] $_SCONFIG[seotitle]- $_SCONFIG[sitename]- Powered by SupeSite</title>
	<meta name="keywords" content="$_SCONFIG[sitename] $_SCONFIG[seokeywords]" />
	<meta name="description" content="$_SCONFIG[sitename] $_SCONFIG[seodescription]" />
	<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/style.css" />
	</head>
	<frameset name="fset" rows="*,30px" border=0 >
		<frame name="main" src="$item[url]" >
		<frame name="bottom" height="30" src="$siteurl/batch.viewlink.php?action=bottom&code=$code" scrolling="no" noresize="true">
	</frameset>	
	</html>
END;
exit;

} elseif ($action == 'bottom') {

	$code = empty($_GET['code'])?'':$_GET['code'];
	$codestr = authcode($code, 'DECODE');
	$codearr = explode('|', $codestr);
	if(count($codearr) != 2) exit;
	$uid = intval($codearr[0]);
	$itemid = intval($codearr[1]);

	$itemurl = geturl('uid/'.$uid.'/action/viewspace/itemid/'.$itemid);
	print<<<END
	<html>
	<head>
	<meta http-equiv="content-type" content="text/html; charset=$charset">
	<title>$_SCONFIG[sitename]</title>
	<style type="text/css">
	<!--
	body { font:75% Arial, Helvetica, sans-serif; color:#333; background: #CCC; text-align: center; margin: 0; line-height: 30px; }
	li { border-bottom: 1px solid #CCC; padding-bottom: 1em; margin-bottom: 1em; }
	h4 { font-size: 1.2em; margin: 0.5em 0; }
	a { color: #000; text-decoration: underline; }
		a:hover { text-decoration: none; }
		a:visited { color: #666; }
	-->
	</style>
	</head>
	<body>
	$_SCONFIG[sitename]
	<a href="$itemurl" target="_top">$blang[i_comment]</a>
	| <a href="$siteurl/batch.viewlink.php?action=snapshot&amp;itemid=$itemid" target="main">$blang[check_snapshot]</a>
	| <a href="$siteurl/batch.viewlink.php?action=copy&amp;itemid=$itemid" target="main">$blang[copy_to_my_bookmarks]</a>
	| <a href="$siteurl/batch.viewlink.php?action=domain&amp;itemid=$itemid" target="main">$blang[check_with_the_site_bookmarks]</a>
	| <a href="$siteurl/batch.viewlink.php?action=subject&amp;itemid=$itemid" target="main">$blang[check_with_the_title_bookmarks]</a>
	| <a href="$siteurl" target="_top">$blang[return_to_index_page]</a>
	</body>
	</html>
END;
exit;

} elseif ($action == 'domain') {

	if(empty($item)) messagebox('error', 'not_found', S_URL);
	
	$links = '';
	if(!empty($item['domain'])) {
		$domain = str_replace('\'', '', $item['domain']);
		$query = $_SGLOBAL['db']->query("SELECT ii.*, i.* FROM ".tname('spacelinks')." ii LEFT JOIN ".tname('spaceitems')." i ON i.itemid=ii.itemid WHERE ii.domain='$domain'");
		while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			$value['dateline'] = sgmdate($value['dateline']);
			$links .= "<li>
				<a href=\"".geturl("uid/$value[uid]/action/viewspace/itemid/$value[itemid]")."\"><b>$value[subject]</b></a><br />
				$blang[adder]:<a href=\"".geturl("uid/$value[uid]")."\" target=\"_top\">$value[username]</a> $blang[time]:$value[dateline] $blang[already] $value[viewnum] $blang[s_click], $value[replynum] $blang[s_reply]<br />
				$value[message]
				</li>";
		}
	}
	if(empty($links)) $links = '<li>'.$blang['not_found_relevant_bookmarks'].'</li>';

	print<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=$charset" />
	
	<title>$item[domain] - $blang[check_with_the_site_bookmarks] - $_SCONFIG[sitename]</title>
	<link rel="stylesheet" type="text/css" href="$siteurl/templates/$_SCONFIG[template]/css/style.css" />
	<script type="text/javascript">
	var siteUrl = "$siteurl";
	</script>
	</head>
	<body>
	<table summary="" id="notice" cellpadding="0" cellspacing="0" border="0" style="width:80%; text-align:left; margin: 40px auto 0; ">
		<tr>
			<td id="notice_message">
			<center>$blang[check_with_the_site_bookmarks]</center>
			<ul style="font-size:12px;">
			$links
			</ul>
			</td>
		</tr>
		<tr>
			<td id="notice_links" style="text-align:center;">
				<a href="javascript:window.close();" class="done">$blang[mail_close]</a>
				<a href="$siteurl" class="home">$_SCONFIG[sitename]</a>
			</td>
		</tr>
	</table>
	</body>
	</html>
END;
exit();

} elseif ($action == 'subject') {

	if(empty($item)) messagebox('error', 'not_found', S_URL);
	
	$links = '';
	if(!empty($item['subject'])) {
		include_once(S_ROOT.'./include/common.inc.php');
		
		$subject = addslashes(stripsearchkey(cutstr($item['subject'], 18)));

		
		$query = $_SGLOBAL['db']->query("SELECT i.* FROM ".tname('spaceitems')." i WHERE i.subject LIKE '$subject'");
		while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			$value['dateline'] = sgmdate($value['dateline']);
			$links .= "<li>
				<a href=\"".geturl("uid/$value[uid]/action/viewspace/itemid/$value[itemid]")."\"><b>$value[subject]</b></a><br />
				$blang[adder]:<a href=\"".geturl("uid/$value[uid]")."\" target=\"_top\">$value[username]</a> $blang[time]:$value[dateline] $blang[already] $value[viewnum] $blang[s_click], $value[replynum] $blang[s_reply]
				</li>";
		}
	}
	if(empty($links)) $links = '<li>'.$blang['heading_found_no_correlation_bookmarks'].'</li>';

	print<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=$charset" />
	
	<title>$item[domain] - $blang[check_with_the_title_bookmarks] - $_SCONFIG[sitename]</title>
	<link rel="stylesheet" type="text/css" href="$siteurl/templates/$_SCONFIG[template]/css/style.css" />
	<script type="text/javascript">
	var siteUrl = "$siteurl";
	</script>
	</head>
	<body>
	<table summary="" id="notice" cellpadding="0" cellspacing="0" border="0" style="width:80%; text-align:left; margin: 40px auto 0; ">
		<tr>
			<td id="notice_message">
			<center>$blang[check_with_the_title_bookmarks]</center>
			<ul style="font-size:12px;">
			$links
			</ul>
			</td>
		</tr>
		<tr>
			<td id="notice_links" style="text-align:center;">
				<a href="javascript:window.close();" class="done">$blang[mail_close]</a>
				<a href="$siteurl" class="home">$_SCONFIG[sitename]</a>
			</td>
		</tr>
	</table>
	</body>
	</html>
END;
exit();

} elseif ($action == 'copy') {
	
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) messagebox('error', 'no_login', geturl('action/login'));
	if($_SGLOBAL['supe_uid'] == $item['uid']) messagebox('error', 'no_self');
	
	include_once(S_ROOT.'./include/common.inc.php');
	$setsqlarr = array(
		'uid' => $_SGLOBAL['supe_uid'],
		'username' => $_SGLOBAL['supe_username'],
		'type' => 'link',
		'subject' => addslashes($item['subject']),
		'dateline' => $_SGLOBAL['timestamp']
	);
	$newitemid = inserttable('spaceitems', $setsqlarr, 1);
	
	$setsqlarr = array(
		'itemid' => $newitemid,
		'postip' => $_SGLOBAL['onlineip'],
		'url' => addslashes($item['url']),
		'domain' => addslashes($item['domain'])
	);
	inserttable('spacelinks', $setsqlarr);
	
	messagebox('ok', 'bookmark_has_successfully');
	
} elseif ($action == 'snapshot') {
	
	if(empty($item['snaptext'])) messagebox('error', 'no_snaptext');
	if($item['snaptype'] == 1) {
		$item['snaptext'] = nl2br(str_replace(array("\t", '   ', '  '), array('&nbsp; &nbsp; &nbsp; &nbsp; ', '&nbsp; &nbsp;', '&nbsp;&nbsp;'), $item['snaptext']));
	}
	
	print<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>$item[subject] - $blang[check_snapshot] - $_SCONFIG[sitename]</title>
	<base href="$item[url]" />
	</head>
	<body>
	$item[snaptext]
	</body>
	</html>
END;
exit;

}

?>