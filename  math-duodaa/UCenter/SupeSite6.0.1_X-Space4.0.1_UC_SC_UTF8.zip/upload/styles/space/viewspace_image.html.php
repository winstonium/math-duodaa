<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">上一篇</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">下一篇</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])# / 图片数($item[imagenum])
	<!--{if !empty($item['digest'])}--> / 精华($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ 置顶($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ 不允许评论<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ 个人分类：<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">查看( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">评论( $item[replynum] )</a> / 
	<a href="#xspace-itemform">评分( <span class="xspace-rategood" title="好评">$item[goodrate]</span> / <span class="xspace-ratebad" title="差评">$item[badrate]</span> )</a>
</div>

<div class="xspace-imagebox" >
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="100%" height="650" id="photo" align="middle">
		<param name="movie" value="$flashurl" />
		<param name="quality" value="high" />
		<param name="bgcolor" value="#EEEEEE" />
		<embed src="$flashurl" quality="high" bgcolor="#EEEEEE" width="100%" height="650" name="photo" align="middle" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
</div>

<div class="xspace-msgmodule">
	<h5>图片分享</h5>
	<ul class="xspace-list">
		<li>主题地址: <script type="text/javascript">
			document.write('<input type="text" value="'+location.href+'" size="80" onmouseover="this.select();" \/>');
		</script>
		<br /><span style="padding-left: 4.5em; color: #999;">通过E-mail / MSN / QQ，把节目地址告诉你的好友</span></li>
		<!--{if empty($item['password'])}-->
		<li>图片地址: <input type="text" value="$flashurl" size="80" onmouseover="this.select();" />
		<br /><span style="padding-left: 4.5em; color: #999;">在各类论坛、Blog的文章编辑器中选择“插入flash”，直接复制就可以了</span></li>
		<li>页面代码: <input type="text" value="&lt;object width=&quot;100%&quot; height=&quot;650&quot;&gt;&lt;param name=&quot;movie&quot; value=&quot;$flashurl&quot;&gt;&lt;/param&gt;&lt;param name=&quot;wmode&quot; value=&quot;transparent&quot;&gt;&lt;/param&gt;&lt;embed src=&quot;$flashurl&quot; type=&quot;application/x-shockwave-flash&quot; wmode=&quot;transparent&quot; width=&quot;100%&quot; height=&quot;650&quot;&gt;&lt;/embed&gt;&lt;/object&gt;" size="80" onmouseover="this.select();" />
		<br /><span style="padding-left: 4.5em; color: #999;">可以用于所有支持html编辑的网页或blog（标准尺寸340*300）</span></li>
		<!--{/if}-->
	</ul>
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->