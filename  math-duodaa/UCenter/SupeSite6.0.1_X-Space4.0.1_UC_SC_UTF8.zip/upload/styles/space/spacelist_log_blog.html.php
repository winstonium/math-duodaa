<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=spaceblogs&op=add&openwindow=1">发布新日志</a><p>
<ul class="xspace-listtab">
	<li id="xspace-myentry" class="xspace-sublist{$tabactive[0]}" onmouseover="showHideCatList('show', this.id, 'xspace-catlist', 5, 30);" onmouseout="showHideCatList('hide', this.id, 'xspace-catlist');"><a href="#uid/$uid/action/spacelist/type/blog#">我的日志</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/blog/view/track#">我的足迹</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/blog/view/fav#">我的收藏</a></li>
</ul>

<!--{if !empty($_SBLOCK['itemtype'])}-->
	<div id="xspace-catlist" class="xspace-sublistitem" onmouseover="showHideCatList('show', 'xspace-myentry', this.id, 5, 30);" onmouseout="showHideCatList('hide', 'xspace-myentry', this.id);">
		<ul>
			<!--{loop $_SBLOCK['itemtype'] $ikey $ivalue}-->
			<li><a href="#uid/$ivalue[uid]/action/spacelist/type/$ivalue[type]/itemtypeid/$ivalue[typeid]#">$ivalue[typename]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{/if}-->
<div>
	<!--{if empty($iarr)}-->
	<div class="xspace-noticemsg">现在还没有相关日志信息</div>
	<!--{else}-->
	<ul class="xspace-itemlist">
	<!--{loop $iarr $value}-->
		<li class="xspace-loglist">
			<h4 class="xspace-entrytitle"><!--{if !empty($value['tid'])}-->[<a href="{B_URL}/viewthread.php?tid=$value[tid]" target="_blank">论坛</a>]<!--{/if}--><a href="$value[url]">$value[subject]</a></h4>
			<p class="xspace-smalltxt">
			<!--{if !empty($view)}-->
			<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> 发布于 
			<!--{/if}-->
			#date("Y-m-d H:i:s",$value["dateline"])#
			{$value[top]}{$value[digest]}
			</p>			
			<div class="xspace-itemmessage" id="xspace-item{$value[itemid]}">
			<!--{if empty($space['summarylen'])}-->
				$value[message]
			<!--{else}-->
				正在下载中，请稍等...
			<!--{/if}-->
			</div>
			<p class="xspace-itemlinks">
				<a href="$value[url]">查看($value[viewnum])</a>
				<a href="$value[url]#xspace-itemform">评论($value[replynum])</a>
				<a href="javascript:joinfavorite($value[itemid]);">收藏</a>
				<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$value[itemid]', 300);">分享</a>
				<!--{if !empty($channels['menus']['group'])}-->
				<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$value[itemid]', 300);">圈子</a>
				<!--{/if}-->
				<a href="{S_URL}/batch.manage.php?itemid=$value[itemid]" target="_blank">管理</a>
			</p>
		</li>
	<!--{/loop}-->
	</ul>
	<!--{/if}-->
</div>

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->

<!--{if !empty($space['summarylen'])}-->
<script type="text/javascript">
<!--{loop $iarr $value}-->
getbyid('xspace-item{$value[itemid]}').innerHTML = "$value[message]";
<!--{/loop}-->
</script>
<!--{/if}-->