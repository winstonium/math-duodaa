<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">上一篇</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">下一篇</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['weather'])}--> / 天气: $item[weather]<!--{/if}-->
	<!--{if !empty($item['mood'])}-->/ 心情: $item[mood]<!--{/if}-->
	<!--{if !empty($item['digest'])}-->/ 精华($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ 置顶($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ 不允许评论<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ 个人分类：<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	查看( $item[viewnum] ) / 
	评论( $item[replynum] )
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
	<br />
	<div class="xspace-imginlog">
		<!--{loop $item['attach'] $value}-->
		<a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank" title="点击查看大图片"><img src="$value[thumbpath]" alt="$value[subject]" class="xspace-imgstyle" /></a>
		<p>$value[subject]</p>
		<!--{/loop}-->
	</div>
</div>
<!--{if !empty($ads['spaceviewad'])}-->
<div class="xspace-itemmessage">
	$ads[spaceviewad]
</div>
<!--{/if}-->

<!--{if !empty($item['tracks'])}-->
<div id="xspace-tracks" class="xspace-msgmodule">
	<h5>
	<a href="{S_URL}/batch.track.php?itemid=$item[itemid]" target="_blank" title="查看全部脚印" style="float:right;" class="xspace-smalltxt">全部脚印</a>
	<a href="javascript:;" onclick="javascript:deletetrack($item[itemid]);" target="_self" title="清除我的脚印" style="float:right;margin-right:0.5em;" class="xspace-smalltxt">不留脚印</a>
	留下脚印:
	</h5>
	<ul class="xspace-list">
	<!--{loop $item['tracks'] $value}-->
	<li class="xspace-avatarlist xspace-imgstyle"><a href="$value[url]" title="$value[username]曾经在#date("Y-n-d", $value["dateline"])#访问过该主题" target="_blank"><img src="$value[photo]" alt="$value[username]曾经在#date("Y-n-d", $value["dateline"])#访问过该主题" /></a><p><a href="$value[url]" target="_blank">$value[username]</a></p></li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<!--{if !empty($item['relatives'])}-->
<div id="xspace-relatives" class="xspace-msgmodule">
	<h5>相关阅读:</h5>
	<ul class="xspace-list">
	<!--{loop $item['relatives'] $value}-->
	<li><a href="$value[url]" target="_blank">$value[subject]</a> <span class="xspace-smalltxt">(<a href="#uid/$value[uid]#" target="_blank">$value[username]</a>, #date("Y-n-d", $value["dateline"])#)</span></li> 
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<p class="xspace-itemlinks">
	<a href="{B_URL}/viewthread.php?tid=$item[tid]" target="_blank">论坛模式</a>
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$item[itemid]', 300, 150);">推荐</a>
	<a href="javascript:;" onclick="joinfavorite($item[itemid]);">收藏</a>
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$item[itemid]', 400);">分享给好友</a>
	<!--{if !empty($channels['menus']['group'])}-->
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$item[itemid]', 300);">推荐到圈子</a>
	<!--{/if}-->
	<a href="{S_URL}/batch.manage.php?itemid=$item[itemid]" target="_blank">管理</a>
</p>

<p class="xspace-itemtag">TAG: 
	<!--{loop $item[relativetags] $value}-->
	<a href="#action/tag/tagname/$value#" target="_blank">$value</a>
	<!--{/loop}-->
</p>

<div id="xspace-itemreply">
	<!--{if $commentlist}-->
	<!--{loop $commentlist $value}-->
	<dl>
		<dt>
			<!--{if empty($value['spacename'])}-->
			<img src="$value[photo]" class="xspace-signavatar xspace-imgstyle" alt="" />
			<!--{else}-->
			<a href="#uid/$value[authorid]#" target="_blank"><img src="$value[photo]" class="xspace-signavatar xspace-imgstyle" alt="$value[spacename]" /></a>
			<!--{/if}-->
			<!--{if empty($value['spacename'])}-->
			$value[author]
			<!--{else}-->
			<a href="#uid/$value[authorid]#" target="_blank">$value[author]</a>
			<!--{/if}-->
			<span class="xspace-smalltxt">发布于#date("Y-m-d H:i:s", $value["dateline"])#</span>
		</dt>
		<dd>
			<!--{if !empty($value['subject'])}--><strong>$value[subject]</strong><br /><!--{/if}-->
			$value[message]
			<br />
			<!--{if !empty($commentlist[$value['pid']]['attachments'])}-->
			<div class="xspace-imginlog">
			<!--{loop $commentlist[$value['pid']]['attachments'] $value}-->
				<!--{if $value['isimage']}-->
					<a href="{B_URL}/attachment.php?aid=$value[aid]" target="_blank"><img src="$value[attachment]" alt="$value[filename]" class="xspace-imgstyle" /></a><p>$value[filename]</p>
				<!--{else}-->
					<p><img src="{S_URL}/images/base/haveattach.gif" align="absmiddle" border="0"><a href="{B_URL}/attachment.php?aid=$value[aid]" target="_blank"><strong>$value[filename]</strong></a><br />($value[dateline], Size: $value[attachsize], Downloads: $value[downloads])</p>
				<!--{/if}-->
			<!--{/loop}-->
			</div>
			<!--{/if}-->
		</dd>
	</dl>
	<!--{/loop}-->
	<!--{/if}-->
	<div id="xspace-multipage-div" class="xspace-multipage"><a href="{B_URL}/viewthread.php?tid=$item[tid]" target="_blank">进入论坛，查看全部评论</a></div>
</div>

<div id="xspace-itemform">
	<form id="xspace-commentform" action="{S_URL}/blogpost.php" method="post" target="_self">
		<fieldset>
			<legend>我来说两句</legend>
			<p>
				<label for="xspace-subject">标题</label>
				<input type="text" size="20" id="xspace-subject" name="subject" value="" /> (可选)
			</p>
			<p>
				<label for="xspace-commentmsg">内容</label>
				<textarea id="xspace-commentmsg" name="message"></textarea>
			</p>

			<p class="xspace-seccodeline">
				<label for="xspace-seccode">验证</label>
				<input type="text" size="10" id="xspace-seccode" name="seccode" value="" />
				<label for="xspace-seccode"><img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="" title="看不清？点击换一个" /></label>
			</p>

			<p>
				<input type="hidden" name="supe_fromsupesite" value="$item[fromsupesite]" />
				<input type="hidden" name="supe_jumpurl" value="$newsiteurl/?uid/{$item[uid]}/action/viewspace/itemid/{$item[itemid]}/php/1" />
				<input type="hidden" name="itemid" value="$itemid" />
				<input type="hidden" name="tid" value="$item[tid]" />
				<button value="true" type="submit" name="submitcomment" id="xspace-btncomment">提交评论</button>
			</p>
		</fieldset>
	</form>
</div>

<script language="javascript" type="text/javascript">
<!--
function newseccode(obj) {
	obj.src='{S_URL}/batch.seccode.php?'+Math.random(1);
}
addImgLink("xspace-showmessage");addImgLink("xspace-itemreply");
//-->
</script>
