<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">上一篇</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">下一篇</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['digest'])}--> / 精华($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ 置顶($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ 不允许评论<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ 个人分类：<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">查看( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">评论( $item[replynum] )</a> / 
	<a href="#xspace-itemform">评分( <span class="xspace-rategood" title="好评">$item[goodrate]</span> / <span class="xspace-ratebad" title="差评">$item[badrate]</span> )</a>
</div>

<div id="xspace-fileinfo">
	<ul id="xspace-filebaseinfo" class="xspace-propertylist">
		<!--{if $item['filesize']}--><li><strong>文件大小</strong>: $item[filesize] $item[filesizeunit]</li><!--{/if}-->
		<!--{if $item['version']}--><li><strong>文件版本</strong>: $item[version]</li><!--{/if}-->
		<!--{if $item['producer']}--><li><strong>开发商</strong>: $item[producer]</li><!--{/if}-->
		<!--{if $item['downfrom']}--><li><strong>文件来源</strong>: $item[downfrom]</li><!--{/if}-->
		<!--{if $item['language']}--><li><strong>界面语言</strong>: $item[language]</li><!--{/if}-->
		<!--{if $item['permission']}--><li><strong>授权方式</strong>: $item[permission]</li><!--{/if}-->
		<!--{if $item['system']}--><li><strong>运行平台</strong>: $item[system]</li><!--{/if}-->
	</ul>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
</div>

<div class="xspace-filedown xspace-msgmodule">
	<!--{if $item[attach]}-->
	<div class="xspace-localdown">
		<h5>本地下载</h5>
		<!--{if !empty($credits['abs'])}-->
			<p>下载需要消费：<img src="{S_URL}/images/base/credit.gif">{$credits[abs]}个{$_SCONFIG[creditname]}</p>
		<!--{/if}-->
		<ul class="xspace-list">
			<!--{loop $item[attach] $value}-->
			<li><a href="{S_URL}/batch.download.php?aid=$value[aid]">$value[subject]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->

	<!--{if $item[remoteurl]}-->
	<div class="xspace-remotedown">
		<h5>远程下载</h5>
		<ul class="xspace-list">
			<!--{loop $item[remoteurl] $value}-->
			<li><a href="$value[remoteurl]" target="_blank">$value[remoteurlname]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/if}-->
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->