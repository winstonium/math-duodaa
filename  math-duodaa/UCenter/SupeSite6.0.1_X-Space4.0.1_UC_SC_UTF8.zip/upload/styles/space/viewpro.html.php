<?exit?>
<!--{if !empty($_SGET['showpro'])}-->
<h3>$space[username]的个人资料</h3>

<div class="xspace-xcard">
<a href="{B_URL}/viewpro.php?uid=$uid">查看我的论坛资料</a>
</div>

<div class="xspace-xcard">
	<ul class="xspace-propertylist">
	<!--{loop $space['field'] $key $field}-->
		<!--{if !empty($field)}--><li><strong>$space[title][$key]</strong>: $field</li><!--{/if}-->
	<!--{/loop}-->
	<!--{if !empty($space[province])}-->
		<li><strong>省份</strong>: $space[province]</li>
	<!--{/if}-->
	<!--{if !empty($space[city])}-->
		<li><strong>地区</strong>: $space[city]</li>
	<!--{/if}-->
	</ul>
</div>
<!--{/if}-->

<h3 class="xspace-blocktitle">
	<a href="{S_URL}/spacecp.php?action=manage&amp;op=guestbook" target="_blank" class="xspace-manage">管理</a>
	给我的留言
</h3>
<div id="xspace-itemreply">
<!--{loop $guestbooks $key $value}-->
	<dl id="xspace-comment{$value[gid]}">
		<dt>
			<!--{if empty($value['spacename']) || empty($value['authorid'])}-->
			<img src="$value[photo]" class="xspace-signavatar xspace-imgstyle" alt="" />
			<!--{else}-->
			<a href="#uid/$value[authorid]#" target="_blank"><img src="$value[photo]" alt="$value[spacename]" class="xspace-signavatar xspace-imgstyle" /></a>
			<!--{/if}-->

			<!--{if !empty($_SGLOBAL['supe_uid']) && ($_SGLOBAL['supe_uid'] == $space['uid'] || !empty($_SGLOBAL['group']['allowcheckitem']))}-->
			<a href="javascript:;" target="_self" onclick="showajaxdiv('{S_URL}/batch.guestbook.php?action=reply&amp;gid=$value[gid]&amp;page=$page', 300);" class="xspace-quote">回复</a>
			<a href="javascript:;" target="_self" onclick="javascript:deleteguestbook($value[gid]);" class="xspace-del">删除</a>
			<!--{/if}-->

			<!--{if empty($value['spacename']) || empty($value['authorid'])}-->$value[author]<!--{else}--><a href="#uid/$value[authorid]#" target="_blank">$value[author]</a><!--{/if}--> <span class="xspace-smalltxt">留言于#date("Y-m-d H:i:s", $value["dateline"])#
			<!--{if !empty($_SGLOBAL['supe_uid']) && ($_SGLOBAL['supe_uid'] == $space['uid'] || !empty($_SGLOBAL['group']['allowcheckitem']))}-->
			&nbsp;&nbsp; IP: $value[ip]
			<!--{/if}-->
			</span>
		</dt>
		<dd>$value[message]</dd>
	</dl>
<!--{/loop}-->
<div id="xspace-multipage-div" class="xspace-multipage">$multipage</div>
</div>

<div id="xspace-itemform">
	<form id="xspace-commentform" action="{S_URL}/batch.guestbook.php" method="post">
		<fieldset>
			<legend>给 $space[username] 留言</legend>
			<p>　　<input type="checkbox" id="xspace-isprivate" name="isprivate" value="1" /><label for="xspace-isprivate">私密</label></p>
			<p><label for="xspace-commentmsg">内容</label>
			<textarea id="xspace-commentmsg" name="message"></textarea>
			</p>
			<p><label for="xspace-nickname">昵称</label>
			<input type="text" size="20" id="xspace-nickname" name="nickname" value="" /> (可选)
			</p>
			<!--{if allowfeed()}-->
			<p>
				<label>$lang[pushed_to_the_feed]</label>
				<!--{if addfeedcheck(2)}-->
				<input type="checkbox" name="addfeed" checked="checked">
				<!--{else}-->
				<input type="checkbox" name="addfeed" >
				<!--{/if}-->
			</p>
			<!--{/if}-->
			<!--{if empty($_SCONFIG['noseccode'])}-->
			<p class="xspace-seccodeline"><label for="xspace-seccode">验证</label>
			<input type="text" size="10" id="xspace-seccode" name="seccode" value="" />
			<label for="xspace-seccode"><img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" /></label>
			</p>
			<!--{/if}-->
			<p>
			<input type="hidden" name="uid" value="$space[uid]" />
			<input type="submit" id="xspace-btncomment" name="btncomment" value="发表留言" />
			</p>
	</fieldset>
</form>
</div>

<script language="javascript" type="text/javascript">
<!--
function showguestbook(page) {
	var x = new Ajax('statusid', 'XML');
	x.get('{S_URL}/batch.guestbook.php?action=view&uid=$space[uid]&page='+page, function(s) {
			getbyid("xspace-itemreply").innerHTML = s.lastChild.firstChild.nodeValue;
	});
}
function deleteguestbook(gid) {
	var x = new Ajax('statusid', 'XML');
	x.get('{S_URL}/batch.guestbook.php?action=delete&gid='+gid, function(s) {
			alert(s.lastChild.firstChild.nodeValue);
	});
}
function newseccode(obj) {
	obj.src='{S_URL}/batch.seccode.php?'+Math.random(1);
}
//-->
</script>