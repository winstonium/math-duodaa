<?exit?>
<!--{if !empty($_SGLOBAL['viewspacetpl'])}-->
	<!--{if !empty($ads3['pagecenterad'])}-->
	<div class="xspace-itemmessage">
		$ads3[pagecenterad]
	</div>
	<!--{/if}-->
<!--{else}-->
	<!--{if !empty($ads['spaceviewad'])}-->
		<div class="xspace-itemmessage">
			$ads[spaceviewad]
		</div>
	<!--{/if}-->
<!--{/if}-->

<!--{if !empty($item['tracks'])}-->
<div id="xspace-tracks" class="xspace-msgmodule">
	<h5>
	<a href="{S_URL}/batch.track.php?itemid=$item[itemid]" target="_blank" title="查看全部脚印" style="float:right;" class="xspace-smalltxt">全部脚印</a>
	<a href="javascript:;" onclick="javascript:deletetrack($item[itemid]);" target="_self" title="清除我的脚印" style="float:right;margin-right:0.5em;" class="xspace-smalltxt">不留脚印</a>
	留下脚印:
	</h5>
	<ul class="xspace-list">
	<!--{loop $item['tracks'] $value}-->
	<li class="xspace-avatarlist xspace-imgstyle"><a href="$value[url]" title="$value[username]曾经在#date("Y-n-d", $value["dateline"])#访问过该主题" target="_blank"><img src="$value[photo]" alt="$value[username]曾经在#date("Y-n-d", $value["dateline"])#访问过该主题" /></a><p><a href="$value[url]" target="_blank">$value[username]</a></p></li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<!--{if !empty($item['relatives'])}-->
<div id="xspace-relatives" class="xspace-msgmodule">
	<h5>相关阅读:</h5>
	<ul class="xspace-list">
	<!--{loop $item['relatives'] $value}-->
	<li><a href="$value[url]" target="_blank">$value[subject]</a> <span class="xspace-smalltxt">(<a href="#uid/$value[uid]#" target="_blank">$value[username]</a>, #date("Y-n-d", $value["dateline"])#)</span></li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<p class="xspace-itemlinks">
	<!--{if $item['type'] == 'blog'}-->
		<!--{if !empty($_SCONFIG['ucmode'])}-->
		<a href="javascript:;" onclick="showajaxdiv('{S_URL}/blogpost.php?action=import&amp;itemid=$item[itemid]',400);">导入论坛</a>
		<!--{else}-->
		<a href="{B_URL}/post.php?action=import&amp;itemid=$item[itemid]" target="_blank">导入论坛</a>
		<!--{/if}-->
	<!--{if !empty($_SCONFIG['allowtrackback'])}-->
		<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=trackback&amp;itemid=$item[itemid]', 300);">引用链接</a>
	<!--{/if}-->
	<!--{/if}-->
	<a href="javascript:;" onclick="joinfavorite($item[itemid]);">收藏</a>
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$item[itemid]', 400);">分享给好友</a>
	<!--{if !empty($channels['menus']['group'])}-->
	<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$item[itemid]', 300);">推荐到圈子</a>
	<!--{/if}-->
	<a href="{S_URL}/batch.manage.php?itemid=$item[itemid]" target="_blank">管理</a>
	<a href="javascript:;" onclick="report($item[itemid]);">举报</a>
	<!--{if $item['folder'] != 1}--><span style="color:blue;font-weight:bold;">[非公开发布状态]</span><!--{/if}-->
</p>

<p class="xspace-itemtag">TAG:
	<!--{loop $item[relativetags] $value}-->
	<!--{eval $uvalue = rawurlencode($value);}-->
	<a href="#action/tag/tagname/$uvalue#" target="_blank">$value</a>
	<!--{/loop}-->
</p>

<div id="xspace-itemreply">
	<!--{if $commenthtml}-->
	$commenthtml
	<!--{/if}-->
	<div id="xspace-multipage-div" class="xspace-multipage"><a href="javascript:;" onclick="javascript:showcomment(1);">查看全部评论</a></div>
</div>

<div id="xspace-itemform">
	<form id="xspace-commentform" action="{S_URL}/batch.comment.php" method="post" target="xspace-phpframe">
		<fieldset id="xspace-rates">
			<div id="xspace-rates-bg">
				<div id="xspace-rates-star" class="xspace-rates0">&nbsp;</div>
				<div id="xspace-rates-a">
					<a href="javascript:;" onmouseover="rateHover(-5);" onmouseout="rateOut();" onclick="setRate('-5', '$itemid');">-5</a>
					<a href="javascript:;" onmouseover="rateHover(-3);" onmouseout="rateOut();" onclick="setRate('-3', '$itemid');">-3</a>
					<a href="javascript:;" onmouseover="rateHover(-1);" onmouseout="rateOut();" onclick="setRate('-1', '$itemid');">-1</a>
					<a href="javascript:;" onmouseover="rateHover(0);" onmouseout="rateOut();" onclick="setRate('0', '$itemid');">-</a>
					<a href="javascript:;" onmouseover="rateHover(1);" onmouseout="rateOut();" onclick="setRate('1', '$itemid');">+1</a>
					<a href="javascript:;" onmouseover="rateHover(3);" onmouseout="rateOut();" onclick="setRate('3', '$itemid');">+3</a>
					<a href="javascript:;" onmouseover="rateHover(5);" onmouseout="rateOut();" onclick="setRate('5', '$itemid');">+5</a>
				</div>
				<input type="hidden" id="xspace-rates-value" name="rates" value="0" />
			</div>
			<p>评分：<span id="xspace-rates-tip">0</span></p>
		</fieldset>
		<fieldset>
			<legend>我来说两句</legend>
			<p>
				<span onclick="moresmilies();" class="xspace-moresmilies">显示全部</span>
				<div id="xspace-smilies">
					<!--{loop $_SGLOBAL['smilies']['display'] $key $smiley}-->
						<img src="{S_URL}/images/smilies/$smiley[url]" border="0" alt="$smiley[code]" id="smilie_$key" onClick="insertSmilies($key)" />
					<!--{/loop}-->
				</div>
			</p>
			<p>
				<label for="xspace-commentmsg">内容</label>
				<textarea id="xspace-commentmsg" name="message"></textarea>
			</p>
			<p>
				<label for="xspace-nickname">昵称</label>
				<input type="text" size="20" id="xspace-nickname" name="nickname" value="" />
			</p>
			<!--{if allowfeed()}-->
			<p>
				<label>$lang[pushed_to_the_feed]</label>
				<!--{if addfeedcheck(2)}-->
				<input type="checkbox" name="addfeed" checked="checked">
				<!--{else}-->
				<input type="checkbox" name="addfeed" >
				<!--{/if}-->
			</p>
			<!--{/if}-->

			<!--{if empty($_SCONFIG['noseccode'])}-->
			<p id="xspace-seccodeline">
				<label for="xspace-seccode">验证</label>
				<input type="text" size="10" id="xspace-seccode" name="seccode" value="" />
				<label for="xspace-seccode"><img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" /></label>
			</p>
			<!--{/if}-->
			<p>
				<input type="hidden" name="itemid" value="$itemid" />
				<button value="true" type="submit" name="submitcomment" id="xspace-btncomment">提交评论</button>
			</p>
		</fieldset>
	</form>
</div>

<script language="javascript" type="text/javascript">
<!--
function showcomment(page) {
	var x = new Ajax('statusid', 'XML');
	x.get('{S_URL}/batch.comment.php?action=view&itemid=$item[itemid]&page='+page, function(s) {
			getbyid("xspace-itemreply").innerHTML = s.lastChild.firstChild.nodeValue;
	});
}
function deletecomment(cid) {
	var x = new Ajax('statusid', 'XML');
	x.get('{S_URL}/batch.comment.php?action=delete&cid='+cid, function(s) {
			alert(s.lastChild.firstChild.nodeValue);
	});
}

function moresmilies() {
	var smilies = document.getElementById('xspace-smilies');
	if (smilies.style.height=='auto') {
		smilies.style.height = '';
	} else {
		smilies.style.height = 'auto';
	}
}
addImgLink("xspace-showmessage");
addMediaAction('xspace-showmessage');
//-->
</script>
<iframe id="xspace-phpframe" name="xspace-phpframe" width="0" height="0" marginwidth="0" frameborder="0" src="about:blank"></iframe>
