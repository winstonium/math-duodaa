<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=spaceimages&op=add&openwindow=1">发布新图片</a><p>
<ul class="xspace-listtab">
	<li id="xspace-myentry" class="xspace-sublist{$tabactive[0]}" onmouseover="showHideCatList('show', this.id, 'xspace-catlist', 5, 30);" onmouseout="showHideCatList('hide', this.id, 'xspace-catlist');"><a href="#uid/$uid/action/spacelist/type/image#">我的图片</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/image/view/track#">看过的图片</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/image/view/fav#">收藏的图片</a></li>
</ul>

<!--{if !empty($_SBLOCK['itemtype'])}-->
	<div id="xspace-catlist" class="xspace-sublistitem" onmouseover="showHideCatList('show', 'xspace-myentry', this.id, 5, 30);" onmouseout="showHideCatList('hide', 'xspace-myentry', this.id);">
		<ul>
			<!--{loop $_SBLOCK['itemtype'] $ikey $value}-->
			<li><a href="#uid/$value[uid]/action/spacelist/type/$value[type]/itemtypeid/$value[typeid]#">$value[typename]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{/if}-->
<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">现在还没有相关图片信息</div>
<!--{else}-->
<ul class="xspace-itemlist">
<!--{loop $iarr $value}-->
	<li class="xspace-coverlist">
		<h4 class="xspace-entrytitle"><strong class="xspace-imgstyle"><a href="$value[url]"><img src="$value[image]" class="xspace-imgcover" alt="$value[subject]" /></a></strong>
		<a href="$value[url]">$value[subject]</a> <span class="xspace-smalltxt">($value[imagenum]张)</span></h4>
		<p class="xspace-smalltxt">
		<!--{if !empty($view)}-->
		<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> 发布于 
		<!--{/if}-->
		#date("Y-m-d H:i:s", $value["dateline"])# / $value[viewnum]人查看 / $value[replynum]条评论
		{$value[top]}{$value[digest]}
		</p>
		<!--{if $value[message]}--><p>$value[message]</p><!--{/if}-->
		<p class="xspace-itemlinks">
			<a href="javascript:joinfavorite($value[itemid]);">收藏</a>
			<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$value[itemid]', 300);">分享</a>
			<!--{if !empty($channels['menus']['group'])}-->
			<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$value[itemid]', 300);">圈子</a>
			<!--{/if}-->
			<a href="{S_URL}/batch.manage.php?itemid=$value[itemid]" target="_blank">管理</a>
		</p>
	</li>
<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->