<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">上一篇</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">下一篇</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['weather'])}--> / 天气: $item[weather]<!--{/if}-->
	<!--{if !empty($item['mood'])}-->/ 心情: $item[mood]<!--{/if}-->
	<!--{if !empty($item['digest'])}-->/ 精华($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ 置顶($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ 不允许评论<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ 个人分类：<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">查看( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">评论( $item[replynum] )</a> / 
	<a href="#xspace-itemform">评分( <span class="xspace-rategood" title="好评">$item[goodrate]</span> / <span class="xspace-ratebad" title="差评">$item[badrate]</span> )</a>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo xspace-msgmodule">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
	<br />
	<div class="xspace-imginlog">
		<!--{loop $item['attach'] $value}-->
		<!--{if $value['isimage']}-->
		<a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank" title="点击查看大图片"><img src="$value[thumbpath]" alt="$value[subject]" class="xspace-imgstyle" /></a>
		<p><a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank">$value[subject]</a></p>
		<!--{else}-->
		<a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank"><img src="{S_URL}/images/base/attachment.gif" border="0" alt="$value[subject]" ></a>
		<p><a href="{S_URL}/batch.download.php?aid=$value[aid]" target="_blank">$value[filename](<!--{eval echo formatsize($value[size]);}-->)</a></p>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->
