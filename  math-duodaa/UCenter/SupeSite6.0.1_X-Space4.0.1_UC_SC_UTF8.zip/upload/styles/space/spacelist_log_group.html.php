<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=groups&op=add&openwindow=1">创建新圈子</a><p>
<ul class="xspace-listtab">
	<li class="{$tabactive[0]}"><a href="#uid/$uid/action/spacelist/type/group#">我创建的圈子</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/group/view/fav#">我参与的圈子</a></li>
</ul>

<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">现在还没有相关圈子信息</div>
<!--{else}-->
<ul class="xspace-itemlist">
<!--{loop $iarr $value}-->
	<li class="xspace-grouplist">
		<p class="xspace-smalltxt xspace-joingroup">本圈共有$value[usernum]位成员, <a href="javascript:;" onclick="javascript:joingroup('$value[gid]');">加入本圈</a></p>
		<h4 class="xspace-entrytitle"><strong class="xspace-imgstyle"><a href="$value[url]" target="_blank"><img src="$value[logo]" class="xspace-grouplogo" alt="$value[groupname]" /></a></strong>
		<a href="$value[url]" target="_blank">$value[groupname]</a></h4>
		<p class="xspace-smalltxt">
		<!--{if !empty($view)}-->
		圈主: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a> 加入时间:
		<!--{else}-->
		创建于
		<!--{/if}-->
		#date("Y-m-d H:i:s", $value["dateline"])#
		</p>
		<!--{if !empty($value['intro'])}--><p>$value[intro]</p><!--{/if}-->
		<p class="xspace-itemlinks"><a href="$value[url]">进入圈子</a>
		<a href="#action/mygroup/gid/$value[gid]/op/list/type/bbs#">圈子讨论区</a>
		<a href="#action/mygroup/gid/$value[gid]/op/list/type/members#">成员列表</a>
		</p>
	</li>
<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->