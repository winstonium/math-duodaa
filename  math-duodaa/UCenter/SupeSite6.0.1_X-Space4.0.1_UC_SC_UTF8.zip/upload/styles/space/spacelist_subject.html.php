<?exit?>
<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">现在还没有相关信息</div>
<!--{else}-->
<ul class="xspace-list">
<!--{loop $iarr $value}-->
	<li>
	<strong>[<a href="#uid/$uid/action/spacelist/type/$value[type]#">$value[typename]</a>]</strong>
	<a href="$value[url]">$value[subject]</a>
	<span class="xspace-smalltxt">#date("Y-m-d",$value["dateline"])#</span>
	</li>
<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->
