<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=spacelinks&op=add&openwindow=1">发布新书签</a><p>
<ul class="xspace-listtab">
	<li id="xspace-myentry" class="xspace-sublist{$tabactive[0]}" onmouseover="showHideCatList('show', this.id, 'xspace-catlist', 5, 30);" onmouseout="showHideCatList('hide', this.id, 'xspace-catlist');"><a href="#uid/$uid/action/spacelist/type/link#">我的书签</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/link/view/track#">我浏览过的书签</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/link/view/fav#">我收藏的书签</a></li>
</ul>

<!--{if !empty($_SBLOCK['itemtype'])}-->
	<div id="xspace-catlist" class="xspace-sublistitem" onmouseover="showHideCatList('show', 'xspace-myentry', this.id, 5, 30);" onmouseout="showHideCatList('hide', 'xspace-myentry', this.id);">
		<ul>
			<!--{loop $_SBLOCK['itemtype'] $ikey $value}-->
			<li><a href="#uid/$value[uid]/action/spacelist/type/$value[type]/itemtypeid/$value[typeid]#">$value[typename]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{/if}-->
<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">现在还没有相关书签信息</div>
<!--{else}-->
<ul class="xspace-itemlist">
<!--{loop $iarr $value}-->
	<li class="xspace-linklist">
		<h4 class="xspace-entrytitle"><a href="$value[itemurl]">$value[subject]</a></h4>
		<p class="xspace-smalltxt">
		<!--{if !empty($view)}-->
		<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> 发布于 
		<!--{/if}-->
		#date("Y-m-d",$value["dateline"])# &nbsp; {$value[top]} {$value[digest]}
		</p>
		<strong>网址</strong>: $value[cuturl]<br>
		<strong>快照</strong>: <a href="{S_URL}/batch.viewlink.php?action=snapshot&amp;itemid=$value[itemid]" target="_blank">查看快照</a>
		<!--{if !empty($value['tags'])}-->
		<br><strong>标签</strong>:
		<!--{loop $value[tags] $tagname}-->
		<a href="{S_URL}/?action/tag/tagname/<!--{eval echo rawurlencode($tagname);}-->">$tagname</a> &nbsp;
		<!--{/loop}-->
		<!--{/if}-->
		<!--{if $value[message]}-->
		<p><!--{eval echo nl2br($value[message])}--></p>
		<!--{/if}-->
		<p class="xspace-itemlinks">
			<a href="$value[itemurl]">点击($value[viewnum])</a>
			<a href="$value[itemurl]#xspace-itemform" target="_blank" class="xspace-smalltxt">评论($value[replynum])</a>
			<a href="{S_URL}/batch.viewlink.php?action=subject&amp;itemid=$value[itemid]" target="_blank" class="xspace-smalltxt">同主题</a>
			<a href="{S_URL}/batch.viewlink.php?action=domain&amp;itemid=$value[itemid]" target="_blank" class="xspace-smalltxt">同站点</a>
			<a href="javascript:joinfavorite($value[itemid]);">收藏</a>
			<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$value[itemid]', 300);">分享</a>
			<!--{if !empty($channels['menus']['group'])}-->
			<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$value[itemid]', 300);">圈子</a>
			<!--{/if}-->
			<a href="{S_URL}/batch.manage.php?itemid=$value[itemid]" target="_blank">管理</a>
		</p>
	</li>
<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->
