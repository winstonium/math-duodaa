<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=friends&amp;op=add&amp;openwindow=1">添加好友</a><p>
<ul class="xspace-listtab">
	<li class="{$tabactive[0]}"><a href="#uid/$uid/action/spacelist/type/friend#">我的好友</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/friend/view/fav#">我的FANS</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/friend/view/track#">我去过的空间</a></li>
	<li class="{$tabactive[3]}"><a href="#uid/$uid/action/spacelist/type/friend/view/visitor#">我的访客</a></li>
</ul>

<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">现在还没有相关好友信息</div>
<!--{else}-->
<ul class="xspace-itemlist">
	<!--{loop $iarr $value}-->
	<li class="xspace-friendlist">
		
		<!--{if empty($value['spacename'])}-->
		<h4 class="xspace-entrytitle">
		<a href="#uid/$value[fuid]#" target="_blank"><img src="$value[photo]" alt="" class="xspace-friendavatar xspace-imgstyle" /></a>
		<a href="#uid/$value[fuid]#" target="_blank">Member($value[fuid])</a>
		</h4>
		<p>论坛会员</p>
		<p>$firendname #date("", $value["fdateline"])#</p>
		<!--{else}-->
		<h4 class="xspace-entrytitle">
		<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=friendupdate&amp;uid=$value[uid]', 400);" target="_self"><img src="$value[photo]" alt="" class="xspace-friendavatar xspace-imgstyle" /></a>
		<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=friendupdate&amp;uid=$value[uid]', 400);" target="_self">$value[username]</a> 
		</h4>
		<p><a href="#uid/$value[uid]#" target="_blank">$value[spacename]</a> $value[province] $value[city]</p>
		<p>空间更新 #date("", $value["lastpost"])# (<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=friendupdate&amp;uid=$value[uid]', 400);" target="_self">$value[spaceallnum]</a>)</p>
		<p>$firendname #date("", $value["fdateline"])#</p>
		<p class="xspace-itemlinks">
			<a class="xspace-profile" href="$value[prourl]" target="_blank">个人资料</a>
			<a class="xspace-sendpm" href="$value[pmurl]" target="_blank">短消息</a>
			<a class="xspace-addfriend" href="javascript:;" onclick="javascript:joinfriend('$value[uid]');">加为好友</a>
			<a class="xspace-guestbook" href="$value[guestbookurl]" target="_blank">留言两句</a>
		</p>
		<!--{/if}-->
	</li>
	<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->
