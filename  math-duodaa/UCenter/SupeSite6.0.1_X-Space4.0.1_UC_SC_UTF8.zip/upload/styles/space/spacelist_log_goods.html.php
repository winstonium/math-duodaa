<?exit?>
<p class="xspace-addentry"><a href="{S_URL}/spacecp.php?action=spacegoods&op=add&openwindow=1">发布新商品</a><p>
<ul class="xspace-listtab">
	<li id="xspace-myentry" class="xspace-sublist{$tabactive[0]}" onmouseover="showHideCatList('show', this.id, 'xspace-catlist', 5, 30);" onmouseout="showHideCatList('hide', this.id, 'xspace-catlist');"><a href="#uid/$uid/action/spacelist/type/goods#">我的商品</a></li>
	<li class="{$tabactive[1]}"><a href="#uid/$uid/action/spacelist/type/goods/view/track#">浏览过的商品</a></li>
	<li class="{$tabactive[2]}"><a href="#uid/$uid/action/spacelist/type/goods/view/fav#">收藏的商品</a></li>
</ul>

<!--{if !empty($_SBLOCK['itemtype'])}-->
	<div id="xspace-catlist" class="xspace-sublistitem" onmouseover="showHideCatList('show', 'xspace-myentry', this.id, 5, 30);" onmouseout="showHideCatList('hide', 'xspace-myentry', this.id);">
		<ul>
			<!--{loop $_SBLOCK['itemtype'] $ikey $value}-->
			<li><a href="#uid/$value[uid]/action/spacelist/type/$value[type]/itemtypeid/$value[typeid]#">$value[typename]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{/if}-->
<!--{if empty($iarr)}-->
<div class="xspace-noticemsg">现在还没有相关商品信息</div>
<!--{else}-->
<ul class="xspace-itemlist">
	<!--{loop $iarr $ikey $value}-->
	<li class="xspace-goodslist">
		<p class="xspace-smalltxt xspace-price">价格: <strong>$value[price]</strong>元</p>
		<h4 class="xspace-entrytitle"><a href="$value[url]"><img src="$value[thumb]" class="xspace-goodsimg xspace-imgstyle" alt="$value[subject]" /></a>
		<a href="$value[url]">$value[subject]</a>
		<span class="xspace-smalltxt">$value[province] $value[city]</span></h4>
		<p class="xspace-smalltxt">
		<!--{if !empty($view)}-->
		<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> 发布于 
		<!--{/if}-->
		#date("Y-n-d H:i:s", $value["dateline"])# / $value[viewnum]人查看 / $value[replynum]条评论
		{$value[top]}{$value[digest]}
		</p>
		<!--{if $value[message]}--><p>$value[message]</p><!--{/if}-->
		<p class="xspace-itemlinks">
			<a href="$value[url]">查看详情</a>
			<a href="javascript:joinfavorite($value[itemid]);">收藏</a>
			<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$value[itemid]', 300);">分享</a>
			<!--{if !empty($channels['menus']['group'])}-->
			<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=group&amp;itemid=$value[itemid]', 300);">圈子</a>
			<!--{/if}-->
			<a href="{B_URL}/pm.php?action=send&amp;uid=$value[uid]" target="_blank">联系我</a>
			<a href="{S_URL}/batch.manage.php?itemid=$value[itemid]" target="_blank">管理</a>
		</p>
	</li>
	<!--{/loop}-->
</ul>
<!--{/if}-->

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->
