<?exit?>
<ul class="xspace-listtab">
	<!--{loop $modellist $value}-->
	<li$value[active]><a href="#uid/$uid/action/spacelist/type/model/mid/$value[mid]#">$value[modelalias]</a></li>
	<!--{/loop}-->
	<!--{if !empty($hidemodellist)}-->
	<li id="xspace-myentry" class="xspace-sublist" onmouseover="showHideCatList('show', this.id, 'xspace-catlist', 5, 30);" onmouseout="showHideCatList('hide', this.id, 'xspace-catlist');"><a href="#">更多</a></li>
	<!--{/if}-->
</ul>
<!--{if !empty($hidemodellist)}-->
	<div id="xspace-catlist" class="xspace-sublistitem" onmouseover="showHideCatList('show', 'xspace-myentry', this.id, 5, 30);" onmouseout="showHideCatList('hide', 'xspace-myentry', this.id);">
		<ul>
			<!--{loop $hidemodellist $value}-->
			<li><a href="#uid/$uid/action/spacelist/type/model/mid/#$value[mid]">$value[modelalias]</a></li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{/if}-->

<div>
	<!--{if empty($listarr)}-->
	<div class="xspace-noticemsg">现在还没有相关投稿信息</div>
	<!--{else}-->
	<ul class="xspace-itemlist">
	<!--{loop $listarr $value}-->
		<li class="xspace-loglist"><a href="{S_URL}/m.php?name={$resultmodels[modelname]}&mo_catid={$value[catid]}" target="_blank">[{$value[name]}]</a>&nbsp&nbsp<a href="#action/model/name/{$resultmodels[modelname]}/itemid/{$value[itemid]}#" target="_blank" >{$value[subject]}</a>&nbsp&nbsp&nbsp(#date("m-d", $value["dateline"])#)&nbsp&nbsp<span>查看({$value[viewnum]})</span></li>
	<!--{/loop}-->
	</ul>
	<!--{/if}-->
</div>

<!--{if $multipage}-->
<div class="xspace-multipage">$multipage</div>
<!--{/if}-->

<!--{if !empty($space['summarylen'])}-->
<script type="text/javascript">
<!--{loop $iarr $value}-->
getbyid('xspace-item{$value[itemid]}').innerHTML = "$value[message]";
<!--{/loop}-->
</script>
<!--{/if}-->