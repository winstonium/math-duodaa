<?exit?>
<h1 class="xspace-title">$item[subject]</h1>
<p class="xspace-smalltxt">
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=up&amp;itemid=$item[itemid]&amp;uid=$item[uid]">上一篇</a> / 
	<a href="{S_URL}/batch.common.php?action=viewspace&amp;op=next&amp;itemid=$item[itemid]&amp;uid=$item[uid]">下一篇</a> &nbsp;
	#date("Y-m-d H:i:s",$item["dateline"])#
	<!--{if !empty($item['digest'])}--> / 精华($item[digest])<!--{/if}-->
	<!--{if !empty($item['top'])}-->/ 置顶($item[top])<!--{/if}-->
	<!--{if empty($item['allowreply'])}-->/ 不允许评论<!--{/if}-->
	<!--{if !empty($item['itemtypename'])}-->/ 个人分类：<a href="#uid/$item[uid]/action/spacelist/type/$item[type]/itemtypeid/$item[itemtypeid]#">$item[itemtypename]</a><!--{/if}-->
	<!--{if !empty($item['maketime'])}-->拍摄时间：#date("Y-m-d H:i:s",$item["maketime"])#<!--{/if}-->
	<!--{if !empty($item['makeaddress'])}-->拍摄地点：$item[makeaddress]<!--{/if}-->
</p>

<div class="xspace-itemdata">
	<a href="#xspace-tracks">查看( $item[viewnum] )</a> / 
	<a href="#xspace-itemreply">评论( $item[replynum] )</a> / 
	<a href="#xspace-itemform">评分( <span class="xspace-rategood" title="好评">$item[goodrate]</span> / <span class="xspace-ratebad" title="差评">$item[badrate]</span> )</a>
</div>

<div class="xspace-imagebox" >
	<script language="javascript">
	<!--
	var urlarr = new Array();
	var thearr = new Array();
	var urlid = 0;
	<!--{if $item[remoteurl]}-->
	<!--{loop $item[remoteurl] $value}-->
		thearr[0] = "$value[remoteurl]";
		thearr[1] = "$value[remoteurlname]";
		urlarr[urlid] = new Array(thearr[0], thearr[1]);
		urlid++;
	<!--{/loop}-->
	<!--{/if}-->
	//-->
	</script>
	<script language="JavaScript" src="{S_URL}/include/js/musicimg.js"></script>
	<script language="javascript" src="{S_URL}/include/js/real.js"></script>
	<script Language ="JavaScript" FOR=SMusic EVENT=OnPlayStateChange(ns)> evtPSChg(ns);</script>

	<div class="xspace-mediaframe">
		<div class="xspace-musictitle">
			<marquee behavior="scroll" scrolldelay=23 scrollamount=1 truespeed>
			  <div id="disp1" class="xspace-title" align=left>X-Space Video Player</div>
			</marquee>
		</div>
		<div class="xspace-spacevideo">
			<embed type="audio/x-pn-realaudio-plugin" id="SMusic" controls="ImageWindow"  style="width:100%;height:100%;" border="0"> 
		</div>
		<div class="xspace-musiccontrol">
			<table border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td><img name="prevt" src="{S_URL}/images/base/music/btn_prev.gif" border="0" onClick="playPrev();this.blur();" onMouseOver="imgtog('prevt',2);" onMouseOut="imgtog('prevt',3)" style="cursor:pointer;" title="前一个"></td>
				<td><img name="playt" id="playt" src="{S_URL}/images/base/music/btn_play.gif" border="0" onClick="startSMusic();this.blur();" onMouseOver="imgtog('playt',2);" onMouseOut="imgtog('playt',3)" style="cursor:pointer;" title="播放"></td>
				<td><img name="pauzt" src="{S_URL}/images/base/music/btn_pauz_off.gif" border="0" onClick="playPause();this.blur();" onMouseOver="imgtog('pauzt',2);" onMouseOut="imgtog('pauzt',3)" style="cursor:pointer;" title="暂停"></td>
				<td><img name="stopt" src="{S_URL}/images/base/music/btn_stop.gif" border="0" onClick="realStop();this.blur();" onMouseOver="imgtog('stopt',2);" onMouseOut="imgtog('stopt',3)" style="cursor:pointer;" title="停止"></td>
				<td><img name="nextt" src="{S_URL}/images/base/music/btn_next.gif" border="0" onClick="playNext();this.blur();" onMouseOver="imgtog('nextt',2);" onMouseOut="imgtog('nextt',3)" style="cursor:pointer;" title="下一个"></td>
				<td><img name="rwdt" src="{S_URL}/images/base/music/btn_rwd.gif" border=0 onClick="forward(-1);imgChange('rwdt',1);" onMouseOver="imgChange('rwdt',2);" onMouseOut="imgChange('rwdt',0);" style="cursor:pointer;" title="单步快退"></td>
				<td><img name="fwdt" src="{S_URL}/images/base/music/btn_fwd.gif" border=0 onClick="fastRew();imgChange('fwdt',1);" onMouseOver="imgChange('fwdt',2);" onMouseOut="imgChange('fwdt',0);" style="cursor:pointer;" title="单步快进"></td>
				<td><img name="tloop" src="{S_URL}/images/base/music/btn_trkloop_off.gif" onClick="chgTrkLoop();this.blur();" onMouseOver="imgtog('tloop',2);" onMouseOut="imgtog('tloop',3)" style="cursor:pointer;" title="循环播放"></td>
				<td><img name="vmute" src="{S_URL}/images/base/music/btn_mute_off.gif" border="0" onClick="setMute();this.blur();" onMouseOver="imgtog('vmute',2);" onMouseOut="imgtog('vmute',3)" style="cursor:pointer;" title="静音"></td>
				<td><img name="rept" src="{S_URL}/images/base/music/btn_rept_off.gif" border="0" onClick="chkRept();this.blur();" onMouseOver="imgtog('rept',2);" onMouseOut="imgtog('rept',3)"  style="cursor:pointer;" title="重复播放"></td>
				<td><img name="pmode" src="{S_URL}/images/base/music/btn_rndmode_off.gif" border="0" onClick="chgPMode();this.blur();" onMouseOver="imgtog('pmode',2);" onMouseOut="imgtog('pmode',3)" style="cursor:pointer;" title="顺序/随机播放"></td>
				<td>
					 <table border="0" cellspacing="0" cellpadding="0" width="98" height="22">
						<tr>
						   <td width="98" height="22" align="left" background="{S_URL}/images/base/music/bg_volmeter.gif">
							   <img id="volSlider" src="{S_URL}/images/base/music/btn_slider.gif" width="15" height="11" onMousedown="readyDrag(event);" style="position:relative;top:1px!important;top:2px;left:30px;cursor:pointer" title="音量">
						   </td>
						</tr>
					</table>
				</td>
			  </tr>
			</table>
			<table border="0" cellspacing="0" cellpadding="0" width="100%" style="line-height: 1.5em;">
				<tr>
					<td onClick="chgTimeFmt();this.blur();" nowrap>
						<span id="disp2" class="time" title ="TimeFormat(Elaps/Laps)" style="cursor:pointer;">00:00 | 00:00</span>
					</td>
					<td align="right">
						<a href="#" onClick="chkAllSel();playSel();" title="{lang tpl_file_music_selAll}">全选</a>
						<a href="#" onClick="reverseSel();playSel();" title="{lang tpl_file_music_selreverse}">反选</a>
						<a href="#" onClick="chkAllDesel();playSel();" title="{lang tpl_file_music_unsel}">取消</a>
					</td>
			  </tr>
			</table>
		</div>
		
		<div id="xspace-musiclist">
			<div id="xspace-mmList"></div>
		</div>
		
		<div style="display:none;">
			<script language="JavaScript">
				initPlayer();
				initVol();
				dspList();
			</script>
			<SCRIPT FOR=window EVENT=onload LANGUAGE="JScript">
				startSMusic();
			</SCRIPT>
			
		</div>
	</div>
</div>

<!--{if !empty($item[custom][name])}-->
<div class="xspace-addoninfo">
	<h5>$item[custom][name]</h5>
	<ul class="xspace-propertylist">
	<!--{loop $item[custom][key] $ckey $cvalue}-->
		<li><strong>$cvalue[name]</strong>:$item[custom][value][$ckey]</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div id="xspace-showmessage" class="xspace-itemmessage">
	$item[message]
</div>

<div class="xspace-msgmodule">
	<h5>影音分享</h5>
	<ul class="xspace-list">
		<li>节目地址: <script type="text/javascript">
			document.write('<input type="text" value="'+location.href+'" size="80" onmouseover="this.select();" \/>');
		</script>
		<br /><span style="padding-left: 4.5em; color: #999;">通过E-mail / MSN / QQ，把节目地址告诉你的好友</span></li>
	</ul>
</div>

<!--{eval include template('styles/space/viewspace_common.html.php', 1);}-->