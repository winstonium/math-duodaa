<?exit?>
<!--{loop $iarr $ikey $value}-->
<li><a href="$value[url]" target="_blank">$value[tagname]</a></li>
<!--{/loop}-->