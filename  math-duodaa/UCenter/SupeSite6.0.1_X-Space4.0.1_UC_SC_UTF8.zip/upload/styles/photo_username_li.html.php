<?exit?>
<!--{loop $iarr $value}-->
<li>
<a href="$value[url]" target="_blank" title="$value[spacename]"><img src="$value[photo]" width="80" height="80" border="0" /></a>
<p><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></p>
</li>
<!--{/loop}-->