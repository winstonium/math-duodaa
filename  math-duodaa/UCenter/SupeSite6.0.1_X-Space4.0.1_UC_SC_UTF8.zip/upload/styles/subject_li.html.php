<?exit?>
<!--{loop $iarr $ikey $value}-->
<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
<!--{/loop}-->