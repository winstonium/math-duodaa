<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	վ����Ѷ��ҳ

	$RCSfile: spaces.php,v $
	$Revision: 1.10 $
	$Date: 2007/06/27 17:15:09 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

$page = empty($_SGET['page'])?1:intval($_SGET['page']);
$page = $page<1?1:$page;

if(!empty($_SCONFIG['htmlindex'])) {
	$_SHTML['action'] = 'spaces';
	$_SHTML['page'] = $page;
	$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
	ehtml('get', $_SCONFIG['htmlindextime']);
	$_SCONFIG['debug'] = 0;
}

include_once(S_ROOT.'./include/common.inc.php');

$title = $lang['space'].' - '.$_SCONFIG['sitename'];
$keywords = $lang['space'];
$description = $lang['space'];

$guidearr = array();
$guidearr[] = array('url' => geturl('action/spaces'),'name' => $lang['space']);

$tplname = 'spaces_index';

$title = strip_tags($title);
$keywords = strip_tags($keywords);
$description = strip_tags($description);

include template($tplname);

ob_out();

if(!empty($_SCONFIG['htmlindex'])) {
	ehtml('make');
} else {
	maketplblockvalue('cache');
}

?>