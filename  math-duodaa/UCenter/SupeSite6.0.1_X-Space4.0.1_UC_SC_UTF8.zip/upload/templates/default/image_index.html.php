<?exit?>
{template image_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR" style="margin-bottom: 0;">
	<div class="sideR">
	
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--最新图片-->
		<!--{block name="spaceimage" parameter="order/i.dateline DESC/limit/0,6/subjectlen/14/cachetime/12000/cachename/newimage/tpl/data"}-->
		<div class="block" style="height: 320px; overflow: hidden;">
			<h3>最新上传</h3>
			<dl>
				<!--{loop $_SBLOCK['newimage'] $value}-->
				<dt><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a> <span class="smalltxt" title="共有$value[replynum]条评论">($value[replynum])</span></dt>
				<dd><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / #date("m-d h:m", $value["dateline"])#</dd>
				<!--{/loop}-->
			</dl>
		</div>
		
	</div>
	<div class="mainarea">
		
		<!--精选：本周好评最多-->
		<div class="block topblock" style="height: 190px; overflow: hidden;">
			<h3>一周好评靓图</h3>
			<!--{block name="spaceimage" parameter="dateline/604800/order/i.goodrate DESC/limit/0,5/cachetime/64400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/focusimageweek/tpl/data"}-->
			<ul class="avatarlist">
				<!--{loop $_SBLOCK['focusimageweek'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
					<ul>
						<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
						<li class="smalltxt"><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
						<li class="smalltxt"><span class="goodrate">好评: $value[goodrate]</span></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--焦点：评论最多-->
		<div id="focusimage" class="block">
			<h3 id="focusimagetabs" class="tabs">
				<a id="weektab" href="javascript:setTab('focusimage','week')" class="tab curtab">本周焦点</a>
				<a id="monthtab" href="javascript:setTab('focusimage','month')" class="tab">本月焦点</a>
				<a id="alltab" href="javascript:setTab('focusimage','all')" class="tab">焦点排行</a>
			</h3>
			<!--评论最多的相册列表(一周)-->
			<!--{block name="spaceimage" parameter="dateline/604800/order/i.replynum DESC/limit/0,16/cachetime/84400/subjectlen/28/subjectdot/1/cachename/focusimageweek/tpl/data"}-->
			<div id="week" class="tabcontent">
				<ul class="list2col" style="height: 190px; overflow: hidden;">
					<!--{loop $_SBLOCK['focusimageweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a><span class="smalltxt" title="共有$value[replynum]条评论"> ($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--评论最多的相册列表(一月)-->
			<!--{block name="spaceimage" parameter="dateline/2592000/order/i.replynum DESC/limit/0,16/cachetime/94400/subjectlen/28/subjectdot/1/cachename/focusimagemonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px; overflow: hidden;">
					<!--{loop $_SBLOCK['focusimagemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a><span class="smalltxt" title="共有$value[replynum]条评论"> ($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--评论最多的相册列表(全部)-->
			<!--{block name="spaceimage" parameter="order/i.replynum DESC/limit/0,16/cachetime/104400/subjectlen/28/subjectdot/1/cachename/focusimage/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px; overflow: hidden;">
					<!--{loop $_SBLOCK['focusimage'] $value}-->
					<li><cite><a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a><span class="smalltxt" title="共有$value[replynum]条评论"> ($value[replynum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>

<!--最新评论图片-->
<!--{block name="spaceimage" parameter="order/i.lastpost DESC/limit/0,12/cachetime/11400/subjectlen/12/showdetail/1/cachename/commendimage/tpl/data"}-->
<div class="block cleanblock">
	<h3>最新评论图片更新</h3>
	<div style="width: 100%; background: #FFF; overflow: hidden">
		<ul id="scroller" class="imgthumblist">
			<!--{loop $_SBLOCK['commendimage'] $value}-->
			<li>
				<div><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
				<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
	
		<!--月度好评-->
		<!--{block name="spaceimage" parameter="dateline/2592000/order/i.lastpost DESC/limit/0,8/cachetime/57400/subjectlen/12/showdetail/1/cachename/specialimage/tpl/data"}-->
		<div class="block" style="height: 566px; overflow: hidden;">
			<h3>月度好评图</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['specialimage'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a>
					<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
					<p class="smalltxt">上传: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a></p>
					<p class="smalltxt"><span class="goodrate">好评: $value[goodrate]</span></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">
		<!--本周点击排行-->
		<!--{block name="spaceimage" parameter="dateline/604800/order/i.viewnum DESC/limit/0,8/cachetime/84410/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/hotimage/tpl/data"}-->
		<div class="block" style="height: 567px; overflow: hidden;">
			<h3>本周点击排行</h3>
			<ul class="coverlist">
				<!--{loop $_SBLOCK['hotimage'] $value}-->
				<li>
					<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
					<ul>
						<li><h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4></li>
						<li class="smalltxt">上传: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a></li>
						<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
						<li class="smalltxt"><span class="goodrate">好评: $value[goodrate]</span>
						<!--{if $value[replynum]}--> <a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}--></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template image_footer}