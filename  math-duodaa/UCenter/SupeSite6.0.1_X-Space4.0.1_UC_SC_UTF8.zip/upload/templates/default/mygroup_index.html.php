<?exit?>
{template mygroup_header}

<div id="container">
	<div class="side1">

		<div class="block topblock" style="overflow: hidden;">
			<h3>圈子介绍</h3>
			<div class="avatar"><img src="$grouparr[logo]" alt="$grouparr[groupname]" />
			<h2><a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a></h2></div>
			<p>$grouparr[intro]</p>
		</div>
		<div class="block">
			<h3><a href="{S_URL}/batch.search.php" class="more">更多搜索</a>圈子搜索</h3>
			<ul class="msglist">
				<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" name="searchkey" id="searchkey2" class="inputsize"/>&nbsp;
				<button type="submit" name="groupsearch" value="true">搜索</button>
				</form>
			</ul>
		</div>
		<div class="block">
			<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/members#" class="more">所有成员</a>最新成员</h3>
			<ul class="avatarList">
				<!--{block name="groupuser" parameter="gid/$_SGET[gid]/flag/1,2,3/order/g.dateline DESC/limit/0,9/cachetime/11900/cachename/groupuser/tpl/data"}-->
				<!--{loop $_SBLOCK['groupuser'] $value}-->
					<li><a href="#uid/$value[uid]#"><img src="$value[photo]" alt="$value[username]" /><span>$value[username]</span></a></li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="content1">
		<!--{block name="spaceblog" parameter="type/blog/gid/$_SGET[gid]/order/i.dateline DESC/limit/0,10/subjectlen/37/cachetime/11800/cachename/newblog/tpl/data"}--><!--推荐日志-->
		<div class="msglist">
			<h3 class="topblock"><a href="#action/mygroup/gid/$_SGET[gid]/op/list#" class="more">更多</a><strong style="font-weight: bold;">最新日志</strong></h3>
			<div id="group-recommend" class="tabcontent">
			<ul>
				<!--{if $_SBLOCK['newblog']}-->
					<!--{loop $_SBLOCK['newblog'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				<!--{else}-->
					<li>暂无最新博文</li>
				<!--{/if}-->
			</ul>
			</div>
		</div>

		<!--{block name="spaceimage" parameter="showdetail/1/gid/$_SGET[gid]/order/i.dateline DESC/limit/0,8/cachetime/11800/cachename/newimage/tpl/data"}--><!--推荐图片-->
		<!--{if $_SBLOCK['newimage']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list#" class="more">更多</a><strong style="font-weight: bold;">最新图片</strong></h3>
				<div id="group-recommend" class="tabcontent">
				<ul class="imgthumblist">
					<!--{loop $_SBLOCK['newimage'] $value}-->
					<li class="smallthumb">
						<div><a href="$value[url]" title="$value[subject], by $value[username]"><img src="$value[image]" alt="$value[subject]" /></a></div>
						<p><a href="$value[url]">$value[subject]</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				</div>
			</div>
		<!--{/if}-->
		<!--{block name="spacegoods" parameter="showdetail/1/gid/$_SGET[gid]/order/i.dateline DESC/limit/0,10/cachetime/11800/cachename/newgoods/tpl/data"}--><!--推荐商品-->
		<!--{if $_SBLOCK['newgoods']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list#" class="more">更多</a><strong style="font-weight: bold;">最新商品</strong></h3>
				<div id="group-recommend" class="tabcontent">
				<ul class="imgthumblist">
					<!--{loop $_SBLOCK['newgoods'] $value}-->
					<li class="smallthumb">
						<div><a href="$value[url]" title="$value[subject], by $value[username]"><img src="$value[image]" alt="$value[subject]" /></a></div>
						<p><a href="$value[url]">$value[subject]</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				</div>
			</div>
		<!--{/if}-->
		
		<!--{block name="spacefile" parameter="gid/$_SGET[gid]/order/i.dateline DESC/limit/0,10/subjectlen/37/cachetime/11800/cachename/newfile/tpl/data"}--><!--推荐文件-->
		<!--{if $_SBLOCK['newfile']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list#" class="more">更多</a><strong style="font-weight: bold;">最新文件</strong></h3>
				<div id="group-recommend" class="tabcontent">
				<ul>
					<!--{loop $_SBLOCK['newfile'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
				</div>
			</div>
		<!--{/if}-->
		
		<!--{block name="spacelink" parameter="gid/$_SGET[gid]/order/i.dateline DESC/limit/0,10/subjectlen/37/cachetime/11800/cachename/newlink/tpl/data"}--><!--推荐书签-->
		<!--{if $_SBLOCK['newlink']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list#" class="more">更多</a><strong style="font-weight: bold;">最新书签</strong></h3>
				<div id="group-recommend" class="tabcontent">
				<ul>
					<!--{loop $_SBLOCK['newlink'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
				</div>
			</div>
		<!--{/if}-->
		
		<!--{block name="spacevideo" parameter="showdetail/1/gid/$_SGET[gid]/order/i.dateline DESC/limit/0,10/cachetime/11800/cachename/newvideo/tpl/data"}--><!--推荐影音-->
		<!--{if $_SBLOCK['newvideo']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list#" class="more">更多</a><strong style="font-weight: bold;">最新影音</strong></h3>
				<div id="group-recommend" class="tabcontent">
				<ul class="imgthumblist">
					<!--{loop $_SBLOCK['newvideo'] $value}-->
						<li class="smallthumb">
						<div><a href="$value[url]" title="$value[subject], by $value[username]"><img src="$value[image]" alt="$value[subject]" /></a></div>
						<p><a href="$value[url]">$value[subject]</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				</div>
			</div>
		<!--{/if}-->
		
		<!--{block name="spaceblog" parameter="notype/1/gid/$_SGET[gid]/gdigest/1/order/i.dateline DESC/limit/0,10/subjectlen/37/cachetime/14500/cachename/gdigestlist/tpl/data"}-->
		<!--{if $_SBLOCK['gdigestlist']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/digest#" class="more">更多</a>精华博文</h3>
				<ul>
					<!--{loop $_SBLOCK['gdigestlist'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->

		<!--{if empty($_SCONFIG['ucmode'])}-->
		<!--{block name="bbsthread" parameter="sgid/$_SGET[gid]/order/t.dateline DESC/limit/0,10/subjectlen/37/cachetime/1900/subjectlen/40/subjectdot/1/cachename/threadlist/tpl/data"}-->
		<!--{if $_SBLOCK['threadlist']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs#" class="more">更多</a>圈内讨论</h3>
				<ul>
					<!--{loop $_SBLOCK['threadlist'] $value}-->
						<li><cite><a href="#uid/$value[authorid]#" target="_blank">$value[author]</a></cite>[帖子] <a href="{B_URL}/viewthread.php?tid=$value[tid]&extra=page%3D1" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--{block name="recommend" parameter="gid/$_SGET[gid]/order/g.dateline DESC/limit/0,10/subjectlen/37/cachetime/11900/cachename/recommendlist/tpl/data"}-->
		<!--{if $_SBLOCK['recommendlist']}-->
			<div class="msglist">
				<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/recommend#" class="more">更多</a>圈内成员推荐阅读</h3>
				<div id="group-recommend" class="tabcontent">
				<ul>
					<!--{loop $_SBLOCK['recommendlist'] $value}-->
						<li><cite><a href="#uid/$value[guid]#" target="_blank">$value[gusername]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
				</div>
			</div>
		<!--{/if}-->

	</div>
	<div class="side2">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div class="block" style="overflow: hidden;">
			<h3>圈子公告</h3>
			<p>$grouparr[announcements]</p>
		</div>
		<div class="block" style="zoom:1; overflow: hidden;">
			<!--{block name="userspace" parameter="uid/$grouparr[uid]/limit/0,1/cachetime/91800/cachename/space/tpl/data"}--><!--圈主信息-->
			<h3><a href="#uid/$grouparr[uid]#" class="more">个人空间</a>圈主介绍</h3>
			<a href="#uid/$grouparr[uid]#" title="$_SBLOCK['space'][0]['spacename']"><img id="groupadmin" src="$_SBLOCK['space'][0]['photo']" alt="$_SBLOCK['space'][0]['spacename']" /></a>
			<p>$grouparr[selfintro]</p>
		</div>
		<div class="block">
			<!--{block name="group" parameter="lastpost/604800/order/g.usernum DESC/limit/0,9/cachetime/14400/cachename/hotgroup/tpl/data"}--><!--本周热门圈子-->
			<h3>本周热门圈子</h3>
			<ul class="avatarList">
				<!--{loop $_SBLOCK['hotgroup'] $value}-->
					<li><a href="#action/mygroup/gid/$value[gid]#" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /><span>$value[groupname]</span></a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

{template mygroup_footer}