<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>您的位置：
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>投票</h1>
</div>
<div id="panel">
	<h3>投票:$poll[subject]</h3>
	<p>投票人数:$poll[votersnum]</p>
	<p>开始时间($poll[dateline])-更新时间($poll[updatetime])</p>
	<p id="pollsummary">投票说明:$poll[summary]</p>
	<form id="pollform" action="#action/poll/php/1#" method="post">
		<fieldset id="pollresult" style="display: none;">
			<legend>投票结果</legend>
			<ul>
			<!--{loop $poll[options] $key $options}-->
				<li>
					$options[name]
					<p>
						<span class="pollnum">得票:$options[num] / $options[percent]%</span>
						<span class="pollpercent"><span style="width: $options[percent]%;">&nbsp;</span></span>
					</p>
				</li>
			<!--{/loop}-->
			</ul>
		</fieldset>
		<script language="javascript" type="text/javascript">
		function showresult() {
		var result=getbyid('pollresult');
		if (result.style.display=='none') result.style.display='block'; else result.style.display='none';
		}
		</script>
		<fieldset id="dopoll">
			<legend>投票</legend>
			<ul>
			<!--{loop $poll[options] $okey $options}-->
				<li>
					<!--{if $poll[ismulti]}-->
					<input type="checkbox" id="votekey-$okey" name="votekey[]" value="$okey" class="votekey" />
					<!--{else}-->
					<input type="radio" id="votekey-$okey" name="votekey[]" value="$okey" class="votekey"/>
					<!--{/if}-->
					<label for="votekey-$okey">$options[name]</label>
				</li>
			<!--{/loop}-->
			</ul>
			<input type="hidden" name="pollid" value="$poll[pollid]" />
			<input type="hidden" name="pollsubmit" value="yes" />
			<button id="dovote" name="pollbtn" type="submit" value="true">投票</button>
			&nbsp;<button type="button" onclick="showresult();">查看结果</button>
		</fieldset>
	</form>
</div>

{template site_footer}