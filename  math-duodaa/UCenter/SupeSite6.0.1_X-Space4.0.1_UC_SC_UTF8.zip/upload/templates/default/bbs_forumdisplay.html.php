<?exit?>
{template bbs_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="content" style="background: none; margin-bottom: 0.5em;">
	$ads2[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">

		<div class="block topblock">
			<h3>$forum[name]</h3>
			<!--子版块-->
			<!--{block name="bbsforum" parameter="fup/$fid/allowblog/1/order/displayorder/limit/0,100/cachetime/28800/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subarr'] $value}-->
				<li><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->
		</div>

		<!--月度关注热点-->
		<!--{block name="bbsthread" parameter="fid/$fid/dateline/2592000/order/views DESC/limit/0,10/cachetime/97200/cachename/hotthread/tpl/data"}-->
		<!--{if $_SBLOCK['hotthread']}-->
		<div class="block">
			<h3>月度关注热点</h3>
			<dl>
				<!--{loop $_SBLOCK['hotthread'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a></dt>
				<!--{/loop}-->
			</dl>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<!--根分类最新日志列表-->
		<!--{if $forum['type'] != 'group'}-->
		<!--{block name="bbsthread" parameter="perpage/20/fid/$fid/showdetail/1/messagelen/160/subjectlen/40/order/dateline DESC/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		<div class="block topblock">
			<a href="javascript:;" onclick="ColExpAllIntro('threadlist',this)" class="more minus">只列出标题</a>
			<h3>帖子列表</h3>
			<ul id="threadlist" class="messagelist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4>
						<em class="smalltxt"><a href="#uid/$value[authorid]#" target="_blank">$value[author]</a></em>
						<a href="$value[url]" target="_blank">$value[subject]</a>
					</h4>
					<p class="smalltxt">
						发表于: #date("Y-m-d", $value["dateline"])# 
						<!--{if $value[replies]}--><a href="$value[url]" target="_blank" class="replynum">回复: $value[replies]</a><!--{/if}-->
					</p>
					<p>$value[message] <a href="$value[url]" target="_blank">...全文</a></p>
				</li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[newlist_multipage]}-->
				$_SBLOCK[newlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
			
		</div>
		<!--{/if}-->
		<!--{/if}-->

		<!--{if $_SGET['page']<2 && !empty($_SBLOCK['subarr'])}-->
		<!--{loop $_SBLOCK['subarr'] $key $value}-->
		<!--{eval $cachetime=1800+$key*5;}-->
		<!--{block name="bbsthread" parameter="fid/$value[fid]/order/dateline DESC/limit/0,20/cachetime/$cachetime/cachename/subthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['subthreadlist']}-->
		<div class="block">
			<a href="#action/forumdisplay/fid/$value[fid]#" class="more">更多</a>
			<h3><a href="#action/forumdisplay/fid/$value[fid]#">$value[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<!--{if !empty($ads2['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads2['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads2[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template bbs_footer}
