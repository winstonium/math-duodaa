<?exit?>
{template site_header}<!-- 调用站点site_header.html.php模板文件 -->

<h3>欢迎使用SupeSite自定义频道</h3>
在频道模板页面中，您可以通过 SupeSite 强大的模块功能，进行自由组合，对Discuz!论坛、X-Space个人空间上面的数据信息，进行灵活聚合展示，来创建自己的频道页面。<br />
下面给出的是一个模块使用范例：<br />
显示的就是利用日志模块，来分页显示站内所有日志的模板范例(按发布时间递减排序，每页显示20条，并显示内容摘要)，供您参考。您可以使用Dreamweaver等编辑器对本模板进行可视化编辑。

<!-- 模块使用范例开始 -->

<!-- 模块代码 -->
<!-- 这里是模块代码,将满足条件的数据获取到变量$_SBLOCK[变量名]中,使用模块生成向导来生成 -->
<!--{block name="spaceblog" parameter="order/dateline DESC/perpage/20/showdetail/1/messagelen/500/cachename/bloglist/tpl/data"}-->
<ul>
<h4>站内日志</h4>
<!-- 这里使用loop方法对模块获取的数据$_SBLOCK[变量名]进行循环显示 -->
<!--{loop $_SBLOCK['bloglist'] $value}-->
	<li>
	<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
	<a href="#uid/$value[uid]#" target="_blank">$value[username]</a>
	<br />
	$value[message]
	</li>
<!--{/loop}-->
</ul>

<!-- 这里为分页信息$_SBLOCK[变量名_multipage] -->
<div>$_SBLOCK[bloglist_multipage]</div>

<!-- 模块使用范例结束 -->

<!-- 调用站点site_footer.html.php模板文件 -->
{template site_footer}