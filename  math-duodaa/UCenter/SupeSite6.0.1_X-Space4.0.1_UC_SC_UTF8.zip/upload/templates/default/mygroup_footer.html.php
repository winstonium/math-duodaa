<?exit?>
	<!-- Footer -->
	<div id="footer">
		
		<!--{if empty($thecat['catid'])}-->
		<!--{if !empty($ads['pagefootad'])}-->
		<div class="banner">
			$ads[pagefootad]
		</div>
		<!--{/if}-->
		<!--{else}-->
		<!--{if !empty($ads2['pagefootad'])}-->
		<div class="banner">
			$ads2[pagefootad]
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<p>
			<a href="{S_URL}/">$_SCONFIG[sitename]</a> | 
			<a href="{B_URL}/" target="_blank">交流论坛</a> | 
			<a href="{S_URL}/?action/site/type/panel">快捷面板</a> | 
			<a href="{S_URL}/?action/site/type/map">站点地图</a> | 
			<a href="{S_URL}/?action/site/type/link">友情链接</a> | 
			<a href="{S_URL}/?action/spaces">空间列表</a> | 
			<a href="{S_URL}/archiver/">站点存档</a> | 
			<a href="mailto:$_SCONFIG[adminemail]">联系我们</a>
		</p>
		<p id="copyright">
			Powered by <a href="http://www.supesite.com" target="_blank"><strong>Supe<span>Site</span></strong></a> <em title="RELEASE:<?=S_RELEASE?>"><?=S_VER?></em> 
			&copy; 2001-2008 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
			<br />{eval debuginfo();}
		</p>
	</div>
	<!-- /Footer -->
</div>
</body>
</html>