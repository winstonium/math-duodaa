<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>您的位置：
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>欢迎 $_SGLOBAL[supe_username_show] 的到来</h1>
</div>
<div id="panel">
	<ul class="quicklink">

		<!--{if $_SGLOBAL[supe_uid]}-->
			<li><a href="#uid/$_SGLOBAL[supe_uid]#" class="myspace" target="_blank" style="color:red;font-weight:bold;">我的个人空间</a></li>
			<!--{if !empty($_SGLOBAL[member][havespace])}-->
			<li><a href="{S_URL}/spacecp.php?docp=me" class="spacemng" target="_blank">管理我的空间</a></li>
			<!--{else}-->
			<li><a href="#action/register#" class="spacesignup" target="_blank">升级我的空间</a></li>
			<!--{/if}-->
			<!--{if $_SGLOBAL[member][groupid] == 1}-->
			<li><a href="{S_URL}/admincp.php" class="sitemng" target="_blank">站点管理平台</a></li>
			<!--{/if}-->
			<li><a href="{S_URL}/batch.login.php?action=logout" class="logout">安全退出</a></li>
		<!--{else}-->
			<li><a href="#action/login#" class="login">登录站点</a></li>
			<li><a href="{B_URL}/register.php?referer={S_URL}/index.php" class="register" target="_blank">注册用户</a></li>
		<!--{/if}-->
		<li><a href="{S_URL}/" class="sitehome" target="_blank">站点首页</a></li>
		<li><a href="{B_URL}/" class="bbs" target="_blank">交流论坛</a></li>
	</ul>
</div>


{template site_footer}