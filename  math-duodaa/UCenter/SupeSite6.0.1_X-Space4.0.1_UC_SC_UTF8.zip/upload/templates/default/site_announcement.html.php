<?exit?>
{template site_header}

<div id="navigation" class="simplepage">
	<p>您的位置：
		<a href="{S_URL}/">首页</a>
		&gt;&gt; $title
	</p>
	<h1>站点公告</h1>
</div>
<div id="panel">
	<ul class="messagelist">
	<!--{loop $listvalue $value}-->
		<li>
			<h4><a href="$value[url]">$value[subject]</a></h4>
			<p class="smalltxt">发布人: $value[author]&nbsp;&nbsp;开始时间: $value[starttime]&nbsp;&nbsp;结束时间: $value[endtime]</p>
			<p>$value[message]</p>
		</li>
	<!--{/loop}-->
	</ul>
	<div class="pages" style="">
		$multipage
	</div>
</div>

{template site_footer}