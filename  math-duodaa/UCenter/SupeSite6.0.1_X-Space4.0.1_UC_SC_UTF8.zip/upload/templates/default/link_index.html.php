<?exit?>
{template link_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div class="block cleanblock" style="height: 250px; overflow: hidden;">
			<h3>想更方便的添加书签?</h3>
			<a href="{S_URL}/spacecp.php?action=linkmove&amp;op=rightclick" style="display: block; margin: 10px 5px 5px; background: #FFF; height: 48px; line-height: 48px; text-align: center; font-weight: bold;"><img src="{S_URL}/templates/$_SCONFIG[template]/images/thumb_bookmark_xpi.gif" alt="安装书签右键" title="安装书签右键" style="vertical-align: middle;" />安装书签右键</a>
			<p style="margin: 0; padding:5px;line-height:150%;">安装后，今后您到任意网页浏览，鼠标右键菜单中将出现将当前链接加入到自己个人空间书签的快速菜单，点击一下就可以提交书签，非常方便。不想使用的时候，也可以轻松卸载。</p>
		</div>
	</div>

	<div class="mainarea">
		
		<div class="block topblock" style="height: 178px; overflow: hidden;">
			<h3>一周好评排行</h3>
			<!--{block name="spacelink" parameter="dateline/604800/order/i.goodrate DESC/limit/0,12/subjectlen/35/cachetime/83400/cachename/goodrateweek/tpl/data"}-->
			<div>
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['goodrateweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" title="{$value[subjectall]}">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
		<div class="block" style="height: 178px; overflow: hidden;">
			<h3>最新添加书签</h3>
			<!--{block name="spacelink" parameter="order/i.dateline DESC/limit/0,12/subjectlen/35/cachetime/15400/cachename/newlink/tpl/data"}-->
			<div>
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['newlink'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" title="{$value[subjectall]}">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>

<div class="contentR">

	<div class="sideR">
		<!-- 月度点击热点 -->
		<!--{block name="spacelink" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,10/cachetime/83400/subjectlen/17/cachename/viewhot/tpl/data"}-->
		<div class="block" style="height: 270px; overflow: hidden;">
			<h3>月度点击热点</h3>
			<dl>
				<!--{loop $_SBLOCK['viewhot'] $value}-->
				<dt>
					<a href="$value[url]" title="{$value[subjectall]}" target="_blank">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span>
				</dt>
				<!--{/loop}-->
			</dl>
		</div>
	</div>
	
	<div class="mainarea">
		<div id="hotlink" class="block" style="height: 270px; overflow: hidden;">
			<h3 id="hotlinktabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotlink','week')" class="tab curtab">本周热点</a>
				<a id="monthtab" href="javascript:setTab('hotlink','month')" class="tab">本月热点</a>
				<a id="alltab" href="javascript:setTab('hotlink','all')" class="tab">热点排行</a>
			</h3>
			<!--热门书签列表(一周)-->
			<!--{block name="spacelink" parameter="dateline/604800/order/i.replynum DESC/limit/0,20/cachetime/85400/subjectlen/40/subjectdot/1/cachename/hotlinkweek/tpl/data"}-->
			<div  id="week" class="tabcontent">
				<ul class="list2col" style="height: 210px;">
					<!--{loop $_SBLOCK['hotlinkweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a> <a href="#uid/$value[uid]/action/viewspace/itemid/$value[itemid]#" target="_blank" class="smalltxt" title="共有$value[viewnum]条评论">($value[viewnum])</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门书签列表(一月)-->
			<!--{block name="spacelink" parameter="dateline/2592000/order/i.replynum DESC/limit/0,20/cachetime/97200/subjectlen/40/subjectdot/1/cachename/hotlinkmonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 210px;">
					<!--{loop $_SBLOCK['hotlinkmonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a> <a href="#uid/$value[uid]/action/viewspace/itemid/$value[itemid]#" target="_blank" class="smalltxt" title="共有$value[viewnum]条评论">($value[viewnum])</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门书签列表(全部)-->
			<!--{block name="spacelink" parameter="order/i.replynum DESC/limit/0,20/cachetime/97800/subjectlen/40/subjectdot/1/cachename/hotlink/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 210px;">
					<!--{loop $_SBLOCK['hotlink'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a> <a href="#uid/$value[uid]/action/viewspace/itemid/$value[itemid]#" target="_blank" class="smalltxt" title="共有$value[viewnum]条评论">($value[viewnum])</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<!-- 最新评论更新 -->
		<!--{block name="spacelink" parameter="order/i.lastpost DESC/limit/0,20/cachetime/15400/cachename/lastlink/tpl/data"}-->
		<div class="block">
			<h3>最新评论书签</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['lastlink'] $value}-->
				<dt>
					<a href="$value[url]" title="{$value[subjectall]}" target="_blank">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span>
				</dt>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<div class="mainarea">
		<div class="blockcategorylist">
			<!--{loop $_SBLOCK['category'] $ckey $cat}-->
			<!--{eval $ctime=2800+30*$ckey;}-->
			<!--{block name="spacelink" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/28/cachename/sublist/tpl/data"}-->
			<!--{if $_SBLOCK['sublist']}-->
			<div class="blockcategory">
				<h3>
					<a href="#action/category/catid/$cat[catid]#" class="more">更多</a>
					<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
				</h3>
				<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['sublist'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a> <a href="#uid/$value[uid]/action/viewspace/itemid/$value[itemid]#" target="_blank" class="smalltxt" title="共有$value[viewnum]条评论">($value[viewnum])</a></li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--{/loop}-->
		</div>
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template link_footer}