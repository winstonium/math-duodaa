<?exit?>
{template goods_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!-- 同城商品 -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<button value="true" type="submit" name="goodscitysearch">同城<br />商品</button>
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
			</form>
		</div>
	</div>
	<div class="mainarea">
		
		<!-- 一周热点点击商品 -->
		<div class="block topblock" style="height: 178px; overflow: hidden;">
			<h3>一周热点点击商品</h3>
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.viewnum DESC/limit/0,12/cachetime/45400/subjectlen/40/subjectdot/1/showdetail/1/cachename/spacialgoods/tpl/data"}-->
			<div>
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['spacialgoods'] $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a> <span class="smalltxt">($value[price]元)</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<!-- 月度点击热点 -->
		<!--{block name="spacegoods" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,2/cachetime/83400/subjectlen/30/showdetail/1/cachename/promotion/tpl/data"}-->
		<div class="block" style="height: 186px; overflow: hidden;">
			<h3>月度点击热点</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['promotion'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[thumb]" width="78" height="78" alt="$value[subjectall]" /></a>
					<p><a href="$value[url]" target="_blank">$value[subject]</a></p>
					<p class="smalltxt">价格: <strong class="price">$value[price]元</strong></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">
	
		<!--最新上架商品-->
		<!--{block name="spacegoods" parameter="order/i.dateline DESC/limit/0,5/subjectlen/14/subjectdot/1/showdetail/1/cachetime/11900/cachename/weekcommendgoods/tpl/data"}-->
		<div class="block">
			<h3>最新上架商品</h3>
			<ul class="avatarlist" style="height: 160px; overflow: hidden;">
				<!--{loop $_SBLOCK['weekcommendgoods'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
					<ul>
						<li><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a></li>
						<li class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></li>
						<li>价格: <strong class="price">$value[price]元</strong></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<div class="block" style="height: 540px; overflow: hidden;">
			<h3>最新评论商品</h3>
			<!--{block name="spacegoods" parameter="order/i.lastpost DESC/limit/0,11/showdetail/1/cachetime/12900/cachename/newgoods/tpl/data"}-->
			<dl>
				<!--{loop $_SBLOCK['newgoods'] $value}-->
				<dt><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a></dt>
				<dd>卖家:<a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a> / 价格: $value[price]元</dd>
				<!--{/loop}-->
			</dl>
		</div>
	</div>
	<div class="mainarea">
	
		<!--热点商品列表-->
		<div id="hotgoods" class="block" style="height: 540px; overflow: hidden;">
			<h3 id="hotgoodstabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotgoods','week')" class="tab curtab">本周热点</a>
				<a id="monthtab" href="javascript:setTab('hotgoods','month')" class="tab">本月热点</a>
				<a id="alltab" href="javascript:setTab('hotgoods','all')" class="tab">热点热行</a>
			</h3>
			<!--评论最多的商品(一周)-->
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.replynum DESC/limit/0,8/cachetime/64400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotgoodsweek/tpl/data"}-->
			<div id="week" class="tabcontent">
				<ul class="coverlist">
					<!--{loop $_SBLOCK['hotgoodsweek'] $value}-->
					<li>
						<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a></h4></li>
							<li class="smalltxt">价格: <strong class="price">$value[price]元</strong></li>
							<li class="smalltxt">卖家: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> <span class="smalltxt">($value[province])</span><!--{/if}--></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
								<!--{if $value[goodrate]}--><span class="goodrate">好评: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--评论最多的商品(一月)-->
			<!--{block name="spacegoods" parameter="dateline/2592000/order/i.replynum DESC/limit/0,8/cachetime/78400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotgoodsmonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="coverlist">
					<!--{loop $_SBLOCK['hotgoodsmonth'] $value}-->
					<li>
						<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a></h4></li>
							<li class="smalltxt">价格: <strong class="price">$value[price]元</strong></li>
							<li class="smalltxt">卖家: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> <span class="smalltxt">($value[province])</span><!--{/if}--></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
								<!--{if $value[goodrate]}--><span class="goodrate">好评: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--评论最多的商品(全部)-->
			<!--{block name="spacegoods" parameter="order/i.replynum DESC/limit/0,8/cachetime/89400/subjectlen/13/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotgoods/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="coverlist">
					<!--{loop $_SBLOCK['hotgoods'] $value}-->
					<li>
						<div class="cover"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
						<ul>
							<li><h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a></h4></li>
							<li class="smalltxt">价格: <strong class="price">$value[price]元</strong></li>
							<li class="smalltxt">卖家: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> <span class="smalltxt">($value[province])</span><!--{/if}--></li>
							<!--{if $value['message']}--><li class="smalltxt">$value[message]</li><!--{/if}-->
							<li class="smalltxt">
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
								<!--{if $value[goodrate]}--><span class="goodrate">好评: $value[goodrate]</span><!--{/if}-->&nbsp;
							</li>
						</ul>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template goods_footer}