<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>您的位置：
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>安全提问验证</h1>
</div>
<div id="panel">
<div class="loginarea">
	<form id="loginform" action="{S_URL}/batch.login.php?action=login" method="post">
		<!--{if empty($_SCONFIG['ucmode']) && $member['secques']}-->
		<p>问　题 <select name="questionid">
		<option value="1">母亲的名字</option>
		<option value="2">爷爷的名字</option>
		<option value="3">父亲出生的城市</option>
		<option value="4">您其中一位老师名字</option>
		<option value="5">您个人计算机的型号</option>
		<option value="6">您最喜欢的餐馆名称</option>
		<option value="7">驾驶执照最后四位数</option>
		</select>
		</p>
		<p>答　案 <input type="text" name="answer" size="25" /></p>
		<!--{/if}-->
		<!--{if empty($_SCONFIG['noseccode'])}-->
		<p class="imgsecode">验证码 <input type="text" size="10" id="xspace-seccode" name="seccode" value="" />
		<img id="imgsecode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" align="absmiddle"/>
		<!--{/if}-->
		<p>　　　 <button value="true" type="submit" id="securitysubmit" name="securitysubmit">登录</button></p>
		
		
		<input type="hidden" name="uid" value="$member[uid]">
		<input type="hidden" name="password" value="$member[password]" />
		<input type="hidden" name="cookietime" value="$cookietime" />
		<input type="hidden" name="loginsubmit_secques" value="yes" />
		<input type="hidden" name="refer" value="$refer" />
	</form>
</div>
<div class="tips">
	<ul>
		<!--{if empty($_SCONFIG['ucmode'])}-->
		<li>由于您启用了安全提问功能，因此需要您进行第二次安全提问验证方可登录。</li>
		<li>启用安全提问功能，可以加强帐号的安全性。</li>
		<!--{/if}-->
		<!--{if empty($_SCONFIG['noseccode'])}-->
		<li>由于管理员启用了验证码功能，因此需要您进行第二次安全验证方可登录。</li>
		<li>启用验证码功能，可以加强防灌水机制。</li>
		<!--{/if}-->

	</ul>
</div>
</div>
{template site_footer}