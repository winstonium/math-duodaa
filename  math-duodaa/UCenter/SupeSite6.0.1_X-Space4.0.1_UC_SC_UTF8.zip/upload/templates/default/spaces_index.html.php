<?exit?>
{template spaces_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!-- 同城空间 -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<button type="submit" name="usersearch" value="true">同城<br />空间</button>
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script>
				<script language="javascript" type="text/javascript">showcity('city', '');</script>
			</form>
		</div>

		<!--一周更新排行榜-->
		<!--{block name="userspace" parameter="lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>一周更新排行榜</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[photo]" width="78" height="78" alt="$value[spacename]" /></a>
					<p><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></p>
					<p class="smalltxt">信息数: $value[spaceallnum]</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">

		<!--空间之星-->
		<!--{if $page<2}-->
		<!--{block name="userspace" parameter="isstar/1/showdetail/1/limit/0,100/order/u.lastpost DESC/cachetime/17400/cachename/spacestar/tpl/data"}-->
		<div class="block topblock">
			<h3>空间之星</h3>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['spacestar'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
					<em class="smalltxt">信息数: $value[spaceallnum]</em>
					<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
					<p class="msgintro">$value[announcement]&nbsp;</p>
					<p class="msginfo smalltxt"><a href="$value[url]" target="_blank" class="author">$value[username]</a><!--{if $value['province']}--> $value[province]<!--{/if}--><!--{if $value['city']}-->/ $value[city]<!--{/if}-->, 创建于: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, 最后更新: #date("Y-m-d", $value["lastpost"])#<!--{/if}--></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
		<!--最近更新-->
		<!--{block name="userspace" parameter="perpage/20/showdetail/1/order/u.lastpost DESC/cachename/lastpostspace/tpl/data"}-->
		<div class="block topblock">
			<h3>空间更新列表</h3>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['lastpostspace'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
					<em class="smalltxt">信息数: $value[spaceallnum]</em>
					<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
					<p class="msgintro">$value[announcement]&nbsp;</p>
					<p class="msginfo smalltxt"><a href="$value[url]" target="_blank" class="author">$value[username]</a>
					<!--{if $value['province']}--> $value[province]<!--{/if}-->
					<!--{if $value['city']}-->/ $value[city]<!--{/if}--> &nbsp;
					创建于: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, 最后更新: #date("Y-m-d", $value["lastpost"])#<!--{/if}--></p>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{if $_SBLOCK[lastpostspace_multipage]}-->
			<div class="pages">
				$_SBLOCK[lastpostspace_multipage]
			</div>
			<!--{/if}-->
		</div>
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

{template spaces_footer}