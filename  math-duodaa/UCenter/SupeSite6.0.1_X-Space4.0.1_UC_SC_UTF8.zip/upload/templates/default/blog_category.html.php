<?exit?>
{template blog_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="banner">
	$ads2[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">
		<div class="block topblock">
			<h3>$thecat[name]</h3>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{else}-->
			<div class="catepic">
				<p>$thecat[name]</p>
			</div>
			<!--{/if}-->
			<!--{block name="category" parameter="upid/$thecat[catid]/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['subarr'] $value}-->
				<li><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->
		</div>
		
		<!--月度关注热点-->
		<!--{block name="spaceblog" parameter="dateline/2592000/catid/$thecat[subcatid]/order/i.viewnum DESC/limit/0,15/cachetime/17200/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>本月关注热点</h3>
			<dl>
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a></dt>
				<dd><a href="#uid/$value[uid]#">$value[username]</a> / <a href="$value[url]" target="_blank">点击($value[viewnum])</a></dd>
				<!--{/loop}-->
			</dl>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<!--根分类最新日志列表-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="spaceblog" parameter="perpage/20/catid/$thecat[subcatid]/order/i.dateline DESC/showspacename/1/showdetail/1/messagelen/300/messagedot/1/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		<div class="block topblock">
			<a href="javascript:;" onclick="ColExpAllIntro('bloglist',this)" class="more minus">只列出标题</a>
			<h3>日志列表</h3>
			<ul id="bloglist" class="messagelist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4>
						<em class="smalltxt listauthor">
							<a href="#uid/$value[uid]#" target="_blank">$value[username]</a>
							<!--{if $value[province]}-->($value[province])<!--{/if}-->
						</em>
						<a href="$value[url]" target="_blank">$value[subject]</a>
					</h4>
					<p class="smalltxt">
						发表于 #date("Y-m-d", $value["dateline"])# 
						<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
						<!--{if $value[goodrate]}--><span class="goodrate">好评: $value[goodrate]</span><!--{/if}-->
					</p>
					<p>$value[message] <a href="$value[url]" target="_blank">...全文</a></p>
					<!--{if !empty($value['tags'])}-->
					<p class="smalltxt">标签:
					<!--{loop $value['tags'] $tag}-->
					<!--{eval $newtag = rawurlencode($tag);}-->
					<a href="#action/tag/tagname/$newtag#" target="_blank">$tag</a> 
					<!--{/loop}-->
					</p>
					<!--{/if}-->
				</li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[newlist_multipage]}-->
				$_SBLOCK[newlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
			
		</div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--论坛资源列表-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/20/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->
		<div class="block">
			<h3>论坛资源</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
				$_SBLOCK[bbsthreadlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->

		<!--{if $_SGET['page']<2}-->
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spaceblog" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/40/cachename/subnewlist/tpl/data"}-->
		<!--{if $_SBLOCK['subnewlist']}-->
		<div class="block">
			<a href="#action/category/catid/$cat[catid]#" class="more">更多</a>
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="list2col">
				<!--{loop $_SBLOCK['subnewlist'] $value}-->
				<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<!--{if !empty($ads2['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads2['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads2[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template blog_footer}