<?exit?>
{template goods_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="banner">
	$ads2[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">
		
		<div class="block topblock">
			<h3>$thecat[name]</h3>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			<!--{block name="category" parameter="upid/$thecat[catid]/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		
		<!--站内推荐商品-->
		<!--{block name="spacegoods" parameter="dateline/2592000/catid/$thecat[subcatid]/order/i.viewnum DESC/limit/0,15/cachetime/75400/subjectlen/20/showdetail/1/cachename/hotgoods/tpl/data"}-->
		<div class="block">
			<h3>本月关注排行</h3>
			<ul class="imgtitlelist">
			<!--{loop $_SBLOCK['hotgoods'] $value}-->
				<li><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="" /></a><p><a href="$value[url]" target="_blank">$value[subject]</a></p><p class="smalltxt">卖家: <a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a></p></li>
			<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">

		<!--当前分类最新列表-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="spacegoods" parameter="catid/$thecat[subcatid]/order/i.dateline DESC/perpage/15/showdetail/1/messagelen/68/messagedot/1/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		
		<div class="block topblock">
			<h3>商品列表</h3>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subject]" /></a></div>
					<em class="smalltxt">价格: <strong class="price">$value[price]元</strong></em>
					<h4><a href="$value[url]" target="_blank">$value[subject]</a> <span class="smalltxt" title="共有$value[replynum]条评论">($value[replynum])</span></h4>
					<p class="msgintro">$value[message]...</p>
					<p class="msginfo smalltxt">卖家：<a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> <!--{if $value['province']}--> $value[province]<!--{/if}--><!--{if $value['city']}--> $value[city]<!--{/if}-->, <a href="{B_URL}/pm.php?action=send&uid=$value[uid]" target="_blank" class="author">联系</a></p>
				</li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[newlist_multipage]}-->
				$_SBLOCK[newlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
		</div>
		
		<!--{/if}-->
		<!--{/if}-->

		<!--论坛资源列表-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/20/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->		
		<div class="block">
			<h3>论坛资源</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
				$_SBLOCK[bbsthreadlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->
		
		<!--子分类最新列表-->
		<!--{if $_SGET['page']<2}-->
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="spacegoods" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,5/cachetime/$ctime/showdetail/1/messagelen/150/messagedot/1/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->
		<div class="block">
			<a href="#action/category/catid/$cat[catid]#" class="more">更多</a>
			<h3>
				<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
			</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['sublist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subject]" /></a>
					<h4><a href="$value[url]" target="_blank">$value[subject]</a> <span class="smalltxt">($value[viewnum]人点击,$value[replynum]人评论)</span></h4>
					<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
					<p>价格: <strong>$value[price]</strong> 元</p>
					<p>卖家: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a> (<a href="{B_URL}/pm.php?action=send&uid=$value[uid]" target="_blank">联系</a>)</p>
					<p>地区: $value[province] $value[city]</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<!--{if !empty($ads2['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads2['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads2[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->
	
{template goods_footer}