<?exit?>
{template group_header}
<!-- Content内容 -->
<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->
<div class="contentR">
	<div class="sideR">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!--最新成立圈子-->
		<!--{block name="group" parameter="order/g.dateline DESC/limit/0,8/cachetime/13900/cachename/newgroup/tpl/data"}-->
		<div class="block" style="height: 419px; overflow: hidden;">
			<h3>最新成立</h3>
			<dl>
				<!--{loop $_SBLOCK['newgroup'] $value}-->
				<dt><a href="$value[url]" target="_blank">$value[groupname]</a></dt>
				<dd>圈主：<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / 成员：$value[usernum]</dd>
				<!--{/loop}-->
			</dl>
		</div>
	</div>
	<div class="mainarea">

		<!--最近更新-->
		<!--{block name="group" parameter="order/g.lastpost DESC/limit/0,5/cachetime/9900/cachename/updategroup/tpl/data"}-->
		<div class="block topblock">
			<h3>最近更新</h3>
			<ul class="avatarlist" style="height: 160px; overflow: hidden;">
				<!--{loop $_SBLOCK['updategroup'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<ul>
						<li><a href="$value[url]" target="_blank" title="$value[groupname]" style="color: #000;">$value[groupname]</a></li>
						<li class="smalltxt">圈主: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a></li>
						<li class="smalltxt"><a href="javascript:joingroup('$value[gid]');" class="joingroupbtn" title="加入本圈">加入本圈</a><span class="users">成员: $value[usernum]</span></li>
					</ul>
				</li>
				<!--{/loop}-->
			</ul>
		</div>

		<!--{block name="group" parameter="lastpost/604800/order/g.usernum DESC/limit/0,3/showdetail/1/cachetime/29900/cachename/weekhotgroup/tpl/data"}-->
		<div class="block">
			<h3>周热门圈子</h3>
			<ul class="thumbmsglist" style="height: 290px; overflow: hidden;">
				<!--{loop $_SBLOCK['weekhotgroup'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<em class="smalltxt users">成员：<strong>$value[usernum]</strong></em>
					<h4><a href="$value[url]" target="_blank">$value[groupname]</a></h4>
					<p class="msgintro">$value[intro]</p>
					<p class="msginfo smalltxt">圈主: <a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a>, 最近更新: #date("Y-m-d", $value["lastpost"])#, <a href="javascript:joingroup('$value[gid]');" class="joingroup">加入本圈</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>

	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<!--{block name="group" parameter="order/g.usernum DESC/limit/0,3/cachetime/89900/cachename/hotgroup/tpl/data"}-->
		<div class="block" style="height: 240px; overflow: hidden;">
			<h3>超人气圈子</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['hotgroup'] $value}-->
				<li><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a>
					<p><a href="$value[url]" target="_blank">$value[groupname]</a></p>
					<p class="smalltxt">圈主：<a href="#uid/$value[uid]#" target="_blank">$value[username]</a></p>
					<p class="smalltxt">成员：$value[usernum]</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<div class="mainarea">
		
		<div id="infos" class="block" style="height: 240px; overflow: hidden;">
			<h3 id="infostabs" class="tabs">
				<a id="newinfotab" href="javascript:setTab('infos','newinfo');" class="tab curtab">最新文章</a>
				<a id="hotinfotab" href="javascript:setTab('infos','hotinfo');" class="tab">周点击榜</a>
			</h3>
			<!--最新文章-->
			<!--{block name="spaceblog" parameter="notype/1/allgroup/1/showgroupname/1/order/i.dateline DESC/limit/0,10/cachetime/9880/cachename/newinfo/tpl/data"}-->
			<div id="newinfo" class="tabcontent">
				<ul class="list2col" style="height: 190px;">
					<!--{if $_SBLOCK['newinfo']}-->
						<!--{loop $_SBLOCK['newinfo'] $value}-->
							<li><cite><a href="#action/mygroup/gid/$value[gid]#" target="_blank">$value[g_groupname]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{else}-->
						<li>暂无信息</li>
					<!--{/if}-->
				</ul>
			</div>
			<!--最热文章-->
			<!--{block name="spaceblog" parameter="notype/1/allgroup/1/showgroupname/1/dateline/604800/order/i.viewnum DESC/limit/0,10/cachetime/61980/cachename/hotinfo/tpl/data"}-->
			<div id="hotinfo" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px;">
					<!--{if $_SBLOCK['hotinfo']}-->
						<!--{loop $_SBLOCK['newinfo'] $value}-->
							<li><cite><a href="#action/mygroup/gid/$value[gid]#" target="_blank">$value[g_groupname]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{else}-->
						<li>暂无信息</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="contentR">
	<div class="sideR">
		<!--{block name="group" parameter="order/g.usernum DESC/limit/0,20/cachetime/91900/cachename/grouplist/tpl/data"}-->
		<div class="block">
			<h3>圈子排行</h3>
			<dl>
				<!--{loop $_SBLOCK['grouplist'] $value}-->
				<dt><a href="$value[url]" target="_blank">$value[groupname]</a></dt>
				<dd>圈主：<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / 成员：$value[usernum]</dd>
				<!--{/loop}-->
			</dl>
		</div>
	</div>
	<div class="mainarea">
		
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
			<div class="blockcategory">
				<h3>
					<a href="#action/category/catid/$cat[catid]#" class="more">更多</a>
					<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
				</h3>
				<!--{block name="group" parameter="catid/$cat[subcatid]/order/g.lastpost DESC/limit/0,11/cachetime/$ctime/cachename/catgroup/tpl/data"}-->
				<!--{loop $_SBLOCK['catgroup'] $key $value}-->
					<!--{if $key==0}-->
						<div style="float: left; width: 105px; overflow: hidden; margin-left: -5px;">
							<ul class="avatarlist">
								<li>
									<div><a href="$value[url]"><img src="$value[logo]" alt="$value[groupname]" style="width: 75px; height: 75px;" /></a></div>
									<ul>
										<li><a href="$value[url]" target="_blank">$value[groupname]</a></li>
										<li><a href="#uid/$value[uid]#" style="color: #090;" target="_blank">$value[username]</a></li>
										<li class="smalltxt"><span class="users">成员: $value[usernum]</span></li>
										<li class="smalltxt"><a href="javascript:joingroup('$value[gid]');" class="joingroup" title="加入本圈">加入本圈</a></li>
									</ul>
								</li>
							
							</ul>
						</div>
					<!--{elseif $key>0}-->
						<!--{if $key==1}-->
						<ul class="msgtitlelist" style="margin-left: 100px; margin-right: 10px;">
						<!--{/if}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[groupname]</a></li>
					<!--{/if}-->
				<!--{/loop}-->
				</ul>
			</div>
		<!--{/loop}-->
		</div>
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template group_footer}