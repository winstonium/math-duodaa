<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$_SCONFIG[sitename]  $_SCONFIG[seotitle]- Powered by SupeSite</title>
<meta name="keywords" content="$_SCONFIG[sitename] $_SCONFIG[seokeywords]" />
<meta name="description" content="$_SCONFIG[sitename] $_SCONFIG[seodescription]" />
<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/style.css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
</head>
<body>
<!--{eval $ads = getad('system', 'indexad', '1');}-->
<div id="wrap">
	<div id="header">
		<table border="0" cellpadding="0" cellspacing="0" id="headertab">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img src="{S_URL}/templates/$_SCONFIG[template]/images/logo.gif" alt="$_SCONFIG[sitename]" style="border: none;" /></a>
				</td>
				<td id="topmenu">
					<ul>
						<li><a href="{S_URL}/">首页</a></li>
						<!--{loop $channels['menus'] $value}-->
						<li><a href="$value[url]">$value[name]</a></li>
						<!--{/loop}-->
						<li><a href="{S_URL}/batch.search.php">搜索</a></li>
					</ul>
				</td>
			</tr>
		</table>

		<!--{if !empty($ads['pageheadad'])}-->
			<div class="banner">$ads[pageheadad]</div>
			<!--{/if}-->
		<div id="menu">

		<!--{if !empty($channels['types']['news'])}-->
			<!--{block name="category" parameter="type/news/isroot/1/order/c.displayorder/limit/0,10/cachetime/36800/cachename/category_news/tpl/data"}-->
			<dl>
				<dt><strong><a href="#action/news#">$channels['menus']['news']['name']</a></strong></dt>
				<!--{loop $_SBLOCK['category_news'] $value}-->
				<dd><a href="$value[url]" title="$value[name]">$value[name]</a></dd>
				<!--{/loop}-->
			</dl>
		<!--{/if}-->
		
		<!--{if !empty($channels['types']['blog'])}-->
			<!--{block name="category" parameter="type/blog/isroot/1/order/c.displayorder/limit/0,10/cachetime/37800/cachename/category_blog/tpl/data"}-->
			<dl>
				<dt><strong><a href="#action/blog#">$channels['menus']['blog']['name']</a></strong></dt>
				<!--{loop $_SBLOCK['category_blog'] $value}-->
				<dd><a href="$value[url]" title="$value[name]">$value[name]</a></dd>
				<!--{/loop}-->
			</dl>
		<!--{/if}-->
		
		<!--{if !empty($channels['types']['image'])}-->
			<!--{block name="category" parameter="type/image/isroot/1/order/c.displayorder/limit/0,10/cachetime/39800/cachename/category_image/tpl/data"}-->
			<dl>
				<dt><strong><a href="#action/image#">$channels['menus']['image']['name']</a></strong></dt>
				<!--{loop $_SBLOCK['category_image'] $value}-->
				<dd><a href="$value[url]" title="$value[name]">$value[name]</a></dd>
				<!--{/loop}-->
			</dl>
		<!--{/if}-->
		
		<!--{if !empty($channels['types']['video'])}-->
			<!--{block name="category" parameter="type/video/isroot/1/order/c.displayorder/limit/0,10/cachetime/39800/cachename/category_video/tpl/data"}-->
			<dl>
				<dt><strong><a href="#action/video#">$channels['menus']['video']['name']</a></strong></dt>
				<!--{loop $_SBLOCK['category_video'] $value}-->
				<dd><a href="$value[url]" title="$value[name]">$value[name]</a></dd>
				<!--{/loop}-->
			</dl>
		<!--{/if}-->
		
		<!--{if !empty($channels['menus']['group'])}-->
			<!--{block name="category" parameter="type/group/isroot/1/order/c.displayorder/limit/0,10/cachetime/39800/cachename/category_group/tpl/data"}-->
			<dl>
				<dt><strong><a href="#action/group#">$channels['menus']['group']['name']</a></strong></dt>
				<!--{loop $_SBLOCK['category_group'] $value}-->
				<dd><a href="$value[url]" title="$value[name]">$value[name]</a></dd>
				<!--{/loop}-->
			</dl>
		<!--{/if}-->

		</div>
		<div id="navigation">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
			</form>
			<p>您的位置：<a href="{S_URL}/">首页</a></p>
		</div>
	</div>

	<!--{if !empty($ads['pagecenterad'])}-->
	<div class="banner">
		$ads[pagecenterad]
	</div>
	<!--{/if}-->

	<div class="content" style="margin-bottom: 10px;">
		<div class="sideR">
			<!-- 用户面板 -->
			<div id="userpanel" class="block topblock">
				<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
			</div>
			<!--{block name="announcement" parameter="order/displayorder/limit/0,7/cachetime/96400/subjectlen/30/cachename/announce/tpl/data"}-->
			<div id="announcement" class="block" style="height: 165px; overflow: hidden;">
				<h3>站点公告</h3>
				<ul class="msgtitlelist">
				<!--{if empty($_SBLOCK['announce'])}-->
					<li>暂时没有公告</li>
				<!--{else}-->
				<!--{loop $_SBLOCK['announce'] $value}-->
					<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				<!--{/if}-->
				</ul>
			</div>
			<!--{block name="poll" parameter="order/dateline DESC/limit/0,5/cachetime/80000/subjectlen/30/cachename/poll/tpl/data"}-->
			<div id="polls" class="block" style="height: 149px; overflow: hidden;">
				<h3>站点调查</h3>
				<ul class="msgtitlelist">
				<!--{if empty($_SBLOCK['poll'])}-->
					<li>暂时没有调查</li>
				<!--{else}-->
					<!--{loop $_SBLOCK['poll'] $value}-->
						<li><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				<!--{/if}-->
				</ul>
			</div>
		</div>

		<div class="sideL">
			<!--最新日志图片幻灯片 开始-->
			<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/cachetime/13930/cachename/picblog/tpl/data"}-->
			<div id="slideimg" class="block cleanblock topblock" style="height: 205px; overflow: hidden;">
			<!--{if !empty( $_SBLOCK['picblog'])}-->
			<script type="text/javascript" language="javascript">
			<!--			
			var xsTextBar = 1; //是否显示文字链接，1为显示，0为不显示
			var xsPlayBtn = 0; //是否显示播放按钮，1显示，0为不显示
			var xsImgSize = new Array(200,167); //幻灯图片的尺寸，格式为“宽度,高度”
		
			var xsImgs = new Array();
			var xsImgLinks = new Array();
			var xsImgTexts = new Array();
			
			<!--{eval $i=0;}-->
			<!--{loop $_SBLOCK['picblog'] $key $value}-->
			xsImgs[$i] = "$value[a_thumbpath]";
			xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
			xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
			<!--{eval $i++;}-->
			<!--{/loop}-->
			//-->
			</script>
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
			<!--{/if}-->
			</div>

			<!--{block name="spaceblog" parameter="notype/1/dateline/604800/order/i.goodrate DESC/limit/0,8/cachetime/14400/subjectlen/28/cachename/recommendnews/tpl/data"}-->
			<div class="block" style="height: 216px; overflow: hidden;">
				<h3>一周好评榜</h3>
				<ul class="msgtitlelist">
				<!--{if !empty($_SBLOCK['recommendnews'])}-->
				<!--{loop $_SBLOCK['recommendnews'] $value}-->
					<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				<!--{/if}-->
				</ul>
			</div>
		</div>

		<div class="mainarea">
			<!--最新图文头条-->
			<!--{block name="spacenews" parameter="showattach/1/showdetail/1/order/i.dateline DESC/limit/0,1/subjectlen/34/subjectdot/1/messagelen/80/messagedot/1/cachetime/18600/cachename/headnews/tpl/data"}-->
			<div id="headline" class="block cleanblock topblock">
			<!--{if !empty($_SBLOCK[headnews])}-->
			<!--{loop $_SBLOCK[headnews] $value}-->
				<!--{if !empty($value[a_thumbpath])}--><a href="$value[url]"><img src="$value[a_thumbpath]" alt="" /></a><!--{/if}-->
				<strong><a href="$value[url]">$value[subject]</a></strong>
				<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
			</div>
			
			<!-- 一周回复热点 -->
			<!--{block name="spaceblog" parameter="notype/1/dateline/604800/order/i.replynum DESC/subjectlen/34/limit/0,15/cachetime/13600/showspacename/1/cachename/newinfos/tpl/data"}-->
			<div id="focus">
				<ul class="msgtitlelist linelist">
				<!--{loop $_SBLOCK[newinfos] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite>[<a href="#action/$value[type]#">{$lang[$value[type]]}</a>] <a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	
	<!--{if !empty($channels['types']['news'])}-->
	<div id="newsblock">
		<div class="blocktitle">
			<a href="#action/news#" class="more">更多</a>
			<h2>资讯</h2>
		</div>
		<div class="content" style="margin-bottom: 10px;">
			<div class="sideR">
				<!-- 一个月点击排行榜 -->
				<!--{block name="spacenews" parameter="dateline/2592000/haveattach/1/showattach/1/order/i.viewnum DESC/showdetail/1/messagelen/180/messagedot/1/limit/0,1/cachetime/98800/subjectlen/30/cachename/hotnews/tpl/data"}-->
				<div id="topicnews" class="block" style="height: 240px; overflow: hidden;">
					<h3>月点击图文头条</h3>
					<!--{loop $_SBLOCK[hotnews] $value}-->
					<p class="blockintro"><a href="$value[url]"><img src="$value[a_thumbpath]" class="blockintroimg" alt="$value[subject]" /></a>$value[message]... <a href="$value[url]">阅读更多</a></p>
					<!--{/loop}-->
				</div>
			</div>
			<div class="sideL">
			
			<!--{block name="spacenews" parameter="order/i.lastpost DESC/limit/0,9/cachetime/14400/subjectlen/30/cachename/spacialnews/tpl/data"}-->
				<div class="block" style="height: 240px; overflow: hidden;">
					<h3>评论更新</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK[spacialnews] $value}-->
						<li><a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
			<!--{block name="spacenews" parameter="order/i.dateline DESC/subjectlen/40/subjectdot/1/limit/0,10/cachetime/10800/cachename/newnews/tpl/data"}-->
				<ul class="msgtitlelist linelist">
					<!--{loop $_SBLOCK['newnews'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->

	<!--{if !empty($channels['types']['blog'])}-->
	<div id="blogblock">
		<div class="blocktitle">
			<a href="#action/blog#" class="more">更多</a>
			<h2>日志</h2>
		</div>
		<div class="content" style="margin-bottom: 10px;">
			<div class="sideR">
			<!--{block name="userspace" parameter="order/u.spaceallnum DESC/limit/0,10/cachetime/44000/cachename/topspace/tpl/data"}-->
				<div id="hotspace" class="block stat" style="height: 240px;">
					<a href="#action/spaces#" class="more">所有空间</a>
					<h3>空间排行</h3>
					<ol>
					<!--{loop $_SBLOCK['topspace'] $value}-->
						<li><em>$value[spaceallnum]</em><a href="$value[url]">$value[spacename]</a></li>
					<!--{/loop}-->
					</ol>
				</div>
			</div>
			<div class="sideL">
				<!-- 同城空间 -->
				<div id="cityspace" class="block cleanblock">
					<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
					<form action="{S_URL}/batch.search.php" method="post">
						<button type="submit" name="usersearch" value="true">同城<br />空间</button>
						<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
					</form>
				</div>
				<!--{block name="tag" parameter="order/spaceallnum DESC/limit/0,20/cachetime/21600/cachename/hottag/tpl/data"}-->
				<div id="hottag" class="block boldblock">
					<h3>热门标签</h3>
					<div style="height: 10.5em;">
					<!--{loop $_SBLOCK['hottag'] $value}-->
						<a href="$value[url]">$value[tagname]<em>($value[spaceallnum])</em></a>
					<!--{/loop}-->
					</div>
				</div>
			</div>
			<div class="mainarea">
				<!-- 周评论榜 -->
				<!--{block name="spaceblog" parameter="dateline/604800/order/i.replynum DESC/subjectlen/40/subjectdot/1/limit/0,10/cachetime/18400/cachename/hotblog/tpl/data"}-->
				<ul class="msgtitlelist linelist">
					<!--{loop $_SBLOCK['hotblog'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->
	
	<!--{if !empty($channels['menus']['group'])}-->
	<div id="groupblock">
		<div class="blocktitle">
			<a href="#action/group#" class="more">更多</a>
			<h2>圈子</h2>
		</div>
		<div class="contentL" style="margin-bottom: 10px;">
			<div class="sideL">
			<!--{block name="group" parameter="order/g.dateline DESC/limit/0,8/cachetime/19900/cachename/newgroup/tpl/data"}-->
				<div id="commendimage" class="block" style="height: 214px; overflow: hidden;">
					<h3>最新圈子</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['newgroup'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank" title="圈主">$value[username]</a></cite><a href="$value[url]" target="_blank">$value[groupname]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
				<!--最近更新-->
				<!--{block name="group" parameter="order/g.lastpost DESC/limit/0,12/cachetime/11000/cachename/updategroup/tpl/data"}-->
				<div id="updategroup">
					<ul class="imgthumblist" style="margin-left: -4px; width: 559px;">
					<!--{loop $_SBLOCK['updategroup'] $value}-->
						<li class="smallthumb">
							<div><a href="$value[url]" title="$value[groupname], by $value[username]"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
							<p><a href="$value[url]">$value[groupname]</a><span class="smalltxt" title="共有$value[usernum]位会员"> ($value[usernum])</span></p>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!--{/if}-->

	<!--{if !empty($channels['types']['image'])}-->
	<div id="imageblock">
		<div class="blocktitle">
			<a href="#action/image#" class="more">更多</a>
			<h2>图片</h2>
		</div>
		<div class="contentL" style="margin-bottom: 10px;">
			<div class="sideL">
			<!--{block name="spaceimage" parameter="order/i.dateline DESC/limit/0,8/subjectlen/20/cachetime/27900/cachename/newimage/tpl/data"}-->
				<div class="block" style="height: 214px; overflow: hidden;">
					<h3>最新图片</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['newimage'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
				<!--{block name="spaceimage" parameter="dateline/604800/order/i.replynum DESC/limit/0,12/showdetail/1/subjectlen/14/cachetime/29000/cachename/newimage/tpl/data"}-->
				<div id="newimage">
					<ul class="imgthumblist" style="margin-left: -4px; width: 559px;">
					<!--{loop $_SBLOCK['newimage'] $value}-->
						<li class="smallthumb">
							<div><a href="$value[url]" title="$value[subject], by $value[username]"><img src="$value[image]" alt="$value[subject]" /></a></div>
							<p><a href="$value[url]">$value[subject]</a><span class="smalltxt" title="共有$value[imagenum]幅图片"> ($value[imagenum])</span></p>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!--{/if}-->

	
	<!--{if !empty($channels['types']['video'])}-->
	<div id="videoblock">
		<div class="blocktitle">
			<a href="#action/video#" class="more">更多</a>
			<h2>影音</h2>
		</div>
		<div class="contentL" style="margin-bottom: 10px;">
			<div class="sideL">
			<!--{block name="spacevideo" parameter="order/i.dateline DESC/limit/0,8/subjectlen/14/cachetime/10400/cachename/newvideo/tpl/data"}-->
				<div class="block" style="height: 214px; overflow: hidden;">
					<h3>最新影音</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['newvideo'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
				<!--{block name="spacevideo" parameter="dateline/604800/order/i.viewnum DESC/limit/0,12/cachetime/64400/subjectlen/13/showdetail/1/messagelen/40/messagedot/1/cachename/hotratevideo/tpl/data"}-->
				<div id="hotratevideo">
					<ul class="imgthumblist" style="margin-left: -4px; width: 559px;">
					<!--{loop $_SBLOCK['hotratevideo'] $value}-->
						<li class="smallthumb">
							<div><a href="$value[url]" title="$value[subject], by $value[username]"><img src="$value[image]" alt="$value[subject]" /></a></div>
							<p><a href="$value[url]">$value[subject]</a></p>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!--{/if}-->

	<!--{if !empty($channels['types']['goods'])}-->
	<div id="goodsblock">
		<div class="blocktitle">
			<a href="#action/goods#" class="more">更多</a>
			<h2>商品</h2>
		</div>
		<div class="contentL" style="margin-bottom: 10px;">
			<!-- 右侧版块 -->
			<div class="sideL">
			<!--{block name="spacegoods" parameter="order/i.dateline DESC/limit/0,8/subjectlen/20/cachetime/15980/cachename/newgoods/tpl/data"}-->
				<div id="newgoods" class="block" style="height: 215px; overflow: hidden;">
					<h3>最新商品</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['newgoods'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
			<!-- 一周热评 -->
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.replynum DESC/subjectlen/12/limit/0,12/showdetail/1/cachetime/33800/cachename/picgoods/tpl/data"}-->
				<ul class="imgthumblist" style="margin-left: -4px; width: 559px;">
				<!--{loop $_SBLOCK['picgoods'] $value}-->
					<li class="smallthumb"><div><a href="$value[url]"><img src="$value[thumb]" alt="$value[subject]" /></a></div><p><a href="$value[url]">$value[subject]</a></p></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->
	
	<!--{if !empty($channels['types']['file'])}-->
	<div id="fileblock">
		<div class="blocktitle">
			<a href="#action/file#" class="more">更多</a>
			<h2>文件</h2>
		</div>
		<div class="content" style="margin-bottom: 10px;">
			<!-- 右侧版块 -->
			<div class="sideR">
			<!--{block name="spacefile" parameter="order/i.dateline DESC/limit/0,10/subjectlen/18/cachetime/33900/cachename/hotfile/tpl/data"}-->
				<div id="hotcommentfile" class="block">
					<h3>最新文件</h3>
					<ul class="msgtitlelist" style="height: 225px; overflow: hidden;">
					<!--{loop $_SBLOCK['hotfile'] $value}-->
						<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite><a href="$value[url]" title="$value[subjectall]">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>

			<div class="sideL">
			<!--{block name="spacefile" parameter="dateline/604800/order/i.viewnum DESC/limit/0,10/subjectlen/25/cachetime/41700/cachename/recommendfile/tpl/data"}-->
				<div id="hotfile" class="block">
					<h3>周点击榜</h3>
					<ul class="msgtitlelist" style="height: 225px; overflow: hidden;">
					<!--{loop $_SBLOCK['recommendfile'] $value}-->
						<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
			<!-- 周评论榜 -->
			<!--{block name="spacefile" parameter="dateline/604800/order/i.replynum DESC/limit/0,11/subjectlen/35/cachetime/33900/cachename/hotfile/tpl/data"}-->
				<ul class="msgtitlelist linelist">
				<!--{loop $_SBLOCK['hotfile'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->
	
	<!--{if !empty($channels['types']['link'])}-->
	<div id="linkblock">
		<div class="blocktitle">
			<a href="#action/link#" class="more">更多</a>
			<h2>书签</h2>
		</div>
		<div class="content" style="margin-bottom: 10px;">
			<!-- 右侧版块 -->
			<div class="sideR">
			<!--{block name="spacelink" parameter="order/i.dateline DESC/limit/0,10/subjectlen/30/cachetime/14500/cachename/newlink/tpl/data"}-->
				<div id="newlink" class="block">
					<h3>最新书签</h3>
					<ul class="msgtitlelist" style="height: 215px; overflow: hidden;">
					<!--{loop $_SBLOCK['newlink'] $value}-->
						<li><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="sideL">
			<!--{block name="spacelink" parameter="dateline/604800/order/i.viewnum DESC/limit/0,10/subjectlen/25/cachetime/31700/cachename/hotlink/tpl/data"}-->
				<div id="hotlink" class="block">
					<h3>周点击榜</h3>
					<ul class="msgtitlelist" style="height: 215px; overflow: hidden;">
					<!--{loop $_SBLOCK['hotlink'] $value}-->
						<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
			<!--{block name="spacelink" parameter="dateline/604800/order/i.replynum DESC/subjectlen/40/subjectdot/1/limit/0,10/cachetime/41100/cachename/recommendlink/tpl/data"}-->
				<ul class="msgtitlelist linelist">
				<!--{loop $_SBLOCK['recommendlink'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])#</cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->
	

	<!--{if !empty($channels['menus']['bbs'])}-->
	<div id="bbsblock">
		<div class="blocktitle">
			<a href="#action/bbs#" class="more">更多</a>
			<h2>论坛</h2>
		</div>
		<div class="content">
			<div class="sideR">
			<!--{block name="bbsthread" parameter="dateline/604800/order/t.views DESC/limit/0,11/subjectlen/20/cachetime/28800/cachename/hotthread/tpl/data"}-->
				<div class="block" style="height: 272px; overflow: hidden;">
					<h3>周点击榜</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthread'] $value}-->
						<li><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a><span class="smalltxt" title="查看$value[views]次"> ($value[views])</span></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="sideL">
			<!--{block name="bbsthread" parameter="dateline/604800/order/t.replies DESC/limit/0,5/cachetime/26800/subjectlen/24/cachename/recommendthread/tpl/data"}-->
				<div class="block" style="height: 145px; overflow: hidden;">
					<h3>周评论榜</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['recommendthread'] $value}-->
						<li><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a><span class="smalltxt" title="共有$value[replies]条回复"> ($value[replies])</span></li>
					<!--{/loop}-->
					</ul>
				</div>
			<!--{block name="bbsmember" parameter="regdate/2592000/order/posts DESC/limit/0,10/cachetime/50000/cachename/topuser/tpl/data"}-->
				<div class="block" style="height: 119px; overflow: hidden;">
					<h3>本月新会员榜</h3>
					<ul class="list2col" style="padding: 0;">
					<!--{loop $_SBLOCK['topuser'] $value}-->
						<li style="width: 82px;"><a href="$value[url]">$value[username]</a><span class="smalltxt" title="发帖$value[posts]篇"> ($value[posts])</span></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
			<!--{block name="bbsthread" parameter="order/t.lastpost DESC/subjectlen/40/limit/0,11/cachetime/5630/cachename/newthread/tpl/data"}-->
				<ul class="msgtitlelist linelist">
				<!--{loop $_SBLOCK['newthread'] $value}-->
					<li><cite><a href="#uid/$value[authorid]/action/viewpro#" target="_blank">$value[author]</a></cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->

	<!--{if !empty($_SCONFIG['modelarr'])}-->
	<!--{loop $_SCONFIG['modelarr'] $key $value}-->
	<!--{eval $i=0;}-->
	<!--{eval $ctime = 98800 + $i * 30;}-->
	<div id="newsblock">
		<div class="blocktitle">
			<a href="{S_URL}/m.php?name=$key" class="more">更多</a>
			<h2>$value</h2>
		</div>
		<div class="content" style="margin-bottom: 10px;">
			<div class="sideR">
				<!-- 一个月点击排行榜 -->
				<!--{block name="model" parameter="name/$key/dateline/2592000/haveattach/1/showattach/1/order/i.viewnum DESC/showdetail/1/messagelen/180/messagedot/1/limit/0,1/cachetime/$ctime/subjectlen/30/cachename/hotmodel/tpl/data"}-->
				<div id="topicnews" class="block" style="height: 240px; overflow: hidden;">
					<h3>月点击图文头条</h3>
					<!--{loop $_SBLOCK[hotmodel] $value}-->
					<p class="blockintro"><a href="$value[url]"><img src="$value[subjectimage]" class="blockintroimg" alt="$value[subject]" /></a>$value[message]... <a href="$value[url]">阅读更多</a></p>
					<!--{/loop}-->
				</div>
			</div>
			<div class="sideL">
			<!--{eval $stime = 14400 + $i * 30;}-->
			<!--{block name="model" parameter="name/$key/order/i.lastpost DESC/limit/0,9/cachetime/$stime/subjectlen/30/cachename/spacialmodel/tpl/data"}-->
				<div class="block" style="height: 240px; overflow: hidden;">
					<h3>评论更新</h3>
					<ul class="msgtitlelist">
					<!--{loop $_SBLOCK[spacialmodel] $value}-->
						<li><a href="$value[url]" target="_blank">$value[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="mainarea">
			<!--{eval $ntime = 10800 + $i * 30;}-->
			<!--{block name="model" parameter="name/$key/order/i.dateline DESC/subjectlen/40/subjectdot/1/limit/0,10/cachetime/$ntime/cachename/newsmodel/tpl/data"}-->
				<ul class="msgtitlelist linelist">
					<!--{loop $_SBLOCK['newsmodel'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{eval $i++;}-->
	<!--{/loop}-->
	<!--{/if}-->

	<!--{if !empty($_SCONFIG['showindex'])}-->
		<!--{block name="friendlink" parameter="order/displayorder/limit/0,$_SCONFIG['showindex']/cachetime/11600/namelen/32/cachename/friendlink/tpl/data"}-->
		<!--{eval $imglink=$txtlink="";}-->
		<!--{loop $_SBLOCK['friendlink'] $value}-->
		<!--{if $value[logo]}-->
		<!--{eval $imglink .="<li><a href=\"".$value[url]."\" target=\"_blank\"><img src=\"".$value[logo]."\" alt=\"".$value[description]."\" /></a></li>";}-->
		<!--{else}-->
		<!--{eval $txtlink .= "<li><a href=\"".$value[url]."\" title=\"".$value[description]."\" target=\"_blank\">".$value[name]."</a></li>";}-->
		<!--{/if}-->
		<!--{/loop}-->
		<div id="links">
			<a class="more" href="#action/site/type/link#">更多链接</a>
			<h3>友情链接</h3>
			<ul class="pic">
			$imglink
			</ul>
			<ul class="text">
			$txtlink
			</ul>
		</div>
		<!-- /链接 -->
	<!--{/if}-->
	</div>
	<!-- /Content -->
	<!-- Footer -->
	<div id="footer">
		<!--{if !empty($ads['pagefootad'])}-->
		<div class="banner">
			$ads[pagefootad]
		</div>
		<!--{/if}-->
		<p>
			<a href="{S_URL}/">$_SCONFIG[sitename]</a> | 
			<a href="{B_URL}/" target="_blank">交流论坛</a> | 
			<a href="{S_URL}/?action/site/type/panel">快捷面板</a> | 
			<a href="{S_URL}/?action/site/type/map">站点地图</a> | 
			<a href="{S_URL}/?action/site/type/link">友情链接</a> | 
			<a href="{S_URL}/?action/spaces">空间列表</a> | 
			<a href="{S_URL}/archiver/">站点存档</a> | 
			<a href="mailto:$_SCONFIG[adminemail]">联系我们</a>
		</p>
		<p id="copyright">
			Powered by <a href="http://www.supesite.com" target="_blank"><strong>Supe<span>Site</span></strong></a> <em title="RELEASE:<?=S_RELEASE?>"><?=S_VER?></em> 
			&copy; 2001-2008 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
			<br />{eval debuginfo();}
		</p>
	</div>
	<!-- /Footer -->
</div>

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

</body>
</html>