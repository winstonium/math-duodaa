<?exit?>
{template bbs_header}

<!--{if !empty($ads3['pagecenterad'])}-->
<div class="content" style="background: none; margin-bottom: 0.5em;">
	$ads3[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">

		<!--最新更新主题-->
		<!--{block name="bbsthread" parameter="fid/$thread[fid]/limit/0,10/cachetime/24500/order/dateline DESC/cachename/newthread/tpl/data"}-->
		<!--{if $_SBLOCK['newthread']}-->
		<div class="block topblock">
			<h3>最新更新主题</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newthread'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--月度关注热点-->
		<!--{block name="bbsthread" parameter="fid/$thread[fid]/dateline/2592000/order/views DESC/limit/0,10/cachetime/97200/cachename/hotthread/tpl/data"}-->
		<!--{if $_SBLOCK['hotthread']}-->
		<div class="block">
			<h3>月度关注热点</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotthread'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<div class="block topblock">
			<h1 class="articletitle">$thread[subject]</h1>
			<p class="articleinfo">
				<span class="articlectrl">
					字体:
					<a href="javascript:;" onclick="doZoom('12');">小</a>
					<a href="javascript:;" onclick="doZoom('14');">中</a>
					<a href="javascript:;" onclick="doZoom('16');">大</a> |
					<a href="javascript:;" onclick="doPrint();" class="btnprint">打印</a>
				</span>
				<span class="smalltxt">发表于: #date('Y-n-d H:i', $thread["dateline"])# &nbsp;&nbsp; 作者: $thread[author] &nbsp;&nbsp; 来源: $_SCONFIG[sitename]</span>
			</p>

			<div id="articlebody">
				$thread[message]
				<!--{if !empty($thread['attachments'])}-->
				<div class="imginlog">
					<!--{loop $thread['attachments'] $value}-->
					<!--{if ($value['isimage'])}-->
					<p><img src="$value[attachment]"><br />$value[filename]</p>
					<!--{else}-->
					<p><img src="{S_URL}/images/base/haveattach.gif" align="absmiddle" border="0"><a href="{B_URL}/attachment.php?aid=$value[aid]" target="_blank"><strong>$value[filename]</strong></a><br />($value[dateline], Size: $value[attachsize], Downloads: $value[downloads])</p>
					<!--{/if}-->
					<!--{/loop}-->
				</div>
				<!--{/if}-->
		

				
				<br />
			</div>
		</div>
		
		<div id="commentlist" class="block">
			<!--{if $iarr}-->
			<a href="{B_URL}/post.php?action=reply&tid=$thread[tid]" target="_blank" class="more reply">我也来说两句</a>
			<a href="{B_URL}/viewthread.php?tid=$thread[tid]" target="_blank" class="more">查看全部回复</a>
			<h3>最新回复</h3>
			<ul class="commentlist">
				<!--{loop $iarr $key $post}-->
				<li>
					<h4>$post[author] <span class="smalltxt">(#date("Y-n-d H:i:s", $post["dateline"])#)</span></h4>
					<div>$post[message]</div>
					<!--{if !empty($item['posts'][$post['pid']]['attachments'])}-->
					<div class="imginlog">
						<!--{loop $item['posts'][$post['pid']]['attachments'] $post}-->
						<!--{if ($post['isimage'])}-->
						<p><img src="$post[attachment]"><br />$post[filename]</p>
						<!--{else}-->
						<p><img src="{S_URL}/images/base/haveattach.gif" align="absmiddle" border="0"><a href="{B_URL}/attachment.php?aid=$post[aid]" target="_blank"><strong>$post[filename]</strong></a><br />($post[dateline], Size: $post[attachsize], Downloads: $post[downloads])</p>
						<!--{/if}-->
						<!--{/loop}-->
					</div>
					<!--{/if}-->
				</li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->
			<div class="pages">
				<div class="xspace-page">
					<a href="{B_URL}/viewthread.php?tid=$thread[tid]" target="_blank">查看全部回复</a>
					<a href="{B_URL}/post.php?action=reply&tid=$thread[tid]" target="_blank">我也来说两句</a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /Content -->

<script language="javascript" type="text/javascript">
<!--
	addImgLink("articlebody");
	addImgLink("commentlist");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<!--{if !empty($ads3['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads3[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads3[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads3['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads3[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template bbs_footer}
