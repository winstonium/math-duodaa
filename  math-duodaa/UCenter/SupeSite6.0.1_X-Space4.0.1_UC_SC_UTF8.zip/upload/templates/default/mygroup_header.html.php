<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$title  $_SCONFIG[seotitle]- Powered by SupeSite</title>
<meta name="keywords" content="$keywords $_SCONFIG[seokeywords]" />
<meta name="description" content="$description $_SCONFIG[seodescription]" />
<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/group.css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
<!--{if !empty($grouparr[css])}-->
<style type="text/css">

$grouparr[css]

</style>
<!--{/if}-->
</head>

<body>
<div id="group_wrap">
	<!-- Header页首 -->
	<div id="group_topmenu">
		<table border="0" cellpadding="0" cellspacing="0" id="topmenu">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img src="{S_URL}/templates/$_SCONFIG[template]/images/logo.gif" alt="$_SCONFIG[sitename]" style="border: none;" /></a>
				</td>
				<td id="menutab">
					<ul>
						<li><a href="{S_URL}/">首页</a></li>
						<!--{loop $channels['menus'] $value}-->
						<li><a href="$value[url]">$value[name]</a></li>
						<!--{/loop}-->
						<li><a href="{S_URL}/batch.search.php">搜索</a></li>
					</ul>
				</td>
			</tr>
		</table>
	</div>
	<div id="group_header" style="background-image: url($grouparr['headerimage']);">
		<div id="groupname">
			<h2><a href="#action/mygroup/gid/$_SGET[gid]#" title="$grouparr['groupname']">$grouparr['groupname']</a></h2>
			<p><a href="javascript:;" onclick="javascript:setCopy('$grouparr[domain]');" title="复制圈子链接">$grouparr[domain]</a></p>
		</div>
		<div id="group_menu">
			<ul>
				<li><a href="#action/mygroup/gid/$_SGET[gid]#">圈子首页</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list#">博文更新</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/digest#">精华博文</a></li>
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/recommend#">推荐阅读</a></li>
				<!--{if empty($_SCONFIG['ucmode'])}--><li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs#">交流区</a></li><!--{/if}-->
				<li><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/members#">成员列表</a></li>
				<li><a href="{S_URL}/spacecp.php?action=mygroups&gid=$gid" target="_blank">圈子管理</a></li>
				<li class="important"><a href="javascript:;" onclick="javascript:joingroup('$_SGET[gid]');">+加入本圈</a></li>
			</ul>
		</div>
	</div>
	<!-- /Header页首 -->
