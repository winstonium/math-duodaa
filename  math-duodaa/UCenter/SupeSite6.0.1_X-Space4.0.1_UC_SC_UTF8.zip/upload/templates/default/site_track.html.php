<?exit?>
{template spaces_header}

<!-- Content内容 -->
<div class="contentR">
	<div class="sideR">

		<!--一周更新排行榜-->
		<!--{block name="userspace" parameter="lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>一周更新排行榜</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[photo]" width="78" height="78" alt="$value[spacename]" /></a>
					<p><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></p>
					<p>信息数:$value[spaceallnum]</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
	<div class="mainarea">

		<!--当前分类最新列表-->
		<div class="block topblock">
			<h3><strong>留下脚印</strong></h3>
			<ul class="thumbmsglist">
				<!--{if empty($trackarr)}-->
				<p>现在还没有人留下脚印</p>
				<!--{else}-->
				<!--{loop $trackarr $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
					<em class="smalltxt">信息数: $value[spaceallnum]</em>
					<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
					<p class="msgintro">$value[announcement]...</p>
					<p class="msginfo smalltxt"><a href="$value[url]" target="_blank" class="author">$value[username]</a><!--{if $value['province']}--> $value[province]<!--{/if}--><!--{if $value['city']}-->/ $value[city]<!--{/if}-->, 创建于: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, 最后更新: #date("Y-m-d", $value["lastpost"])#<!--{/if}--></p>
				</li>
				<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
	</div>
</div>
<!-- /Content -->

{template spaces_footer}