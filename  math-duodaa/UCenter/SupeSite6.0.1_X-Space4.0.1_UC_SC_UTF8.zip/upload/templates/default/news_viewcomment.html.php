<?exit?>
{template site_header}
<!--{eval $ads3 = getad('system', 'news', '3');}-->
<!--{if !empty($ads3['pageheadad'])}-->
<div class="adbanner">$ads3[pageheadad]</div>
<!--{/if}-->
<div id="navigation" class="simplepage">
	<p>您的位置：
		<a href="{S_URL}/">首页</a>
		&gt;&gt; 查看评论
	</p>
	<h2>查看评论</h2>
</div>
<div class="contentR">
	<div class="sideR">

		<!--月度关注热点-->
		<!--{block name="spacenews" parameter="catid/$item[catid]/dateline/2592000/order/i.replynum DESC/limit/0,10/cachetime/28800/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>月度评论热点</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<div id="commentlist" class="block topblock">
			<h1 class="articletitle">评论: <a href="#action/viewnews/itemid/$item[itemid]#">$item[subject]</a></h1>
			<p class="articleinfo smalltxt" style="text-align: center;">
				查看数: $item[viewnum] / 
				评论数: $item[replynum] / 
				好评: $item[goodrate] / 
				差评: $item[badrate]
			</p>
			<!--{if !empty($ads3['pagecenterad'])}-->
			<div class="adbox">$ads3[pagecenterad]</div>
			<!--{/if}-->
			<ul class="commentlist">
				<!--{loop $iarr $value}-->
				<li>
					<h4>
						<a href="#action/viewcomment/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#" class="more del">删除</a> 
						<a href="javascript:;" onclick="getQuote($value[cid])" class="more quote">引用</a>
						<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a><!--{/if}-->
					 	<span class="smalltxt">(#date("Y-n-d H:i:s", $value["dateline"])#, 评分: <strong>$value[rates]</strong> )</span>
					</h4>
					<div>
					<!--{if empty($value['message'])}-->
					评 <span style="font-size:16px">$value[rates]</span> 分
					<!--{else}-->
					$value[message]
					<!--{/if}-->
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $multipage}-->
			<div class="pages">
				$multipage
			</div>
			<!--{/if}-->
		</div>
		
		<div id="xspace-rates" class="block">
			<div id="xspace-rates-bg">
				<div id="xspace-rates-star" class="xspace-rates0">&nbsp;</div>
				<div id="xspace-rates-a">
					<a href="javascript:;" onmouseover="rateHover(-5);" onmouseout="rateOut();" onclick="setRateXML('-5', '$item[itemid]');">-5</a>
					<a href="javascript:;" onmouseover="rateHover(-3);" onmouseout="rateOut();" onclick="setRateXML('-3', '$item[itemid]');">-3</a>
					<a href="javascript:;" onmouseover="rateHover(-1);" onmouseout="rateOut();" onclick="setRateXML('-1', '$item[itemid]');">-1</a>
					<a href="javascript:;" onmouseover="rateHover(0);" onmouseout="rateOut();" onclick="setRateXML('0', '$item[itemid]');">-</a>
					<a href="javascript:;" onmouseover="rateHover(1);" onmouseout="rateOut();" onclick="setRateXML('1', '$item[itemid]');">+1</a>
					<a href="javascript:;" onmouseover="rateHover(3);" onmouseout="rateOut();" onclick="setRateXML('3', '$item[itemid]');">+3</a>
					<a href="javascript:;" onmouseover="rateHover(5);" onmouseout="rateOut();" onclick="setRateXML('5', '$item[itemid]');">+5</a>
				</div>
				<input type="hidden" id="xspace-rates-value" name="rates" value="0" />
			</div>
			<p>评分：<span id="xspace-rates-tip">0</span></p>
		</div>
		
		<div id="comment" class="block cleanblock">
			<h3>我来说两句</h3>
			<form id="postcomm" action="#action/viewcomment/itemid/$item[itemid]/php/1#" method="post">
				<p><label for="message">内容:</label><textarea id="message" name="message" onfocus="showcode()" onkeydown="ctlent(event,'postcomm');"></textarea></p>
				<!--{if empty($_SCONFIG['noseccode'])}-->
				<p class="seccodeline"><label for="seccode">验证:</label><input type="text" id="seccode" name="seccode" value="" size="20" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" /></p>
				<!--{/if}-->
				<p><button type="submit" id="submitcomm" name="submitcomm" value="submit" style="margin-left: 2.8em; line-height: 35px; height: 35px; padding: 0 30px; color: #090;">发表评论</button></p>
				<input type="hidden" id="itemid" name="itemid" value="$item[itemid]" />
			</form>
		</div>
	</div>
</div>
<!--{if !empty($ads3['pagefootad'])}-->
<div class="adbox">$ads3[pagefootad]</div>
<!--{/if}-->

<script language="javascript" type="text/javascript">
<!--
	addMediaAction('articlebody');
	addImgLink("articlebody");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<!--{if !empty($ads3['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads3[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads3[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads3['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads3[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->
{template site_footer}