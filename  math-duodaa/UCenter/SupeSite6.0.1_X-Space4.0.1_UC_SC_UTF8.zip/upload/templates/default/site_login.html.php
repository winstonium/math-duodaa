<?exit?>
{template site_header}
<div id="navigation" class="simplepage">
	<p>您的位置：
		<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		&gt;&gt; $title
	</p>
	<h1>登录站点</h1>
</div>
<div id="panel">
	<div class="loginarea">
		<form id="loginform" action="{S_URL}/batch.login.php?action=login" method="post">
			<fieldset>
				<legend>登录</legend>
				<p>用户名 <input type="text" name="username" id="username" /></p>
				<p>密　码 <input type="password" name="password" id="password" /></p>
				<p>有效期 <select name="cookietime">
				<option value="0" >浏览器进程</option>
				<option value="315360000" >永久</option>
				<option value="2592000" >一个月</option>
				<option value="86400" >一天</option>
				<option value="3600" >一小时</option>
				</select></p>
				<p>　　　 <button type="submit" id="loginsubmit" name="loginsubmit" value="true">登录</button></p>
				<input type="hidden" name="refer" value="$refer" />
			</fieldset>
		</form>
	</div>
	<div class="tips">
		<ul>
			<li>游客可以<a href="{B_URL}/register.php?referer={S_URL}/?action/login">点击此处</a>注册成为本站会员！</li>
			<li>如果您忘记了帐号密码，您可以<a href="{B_URL}/member.php?action=lostpasswd" target="_blank">申请找回密码</a>。</li>
			<li>如果您已经拥有了自己的论坛帐号，您可以使用论坛会员名登录站内系统后，<a href="#action/register#">免费升级</a>属于您的个人空间。</li>
		</ul>
	</div>
</div>

{template site_footer}