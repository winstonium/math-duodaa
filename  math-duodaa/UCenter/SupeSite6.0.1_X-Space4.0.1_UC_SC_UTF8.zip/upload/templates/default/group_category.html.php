<?exit?>
{template group_header}

<!--{if !empty($ads2['pagecenterad'])}-->
<div class="banner">
	$ads2[pagecenterad]
</div>
<!--{/if}-->
	
<!-- Content内容 -->
<div class="contentR" style="margin-bottom: 10px;">
	<div class="sideR">
		
		<div class="block topblock">
			<h3>$thecat[name]</h3>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			<!--{block name="category" parameter="upid/$thecat[catid]/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		
		<!--月度关注热点-->
		<!--{block name="group" parameter="lastpost/2592000/order/g.usernum DESC/limit/0,15/cachetime/97200/cachename/hotnews/tpl/data"}--><!--月度热点圈子-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>本月热门</h3>
			<dl>
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<dt><a href="$value[url]">$value[groupname]</a></dt>
				<dd>圈主：<a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / <a href="$value[url]">成员：$value[usernum]</a></dd>
				<!--{/loop}-->
			</dl>
		</div>
		<!--{/if}-->
		
	</div>
	<div class="mainarea">
		<!--根分类圈子列表-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="group" parameter="perpage/20/showdetail/1/catid/$thecat[subcatid]/order/g.lastpost DESC/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
	
		<div class="block topblock">
			<h3>圈子列表</h3>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<em class="smalltxt users">成员：<strong>$value[usernum]</strong></em>
					<em class="smalltxt"><a href="javascript:joingroup('$value[gid]');" class="joingroup">加入本圈</a> | </em>
					<h4><a href="$value[url]">$value[groupname]</a></h4>
					<p class="msgintro">$value[intro]</p>
					<p class="msginfo smalltxt">圈主：<a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a>, 最近更新：#date("Y-m-d", $value["lastpost"])#</p>
				</li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[newlist_multipage]}-->
				$_SBLOCK[newlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
		</div>
		
		<!--{/if}-->
		<!--{/if}-->
		

		<!--论坛资源列表-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/20/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->
		<div class="block">
			<h3>论坛资源</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<div class="pages">
				<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
				$_SBLOCK[bbsthreadlist_multipage]
				<!--{else}-->
				<div class="xspace-page"><span>当前只有一页</span></div>
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->


		<!--子分类最新列表-->
		<!--{if $_SGET['page']<2}-->
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="group" parameter="catid/$cat[subcatid]/order/g.lastpost DESC/limit/0,5/cachetime/$ctime/showdetail/1/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->
		<div class="block">
			<a href="#action/category/catid/$cat[catid]#" class="more">更多</a>
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['sublist'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<em class="smalltxt users">成员：<strong>$value[usernum]</strong></em>
					<em class="smalltxt"><a href="javascript:joingroup('$value[gid]');" class="joingroup">加入本圈</a> | </em>
					<h4><a href="$value[url]">$value[groupname]</a></h4>
					<p class="msgintro">$value[intro]</p>
					<p class="msginfo smalltxt">圈主：<a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a>, 最近更新：#date("Y-m-d", $value["lastpost"])#</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<!--{if !empty($ads2['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads2['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads2[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template group_footer}