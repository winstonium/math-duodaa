<?exit?>
{template news_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="content" style="margin-bottom: 0;">

	<div class="sideR">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
	
		<!--一周评论热点-->
		<!--{block name="spacenews" parameter="dateline/604800/order/i.replynum DESC/limit/0,13/subjectlen/28/cachetime/68000/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>一周评论热点</h3>
			<ul class="msgtitlelist" style="height: 287px; overflow: hidden;">
			<!--{if !empty($_SBLOCK['replyhot'])}-->
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<li><a href="$value[url]" title="$value[subjectall]">$value[subject]</a></li>
				<!--{/loop}-->
			<!--{/if}-->
			</ul>
		</div>
	</div>
	
	<div class="sideL">

		<!--图文资讯幻灯片-->
		<!--{block name="spacenews" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/cachetime/11930/cachename/picnews/tpl/data"}-->
		<div id="slideimg" class="block cleanblock topblock" style="height: 205px; overflow: hidden;">
		<!--{if !empty($_SBLOCK['picnews'])}-->
			<script type="text/javascript" language="javascript">
			<!--			
			var xsTextBar = 1; //是否显示文字链接，1为显示，0为不显示
			var xsPlayBtn = 0; //是否显示播放按钮，1显示，0为不显示
			var xsImgSize = new Array(200,167); //幻灯图片的尺寸，格式为“宽度,高度”
		
			var xsImgs = new Array();
			var xsImgLinks = new Array();
			var xsImgTexts = new Array();
			
			<!--{eval $i=0;}-->
			<!--{loop $_SBLOCK['picnews'] $key $value}-->
			xsImgs[$i] = "$value[a_thumbpath]";
			xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
			xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
			<!--{eval $i++;}-->
			<!--{/loop}-->
			//-->
			</script>
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		<!--资讯图片幻灯片 结束-->
		
		<!--一周好评榜-->
		<!--{block name="spacenews" parameter="dateline/604800/order/i.goodrate DESC/limit/0,7/subjectlen/30/subjectdot/1/cachetime/18000/cachename/goodrateweek/tpl/data"}-->
		<div id="commendread" class="block ">
			<h3>一周好评榜</h3>
			<ul class="msgtitlelist" style="height: 181px; overflow: hidden;">
			<!--{if !empty($_SBLOCK['goodrateweek'])}-->
				<!--{loop $_SBLOCK['goodrateweek'] $value}-->
				<li><a href="$value[url]" title="$value[subjectall]">$value[subject]</a></li>
				<!--{/loop}-->
			<!--{/if}-->
			</ul>
		</div>
	</div>

	<div class="mainarea">
		<!--一周点击排行头条-->
		<!--{block name="spacenews" parameter="dateline/604800/showattach/1/showdetail/1/order/i.viewnum DESC/limit/0,1/subjectlen/34/subjectdot/1/messagelen/80/messagedot/1/cachetime/18600/cachename/headnews/tpl/data"}-->
		<div id="headline" class="block cleanblock topblock">
			<!--{if !empty($_SBLOCK['headnews'])}-->
			<!--{loop $_SBLOCK['headnews'] $value}-->
			<!--{if !empty($value['a_thumbpath'])}--><a href="$value[url]"><img src="$value[a_thumbpath]" alt="" /></a><!--{/if}-->
			<strong><a href="$value[url]">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<!--站内最新资讯列表-->
		<!--{block name="spacenews" parameter="order/i.dateline DESC/limit/0,15/subjectlen/38/cachetime/13800/cachename/newnews/tpl/data"}-->
		<div id="focus">
			<ul class="msgtitlelist linelist">
				<!--{loop $_SBLOCK['newnews'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!--图片资讯显示-->
<!--{block name="spacenews" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/subjectlen/12/subjectdot/1/limit/0,6/cachetime/8000/cachename/picnews/tpl/data"}-->
<div class="block">
	<ul id="scroller" class="imgthumblist">
		<!--{loop $_SBLOCK['picnews'] $value}-->
		<li class="list1line">
			<div><a href="$value[url]" target="_blank"><img src="$value[a_thumbpath]" alt="$value[subjectall]" /></a></div>
			<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
		</li>
		<!--{/loop}-->
	</ul>
</div>

<div class="contentR" style="margin-bottom: 0;">
	<!-- 右侧版块 -->
	<div class="sideR">
	
		<!--最热资讯TAG列表-->
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,18/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block">
			<h3>热门TAG</h3>
			<div style="height: 201px;">
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
		
	</div>
	<div class="mainarea">

		<div id="hotarticle" class="block" style="height: 240px; overflow: hidden;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotarticle','week');" class="tab curtab">周点击榜</a>
				<a id="monthtab" href="javascript:setTab('hotarticle','month');" class="tab">月点击榜</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all');" class="tab">总点击榜</a>
			</h3>
			<!--站内热门资讯列表(一周)-->
			<!--{block name="spacenews" parameter="dateline/604800/order/i.viewnum DESC/limit/0,18/cachetime/85400/subjectlen/40/subjectdot/1/cachename/hotnews1/tpl/data"}-->
			<div  id="week" class="tabcontent">
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['hotnews1'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门资讯列表(一月)-->
			<!--{block name="spacenews" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,18/cachetime/97200/subjectlen/40/subjectdot/1/cachename/hotnews2/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['hotnews2'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门资讯列表(全部)-->
			<!--{block name="spacenews" parameter="order/i.viewnum DESC/limit/0,18/cachetime/99400/subjectlen/40/subjectdot/1/cachename/hotnews3/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="list2col" style="height: 190px;">
					<!--{loop $_SBLOCK['hotnews3'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[viewnum])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="contentR">
	<!-- 右侧版块 -->
	<div class="sideR">

		<!--最新评论资讯显示-->
		<!--{block name="spacenews" parameter="order/i.lastpost DESC/limit/0,10/cachetime/7500/cachename/newnews/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>评论更新</h3>
			<dl>
				<!--{loop $_SBLOCK['newnews'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a></dt>
				<!--{/loop}-->
			</dl>
		</div>
		
		<!--月度评论热点-->
		<!--{block name="spacenews" parameter="lastpost/2592000/order/i.replynum DESC/limit/0,10/cachetime/75400/subjectlen/40/subjectdot/1/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>月度评论热点</h3>
			<dl>
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<dt><a href="$value[url]">$value[subject]</a></dt>
				<!--{/loop}-->
			</dl>
		</div>

	</div>
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--各分类最新资讯列表-->
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spacenews" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/40/cachename/newslist/tpl/data"}-->
		<div class="blockcategory">
			<h3>
				<strong><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></strong>
				<a href="#action/category/catid/$cat[catid]#" class="more">更多</a>
			</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newslist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/loop}-->
		</div>
	</div>
</div>
<!-- /Content -->
<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template news_footer}