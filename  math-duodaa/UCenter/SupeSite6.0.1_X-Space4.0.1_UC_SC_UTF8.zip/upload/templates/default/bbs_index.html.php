<?exit?>
{template bbs_header}

<!--{if !empty($ads['pagecenterad'])}-->
<div class="banner">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<!-- Content内容 -->
<div class="content" style="background: none;">
	<!-- 右侧 -->
	<div class="sideR">
		<!-- 用户面板 -->
		<div id="userpanel" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<div id="bbsintro" class="block">
			<h3>快速链接</h3>
			<ul class="msgtitlelist" style="height: 3.8em;">
			<li><a href="{B_URL}/">访问论坛</a> <span class="smalltxt">参与交流互动</span></li>
			<li><a href="{B_URL}/register.php">注册会员</a> <span class="smalltxt">拥有个人空间</span></li>
			</ul>
		</div>

		<!-- 论坛公告 -->
		<!--{block name="bbsannouncement" parameter="order/displayorder/limit/0,10/cachetime/96400/cachename/announcelist/tpl/data"}-->
		<div id="announcements" class="block">
			<h3>论坛公告</h3>
			<ul class="msgtitlelist" style="height: 17em;">
				<!--{loop $_SBLOCK['announcelist'] $ikey $value}-->
				<li><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>


	</div>
	<!-- /右侧 -->
	<!-- 左侧 -->
	<div class="sideL">

		<!--图片附件-->
		<!--{block name="bbsattachment" parameter="filetype/image/t_lastpost/2592000/order/t.replies DESC/limit/0,10/cachetime/49900/cachename/picthread/tpl/data"}-->
		<div id="slideimg" class="block cleanblock topblock" style="height: 232px; overflow: hidden;">
		<!--{if !empty($_SBLOCK['picthread'])}-->	
		<script type="text/javascript" language="javascript">
		<!--
		var xsTextBar = 1; //是否显示文字链接，1为显示，0为不显示
		var xsPlayBtn = 0; //是否显示播放按钮，1显示，0为不显示
		var xsImgSize = new Array(194,194); //幻灯图片的尺寸，格式为“宽度,高度”
		
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picthread'] $key $value}-->
		xsImgs[$i] = "$value[attachment]";
		xsImgLinks[$i] = "$value[url]";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		<!--图片附件 结束-->
		
		<!--最近1个月的热点回复帖子-->
		<!--{block name="bbsthread" parameter="dateline/2592000/order/replies DESC/limit/0,7/cachetime/82400/subjectlen/26/cachename/hotthread/tpl/data"}-->
		<div id="commendread" class="block boldblock">
			<h3>月度评论热点</h3>
			<ul class="msgtitlelist" style="height: 13em;">
			<!--{loop $_SBLOCK['hotthread'] $value}-->
			<li><a href="$value[url]" title="$value[subjectall]">$value[subject]</a> <span class="smalltxt">($value[replies])</span></li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!-- /左侧 -->
	<div class="mainarea">

		<!--酷主题(2天内评论数最多的帖子)-->
		<!--{block name="bbsthread" parameter="showdetail/1/messagelen/100/subjectlen/40/dateline/172800/order/replies DESC/limit/0,1/cachetime/52400/cachename/coolthread/tpl/data"}-->
		<div id="headline" class="block cleanblock topblock">
			<!--{if !empty($_SBLOCK['coolthread'])}-->
			<!--{loop $_SBLOCK['coolthread'] $value}-->
			<strong><a href="$value[url]">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<!--一周热点讨论排行-->
		<!--{block name="bbsthread" parameter="dateline/604800/subjectlen/33/order/replies DESC/limit/0,16/cachetime/71400/cachename/replyhot/tpl/data"}-->
		<div id="focus">
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<li><cite><a href="#uid/$value[authorid]#">$value[author]</a></cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[replies])</span></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!--{block name="bbsattachment" parameter="dateline/604800/filetype/image/order/t.views DESC/limit/0,6/subjectlen/12/cachetime/38200/cachename/imagethread/tpl/data"}-->
<!--{if !empty($_SBLOCK['imagethread'])}-->
<div class="block">
	<ul class="imgthumblist">
	<!--{loop $_SBLOCK['imagethread'] $value}-->
		<li class="list1line"><div><a href="$value[url]" title="$value[subject]"><img src="$value[attachment]" alt="$value[subject]" /></a></div><p><a href="$value[url]">$value[subject]</a></p></li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<div class="content">
	<!-- 右侧版块 -->
	<div class="sideR">

		<!--板块根据帖子数排行-->
		<!--{block name="bbsforum" parameter="type/forum/allowblog/1/order/posts DESC/limit/0,10/cachetime/14400/cachename/hotforums/tpl/data"}-->
		<div id="hottforum" class="block stat" style="height: 257px; overflow: hidden;">
			<h3>论坛帖子数排行</h3>
			<ol>
				<!--{loop $_SBLOCK['hotforums'] $value}-->
				<li><em>$value[posts]</em><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ol>
		</div>
	</div>

	<div class="sideL">
		<!--会员排行-->
		<div id="hotmembers" class="block stat" style="height: 257px; overflow: hidden;">
			<h3 id="hotmemberstabs" class="tabs">
				<a id="poststab" href="javascript:setTab('hotmembers','posts')" class="tab curtab">发帖排行</a>
				<a id="onlinetab" href="javascript:setTab('hotmembers','online')" class="tab">在线排行</a>
			</h3>
			<!--{block name="bbsmember" parameter="order/m.posts DESC/limit/0,10/cachetime/86400/cachename/hotmembers/tpl/data"}-->
			<div id="posts" class="tabcontent">
				<ol>
					<!--{loop $_SBLOCK['hotmembers'] $value}-->
					<li><cite style="text-align: right; margin-right: 5px;">$value[posts]</cite><a href="$value[url]">$value[username]</a></li>
					<!--{/loop}-->
				</ol>
			</div>
			<!--{block name="bbsmember" parameter="order/m.oltime DESC/limit/0,10/cachetime/86400/cachename/toponline/tpl/data"}-->
			<div id="online" class="tabcontent" style="display: none;">
				<ol>
					<!--{loop $_SBLOCK['toponline'] $value}-->
					<li><cite style="width: 80px; text-align: right;">$value[oltime]小时</cite><a href="$value[url]">$value[username]</a></li>
					<!--{/loop}-->
				</ol>
			</div>
		</div>
	</div>

	<div class="mainarea">
		<div id="hotarticle" class="block">
			<h3 id="hotarticletabs" class="tabs">
				<a id="daytab" href="javascript:setTab('hotarticle','day')" class="tab curtab">本周热点</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week')" class="tab">本月热点</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all')" class="tab">热帖排行</a>
			</h3>
			<!--热门帖子列表(一周)-->
			<!--{block name="bbsthread" parameter="dateline/604800/order/views DESC/limit/0,10/cachetime/72400/subjectlen/40/subjectdot/1/cachename/hotthreadweek/tpl/data"}-->
			<div id="day" class="tabcontent" style="height: 230px; overflow: hidden;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthreadweek'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt" title="共有$value[replies]条回复">($value[replies])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门帖子列表(一月)-->
			<!--{block name="bbsthread" parameter="dateline/2592000/order/views DESC/limit/0,10/cachetime/82400/subjectlen/40/subjectdot/1/cachename/hotthreadmonth/tpl/data"}-->
			<div id="week" class="tabcontent" style="display: none; height: 230px; overflow: hidden;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthreadmonth'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt" title="共有$value[replies]条回复">($value[replies])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门帖子列表(全部)-->
			<!--{block name="bbsthread" parameter="order/views DESC/limit/0,10/cachetime/92400/subjectlen/40/subjectdot/1/cachename/hotthread/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none; height: 230px; overflow: hidden;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthread'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a> <span class="smalltxt" title="共有$value[replies]条回复">($value[replies])</span></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="content">
	<!-- 右侧版块 -->
	<div class="sideR">

		<!--最新更新帖子-->
		<!--{block name="bbsthread" parameter="order/lastpost DESC/limit/0,14/subjectlen/26/cachetime/11400/cachename/newpost/tpl/data"}-->
		<div id="newpost" class="block" style="height: 345px; overflow: hidden;">
			<h3>最新评论</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newpost'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[replies])</span></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<div class="sideL">
		<!--{block name="userspace" parameter="order/u.dateline DESC/limit/0,4/showdetail/1/cachetime/1900/cachename/newspace/tpl/data"}-->
		<div class="block" style="height: 345px; overflow: hidden;">
			<h3>会员最新个人空间</h3>
			<ul class="imgtitlelist">
				<!--{loop $_SBLOCK['newspace'] $value}-->
				<li>
					<a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a>
					<p><a href="$value[url]" target="_blank">$value[spacename]</a></p>
					<p class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a><!--{if !empty( $value[province])}--> ($value[province])<!--{/if}--></p>
					<p class="smalltxt">#date("Y-m-d", $value["dateline"])#</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<div class="mainarea">
		<!--{block name="bbsthread" parameter="order/dateline DESC/limit/0,14/cachetime/21400/cachename/ratehot/tpl/data"}-->
		<div class="block" style="height: 345px; overflow: hidden;">
			<h3>最新帖子</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['ratehot'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<div class="blocktitle">
	<a href="{B_URL}/" class="more">进入论坛</a>
	<h2>论坛版块</h2>
</div>
<div class="blockcategorylist block3col">
	<!--各板块最新列表-->
	<!--{loop $_SBLOCK['forumarr'] $ckey $cat}-->
	<!--{eval $ctime=3800+30*$ckey;}-->
	<!--{block name="bbsthread" parameter="fid/$cat[fid]/order/dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/40/subjectdot/1/cachename/threadlist/tpl/data"}-->
	<div class="blockcategory" style="width: 256px;">
		<h3>
			<a href="#action/forumdisplay/fid/$cat[fid]#" class="more">更多</a>
			<strong><a href="#action/forumdisplay/fid/$cat[fid]#">$cat[name]</a></strong>
		</h3>
		<ul class="msgtitlelist">
			<!--{loop $_SBLOCK['threadlist'] $value}-->
			<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
			<!--{/loop}-->
		</ul>
		<!--p class="catecommend"><a href="javascript:;">热点</a></p-->
	</div>
	<!--{/loop}-->
</div>
<br />
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template bbs_footer}