<?exit?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=$_SCONFIG[charset]" />
<title>$title  $_SCONFIG[seotitle]- Powered by SupeSite</title>
<meta name="keywords" content="$keywords $_SCONFIG[seokeywords]" />
<meta name="description" content="$description $_SCONFIG[seodescription]" />
<link rel="stylesheet" type="text/css" href="{S_URL}/templates/$_SCONFIG[template]/css/style.css" />
$_SCONFIG[seohead]
<script type="text/javascript">
var siteUrl = "{S_URL}";
</script>
<script src="{S_URL}/include/js/ajax.js" type="text/javascript" language="javascript"></script>
<script src="{S_URL}/include/js/common.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<div id="wrap">
	<!-- Header页首 -->
	<div id="header">
	
		<!--系统菜单 begin-->
		<table border="0" cellpadding="0" cellspacing="0" id="headertab">
			<tr>
				<td id="logo">
					<a href="{S_URL}/"><img src="{S_URL}/templates/$_SCONFIG[template]/images/logo.gif" alt="$_SCONFIG[sitename]" style="border: none;" /></a>
				</td>
				<td id="topmenu">
					<ul>
						<li><a href="{S_URL}/">首页</a></li>
						<!--{loop $channels['menus'] $value}-->
						<li><a href="$value[url]">$value[name]</a></li>
						<!--{/loop}-->
						<li><a href="{S_URL}/batch.search.php">搜索</a></li>
					</ul>
				</td>
			</tr>
		</table>

		<!--{if empty($thecat['catid'])}-->
		<!--{eval $ads = getad('system', 'image', '1');}-->
		<!--{if !empty($ads['pageheadad'])}-->
		<div class="banner">$ads[pageheadad]</div>
		<!--{/if}-->
		<!--{else}-->
		<!--{eval $ads2 = getad('system', 'image', '2');}-->
		<!--{if !empty($ads2['pageheadad'])}-->
		<div class="banner">$ads2[pageheadad]</div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--根分类导航菜单-->
		<!--{block name="category" parameter="type/image/isroot/1/order/c.displayorder/limit/0,100/cachetime/93600/cachename/category/tpl/data"}-->
		<div id="menu">
			<ul>
				<!--{loop $_SBLOCK['category'] $value}-->
				<li><a href="$value[url]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<div id="navigation">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<button type="submit" value="true" name="subjectsearch">搜索</button>
			</form>
			<p>您的位置：
				<a href="{S_URL}/">$_SCONFIG[sitename]</a>
				<!--{loop $guidearr $value}-->
				&gt;&gt; <a href="$value[url]">$value[name]</a>
				<!--{/loop}-->
			</p>
		</div>
	</div>
	<!-- /Header页首 -->