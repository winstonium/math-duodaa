<?exit?>
{template spaces_header}
<!--{eval $ads = getad('system', 'spaces', '1');}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
	
		<!--空间之星-->
		<!--{if $page<2}-->
		<!--{block name="userspace" parameter="isstar/1/showdetail/1/limit/0,100/order/u.lastpost DESC/cachetime/17400/cachename/spacestar/tpl/data"}-->
		<div class="block">
			<h3>空间之星</h3>
			<ul class="imagelist">
				<!--{loop $_SBLOCK['spacestar'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank" title="$value[spacename]"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
					<p><a href="$value[url]" target="_blank">$value[spacename]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--最近更新-->
		<!--{block name="userspace" parameter="perpage/20/showdetail/1/order/u.lastpost DESC/cachetime/17400/cachename/lastpostspace/tpl/data"}-->
		<div class="block">
			<h2>空间更新列表</h2>
			<ul class="thumbmsglist">
				<!--{loop $_SBLOCK['lastpostspace'] $value}-->
				<li>
					<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></p>
					<div>
						<em class="smalltxt">信息数: $value[spaceallnum]</em>
						<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
						<!--{if $value['announcement']}--><p>$value[announcement]</p><!--{/if}-->
						<p class="msginfo">
							<a href="$value[url]" target="_blank" class="author">$value[username]</a>
							<!--{if $value['province']}--> $value[province]<!--{/if}-->
							<!--{if $value['city']}-->/ $value[city]<!--{/if}--> &nbsp;
							创建于: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, 最后更新: #date("Y-m-d", $value["lastpost"])#<!--{/if}-->
						</p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{if $_SBLOCK[lastpostspace_multipage]}-->
			<div class="pages">
				$_SBLOCK[lastpostspace_multipage]
			</div>
			<!--{/if}-->
		</div>
	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!-- 同城空间 -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" name="usersearch">同城空间</button>
			</form>
		</div>
		<!--一周更新排行榜-->
		<!--{block name="userspace" parameter="lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>一周更新排行榜</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

{template site_footer}