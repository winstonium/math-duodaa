<?exit?>
{template site_header}
<div id="menu"><h2>TAG</h2></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div id="taginfolist" class="tabblock">
			<a href="#action/tag/tagid/$tag[tagid]/show/all#" class="more">查看全部信息</a>
			<h3 id="taginfolisttabs" class="tabs">
				<!--{if $tag[spacenewsnum]}--><a id="newstab" href="javascript:setTab('taginfolist','news');" class="tab $tabarr[news][0]">资讯<span class="smalltxt">($tag[spacenewsnum])</span></a><!--{/if}-->
				<!--{if $tag[spaceblognum]}--><a id="blogtab" href="javascript:setTab('taginfolist','blog');" class="tab  $tabarr[blog][0]">日志<span class="smalltxt">($tag[spaceblognum])</span></a><!--{/if}-->
				<!--{if $tag[spaceimagenum]}--><a id="imagetab" href="javascript:setTab('taginfolist','image');" class="tab $tabarr[image][0]">图片<span class="smalltxt">($tag[spaceimagenum])</span></a><!--{/if}-->
				<!--{if $tag[spacegoodsnum]}--><a id="goodstab" href="javascript:setTab('taginfolist','goods');" class="tab $tabarr[goods][0]">商品<span class="smalltxt">($tag[spacegoodsnum])</span></a><!--{/if}-->
				<!--{if $tag[spacefilenum]}--><a id="filetab" href="javascript:setTab('taginfolist','file');" class="tab $tabarr[file][0]">文件<span class="smalltxt">($tag[spacefilenum])</span></a><!--{/if}-->
				<!--{if $tag[spacelinknum]}--><a id="linktab" href="javascript:setTab('taginfolist','link');" class="tab $tabarr[link][0]">书签<span class="smalltxt">($tag[spacelinknum])</span></a><!--{/if}-->
				<!--{if $tag[spacevideonum]}--><a id="videotab" href="javascript:setTab('taginfolist','video');" class="tab $tabarr[video][0]">影音<span class="smalltxt">($tag[spacevideonum])</span></a><!--{/if}-->
			</h3>
			
			<!--TAG中资讯列表-->
			<div id="news" class="tabcontent"  $tabarr[news][1]>
				<!--{if $tag[spacenewsnum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/news/order/st.dateline DESC/limit/0,10/cachetime/86400/cachename/news/tpl/data"}-->
				<ul class="msgtitlelist linelist articlelist">
					<!--{loop $_SBLOCK['news'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无资讯</p>
				<!--{/if}-->
			</div>
			
			<!--TAG中日志列表-->
			<div id="blog" class="tabcontent" $tabarr[blog][1]>
				<!--{if $tag[spaceblognum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/blog/order/st.dateline DESC/showdetail/1/messagelen/200/messagedot/1/limit/0,10/cachetime/11830/cachename/blog/tpl/data"}-->
				<ul class="messagelist">
					<!--{loop $_SBLOCK['blog'] $value}-->
					<li>
						<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
						<p class="msginfo"><a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> 发表于 #date("Y-m-d H:i:s", $value["dateline"])#</p>
						<p>$value[message]</p>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无日志</p>
				<!--{/if}-->
			</div>
			
			<!--TAG中图片列表-->
			<div id="image" class="tabcontent"  $tabarr[image][1]>
				<!--{if $tag[spaceimagenum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/image/order/st.dateline DESC/showdetail/1/limit/0,12/cachetime/11900/cachename/image/tpl/data"}-->
				<ul class="imagelist">
					<!--{loop $_SBLOCK['image'] $value}-->
					<li>
						<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
						<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无图片</p>
				<!--{/if}-->
			</div>
			
			<!--TAG中商品列表-->
			<div id="goods" class="tabcontent"  $tabarr[goods][1]>
				<!--{if $tag[spacegoodsnum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/goods/order/st.dateline DESC/limit/0,8/cachetime/12000/showdetail/1/messagelen/150/messagedot/1/cachename/goods/tpl/data"}-->
				<ul class="thumbmsglist">
					<!--{loop $_SBLOCK['goods'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[a_subject]" /></a></p>
						<div>
							<em>价格: <strong>$value[price]元</strong></em>
							<h4><a href="$value[url]" target="_blank">$value[subject]</a></h4>
							<p class="msgintro">$value[message]...</p>
							<p class="msginfo smalltxt">卖家: <a href="#uid/$value[uid]#" target="_blank">$value[username]</a></p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无商品</p>
				<!--{/if}-->
			</div>
			
			<!--TAG中软件列表-->
			<div id="file" class="tabcontent"  $tabarr[file][1]>
				<!--{if $tag[spacefilenum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/file/order/st.dateline DESC/limit/0,5/cachetime/11930/cachename/file/tpl/data"}-->
				<ul class="msgtitlelist linelist articlelist">
					<!--{loop $_SBLOCK['file'] $value}-->
					<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无软件</p>
				<!--{/if}-->
			</div>
	
			<!--TAG中书签列表-->
			<div id="link" class="tabcontent"  $tabarr[link][1]>
				<!--{if $tag[spacelinknum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/link/order/st.dateline DESC/limit/0,10/subjectlen/36/cachetime/12030/cachename/link/tpl/data"}-->
				<ul class="msgtitlelist linelist articlelist">
				<!--{loop $_SBLOCK['link'] $value}-->
				<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
				<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无书签</p>
				<!--{/if}-->
			</div>
			
			<!--TAG中影音列表-->
			<div id="video" class="tabcontent"  $tabarr[video][1]>
				<!--{if $tag[spacevideonum]}-->
				<!--{block name="spacetag" parameter="tagid/$tag[tagid]/type/video/order/st.dateline DESC/showdetail/1/limit/0,12/cachetime/11900/cachename/video/tpl/data"}-->
				<ul class="msgtitlelist linelist articlelist">
					<!--{loop $_SBLOCK['video'] $value}-->
					<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
				<p style="line-height: 100px; text-align: center;">该TAG下暂无影音</p>
				<!--{/if}-->
			</div>
			
		</div>
	</div>
	
	<div class="side">
		<div class="block blockG">
			<h3>TAG信息</h3>
			<h1 id="tagname"><a href="#action/tag/tagid/$tag[tagid]/show/all#">$tag[tagname]</a></h1>
			<ul class="msgtitlelist">
				<li>创建者: <a href="$tag[spaceurl]" target="_blank" class="author">$tag[username]</a></li>
				<li>创建时间: #date("Y-m-d H:i:s",$tag["dateline"])#</li>
				<li>总信息数: $tag[spaceallnum]</li>
				<li><a href="#action/tag/tagid/$tag[tagid]/show/all#">查看Tag为 "$tag[tagname]" 的全部信息</a></li>
			</ul>
		</div>
		<div class="block">
			<h3>相关TAG</h3>
			<ul class="msgtitlelist">
				<!--{if $tag[relativetags]}-->
				<!--{loop $tag[relativetags] $key $value}-->
				<li><a href="#action/tag/tagname/$key#">$value</a></li>
				<!--{/loop}-->
				<!--{else}-->
				<li>暂无相关TAG</li>
				<!--{/if}-->
			</ul>
		</div>
	</div>
</div>

{template site_footer}