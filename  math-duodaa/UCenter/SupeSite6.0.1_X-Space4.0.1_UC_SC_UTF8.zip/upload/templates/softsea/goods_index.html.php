<?exit?>
{template goods_header}
<!--{eval $ads = getad('system', 'goods', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->

<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		<!-- 一周热点点击商品 -->
		<div class="block" style="padding: 0;">
			<h2>一周热点商品</h2>
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.viewnum DESC/limit/0,15/cachetime/45400/subjectlen/10/subjectdot/1/showdetail/1/cachename/spacialgoods/tpl/data"}-->
			<ul class="imagelist" style="height: 420px;">
				<!--{loop $_SBLOCK['spacialgoods'] $value}-->
				<li>
					<div><a href="$value[url]" title="{$value[subjectall]} {$value[province]} {$value[city]}" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></div>
					<p><a href="$value[url]" title="{$value[subjectall]} {$value[province]} {$value[city]}" target="_blank">$value[subject]</a> <span class="smalltxt">($value[price]元)</span></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!-- 同城商品 -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" id="goodscitysearch" name="goodscitysearch">同城商品</button>
			</form>
		</div>
		
		<!--最新上架商品-->
		<!--{block name="spacegoods" parameter="order/i.dateline DESC/limit/0,11/subjectlen/30/subjectdot/1/showdetail/1/cachetime/11900/cachename/weekcommendgoods/tpl/data"}-->
		<div class="block" style="height: 282px; overflow: hidden;">
			<h3>最新上架商品</h3>
			<ul>
				<!--{loop $_SBLOCK['weekcommendgoods'] $value}-->
				<li>
					<a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[province]}{$value[city]}">$value[subject]</a>
					<span class="smalltxt">$value[price]元</span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	
</div>

<!--{if !empty($ads[pagecenterad])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<!--热点商品列表-->
		<div id="hotgoods" class="tabblock" style="height: 520px; overflow: hidden;">
			<h3 id="hotgoodstabs" class="tabs">
				<a id="weektab" href="javascript:setTab('hotgoods','week')" class="tab curtab">本周热点</a>
				<a id="monthtab" href="javascript:setTab('hotgoods','month')" class="tab">本月热点</a>
				<a id="alltab" href="javascript:setTab('hotgoods','all')" class="tab">热点排行</a>
			</h3>
			<!--评论最多的商品(一周)-->
			<!--{block name="spacegoods" parameter="dateline/604800/order/i.replynum DESC/limit/0,10/cachetime/64400/subjectlen/20/subjectdot/1/showdetail/1/messagelen/34/messagedot/1/cachename/hotgoodsweek/tpl/data"}-->
			<div id="week" class="tabcontent">
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['hotgoodsweek'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[province]}{$value[city]}">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								价格: <strong class="price"><a href="$value[url]" target="_blank">$value[price]元</a></strong>
								卖家: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> ($value[province])<!--{/if}-->
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--评论最多的商品(一月)-->
			<!--{block name="spacegoods" parameter="dateline/2592000/order/i.replynum DESC/limit/0,10/cachetime/78400/subjectlen/20/subjectdot/1/showdetail/1/messagelen/34/messagedot/1/cachename/hotgoodsmonth/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['hotgoodsmonth'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[province]}{$value[city]}">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								价格: <strong class="price"><a href="$value[url]" target="_blank">$value[price]元</a></strong>
								卖家: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> ($value[province])<!--{/if}-->
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--评论最多的商品(全部)-->
			<!--{block name="spacegoods" parameter="order/i.replynum DESC/limit/0,10/cachetime/89400/subjectlen/20/subjectdot/1/showdetail/1/messagelen/34/messagedot/1/cachename/hotgoods/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['hotgoods'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[thumb]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[province]}{$value[city]}">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								价格: <strong class="price"><a href="$value[url]" target="_blank">$value[price]元</a></strong>
								卖家: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a><!--{if $value['province']}--> ($value[province])<!--{/if}-->
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<div class="side">
		
		<div class="block" style="height: 522px; overflow: hidden;">
			<h3>最新评论商品</h3>
			<!--{block name="spacegoods" parameter="order/i.lastpost DESC/limit/0,11/subjectlen/30/subjectdot/1/showdetail/1/cachetime/12900/cachename/newgoods/tpl/data"}-->
			<ul>
				<!--{loop $_SBLOCK['newgoods'] $value}-->
				<li>
					<a href="$value[url]" target="_blank" title="{$value[subjectall]} {$value[price]}元 {$value[province]}{$value[city]}">$value[subject]</a>
					<span class="smalltxt">$value[price]元</span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}