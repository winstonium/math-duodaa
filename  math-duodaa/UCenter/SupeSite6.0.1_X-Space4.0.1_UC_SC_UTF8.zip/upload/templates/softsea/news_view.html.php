<?exit?>
{template news_header}
<!--{eval $ads3 = getad('system', 'news', '3');}-->
<!--{if !empty($ads3['pagecenterad'])}-->
<div class="adbanner">
	$ads3['pageheadad']
</div>
			<!--{/if}-->
<!-- Content内容 -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		<div id="articledetail" class="block">
			<p id="articlectrl">
				<span>
				<a href="{S_URL}/batch.common.php?action=viewnews&amp;op=up&amp;itemid=$news[itemid]&amp;catid=$news[catid]" class="viewnewsup">上一篇</a> |
				<a href="{S_URL}/batch.common.php?action=viewnews&amp;op=down&amp;itemid=$news[itemid]&amp;catid=$news[catid]" class="viewnewsdown">下一篇</a>
				</span>
			</p>
			<h1 id="articletitle">$news[subject]</h1>
			<p id="articleinfo">
				发布: #date('Y-n-d H:i', $news["dateline"])# |
				作者: $news[newsauthor] |
				来源: <!--{if !empty($news[newsfromurl])}--><a href="$news[newsfromurl]" target="_blank" title="$news[newsfrom]">$news[newsfrom]</a><!--{else}-->$news[newsfrom]<!--{/if}--> |
				查看: $news[viewnum]次
			</p>
			
			<!--{if !empty($news[custom][name])}-->
			<div id="custominfo">
				<h3><span class="tab curtab">$news[custom][name]</span></h3>
				<ul class="msgtitlelist">
				<!--{loop $news[custom][key] $ckey $cvalue}-->
					<li><strong>$cvalue[name]: </strong>$news[custom][value][$ckey]</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<div id="articlebody">
			$news[message]
			<!--{if !empty($ads3['pagecenterad'])}-->
			<div class="adbox">
				$ads3['pagecenterad']
			</div>
			<!--{/if}-->

			<!--{if empty($multipage)}-->
			<!--{loop $news['attacharr'] $attach}-->
			<!--{if $attach['isimage']}-->
			<p class="attach"><a href="$attach[url]" target="_blank"><img src="$attach[thumbpath]" alt="$attach[subject]" /></a></p>
			<p class="attachtitle">$attach[subject]</p>
			<!--{else}-->
			<p class="attach"><a href="$attach[url]" target="_blank"><img src="{S_URL}/images/base/attachment.gif" border="0" alt="$attach[subject]" ></a></p>
			<p class="attachtitle"><a href="$attach[url]" target="_blank">$attach[filename](<!--{eval echo formatsize($attach[size]);}-->)</a></p>
			<!--{/if}-->
			<!--{/loop}-->
			<!--{/if}-->

			<!--{if !empty($relativetagarr)}-->
			<p id="relativetags"><strong>TAG:</strong> 
			<!--{loop $relativetagarr $value}-->
			<!--{eval $svalue = rawurlencode($value);}-->
			<a href="#action/tag/tagname/$svalue#" target="_blank">$value</a>
			<!--{/loop}-->
			</p>
			<!--{/if}-->
			</div>
			<p id="articlectrl">
				<span>
					字号: <a href="javascript:doZoom('12');">小</a> <a href="javascript:doZoom('14');">中</a> <a href="javascript:doZoom('16');">大</a> |
					<a href="javascript:;" onclick="showajaxdiv('{S_URL}/batch.common.php?action=emailfriend&amp;itemid=$news[itemid]', 400);">推荐给好友</a>
				</span>
			</p>
			<!--{if $multipage}-->
			<div class="pages">
				$multipage
			</div>
			<!--{/if}-->
		</div>
		
		<!--{if !empty($commentlist)}-->
		<div id="commentlist" class="block">
			<h2>最新评论</h2>
			<dl>
				<!--{loop $commentlist $value}-->
				<dt>
					<span>
						<a href="#action/viewcomment/itemid/$value[itemid]/cid/$value[cid]/op/delete/php/1#">删除</a> 
						<!--{if !empty($value['message'])}--><a href="javascript:;" onclick="getQuote($value[cid])">引用</a><!--{/if}-->
					</span>
					<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="#uid/$value[authorid]#" target="_blank" class="author">$value[author]</a><!--{/if}-->
					&nbsp; 评论时间 #date("Y-n-d H:i:s", $value["dateline"])#
				</dt>
				<dd>
					<!--{if !empty($value['message'])}-->
					$value[message]
					<!--{else}-->
					评 <span style="font-size:16px">$value[rates]</span> 分
					<!--{/if}-->
				</dd>
				<!--{/loop}-->
			</dl>
			<p class="more"><a href="#action/viewcomment/itemid/$news[itemid]#">查看全部评论……</a>(共$news[replynum]条)</p>
		</div>
		<!--{/if}-->
		
		<div class="midmain" style="background-color: #F1F5F6;overflow: hidden;">
			<div id="xspace-rates">
				<div id="xspace-rates-bg">
					<div id="xspace-rates-star" class="xspace-rates0">&nbsp;</div>
					<div id="xspace-rates-a">
						<a href="javascript:;" onmouseover="rateHover(-5);" onmouseout="rateOut();" onclick="setRateXML('-5', '$news[itemid]');">-5</a>
						<a href="javascript:;" onmouseover="rateHover(-3);" onmouseout="rateOut();" onclick="setRateXML('-3', '$news[itemid]');">-3</a>
						<a href="javascript:;" onmouseover="rateHover(-1);" onmouseout="rateOut();" onclick="setRateXML('-1', '$news[itemid]');">-1</a>
						<a href="javascript:;" onmouseover="rateHover(0);" onmouseout="rateOut();" onclick="setRateXML('0', '$news[itemid]');">-</a>
						<a href="javascript:;" onmouseover="rateHover(1);" onmouseout="rateOut();" onclick="setRateXML('1', '$news[itemid]');">+1</a>
						<a href="javascript:;" onmouseover="rateHover(3);" onmouseout="rateOut();" onclick="setRateXML('3', '$news[itemid]');">+3</a>
						<a href="javascript:;" onmouseover="rateHover(5);" onmouseout="rateOut();" onclick="setRateXML('5', '$news[itemid]');">+5</a>
					</div>
					<input type="hidden" id="xspace-rates-value" name="rates" value="0" />
				</div>
				<p>评分：<span id="xspace-rates-tip">0</span></p>
			</div>
			<div id="comment">
				<h2>我来说两句</h2>
				<form id="postcomm" action="#action/viewcomment/itemid/$news[itemid]/php/1#" method="post">
					<p><label for="message">内容:</label><textarea id="message" name="message"  onfocus="showcode()"></textarea></p>
					<!--{if empty($_SCONFIG['noseccode'])}-->
					<p id="seccodeline" class="seccodeline"><label for="seccode">验证:</label><input type="text" id="seccode" name="seccode" value="" size="20" /> <img id="xspace-imgseccode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" /></p>
					<!--{/if}-->
					<p><button type="submit" id="submitcomm" name="submitcomm" value="submit">发表评论</button></p>
					<input type="hidden" id="itemid" name="itemid" value="$news[itemid]" />
				</form>
			</div>
		</div>
		<div class="midside">
			<!--相关资讯-->
			<!--{if !empty($news[relativeitemids])}-->
			<!--{block name="spacenews" parameter="itemid/$news[relativeitemids]/order/i.dateline DESC/limit/0,12/subjectlen/26/subjectdot/1/cachetime/17680/cachename/relativeitem/tpl/data"}-->
			<div class="block blockG" style="height: 308px;">
				<h3>相关阅读</h3>
				<ul>
				<!--{loop $_SBLOCK['relativeitem'] $ikey $value}-->
				<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
		</div>
		
	</div>
	
	<div class="side">

		<!--最新更新主题-->
		<!--{block name="spacenews" parameter="catid/$thecat[subcatid]/order/i.dateline DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/7280/cachename/newnews/tpl/data"}-->
		<!--{if $_SBLOCK['newnews']}-->
		<div class="block topblock">
			<h3>最新更新</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">#date('n-d', $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--月度关注热点-->
		<!--{block name="spacenews" parameter="catid/$thecat[subcatid]/dateline/2592000/order/i.viewnum DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/28800/cachename/hotnews/tpl/data"}-->
		<!--{if $_SBLOCK['hotnews']}-->
		<div class="block">
			<h3>月度热点</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">#date('n-d', $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--{if !empty($ads3['viewsiderad'])}-->
		<div class="block">
			<h3>网络推荐</h3>
			<div style="text-align:center;padding:0.5em;">$ads3['viewsiderad']</div>
		</div>
		<!--{/if}-->
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads3['pagefootad'])}-->
<div class="adbox">$ads3[pagefootad]</div>
<!--{/if}-->

<script language="javascript" type="text/javascript">
<!--
	addMediaAction('articlebody');
	addImgLink("articlebody");
//-->
</script>
<!--{if !empty($ads3['pagemovead']) || !empty($ads3['pageoutad'])}-->
<!--{if !empty($ads3['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads3[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads3[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads3['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads3[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads3['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads3['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}
