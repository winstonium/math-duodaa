<?exit?>
{template news_header}
<!--{eval $ads = getad('system', 'news', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<!-- Content内容 -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--图文资讯幻灯片-->
		<!--{block name="spacenews" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/subjectlen/24/subjectdot/1/cachetime/11930/cachename/picnews/tpl/data"}-->
		<div id="slideimg">
		<!--{if !empty( $_SBLOCK['picnews'])}-->
		<script type="text/javascript" language="javascript">
		<!--			
		var xsTextBar = 1; //是否显示文字链接，1为显示，0为不显示
		var xsPlayBtn = 0; //是否显示播放按钮，1显示，0为不显示
		var xsImgSize = new Array(260,217); //幻灯图片的尺寸，格式为“宽度,高度”
	
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picnews'] $key $value}-->
		xsImgs[$i] = "$value[a_thumbpath]";
		xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		
		<!--一周回复排行头条-->
		<!--{block name="spacenews" parameter="dateline/604800/showattach/1/showdetail/1/order/i.replynum DESC/limit/0,1/subjectlen/34/subjectdot/1/messagelen/80/messagedot/1/cachetime/18600/cachename/headnews/tpl/data"}-->
		<div id="headline">
			<!--{if !empty($_SBLOCK['headnews'])}-->
			<!--{loop $_SBLOCK['headnews'] $value}-->
			<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<div id="hotarticle" class="tabblock" style="margin-left: 274px;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="newnewstab" href="javascript:setTab('hotarticle','newnews');" class="tab curtab">最新资讯</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week');" class="tab">周点击榜</a>
				<a id="monthtab" href="javascript:setTab('hotarticle','month');" class="tab">月点击榜</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all');" class="tab">总点击榜</a>
			</h3>
			<!--最新资讯列表-->
			<!--{block name="spacenews" parameter="order/i.dateline DESC/limit/0,6/subjectlen/40/subjectdot/1/cachetime/13800/cachename/newnews/tpl/data"}-->
			<div id="newnews" class="tabcontent">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['newnews'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门资讯列表(一周)-->
			<!--{block name="spacenews" parameter="dateline/604800/order/i.viewnum DESC/limit/0,6/cachetime/85400/subjectlen/40/subjectdot/1/cachename/hotnews1/tpl/data"}-->
			<div  id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotnews1'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门资讯列表(一月)-->
			<!--{block name="spacenews" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,6/cachetime/97200/subjectlen/40/subjectdot/1/cachename/hotnews2/tpl/data"}-->
			<div id="month" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotnews2'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门资讯列表(全部)-->
			<!--{block name="spacenews" parameter="order/i.viewnum DESC/limit/0,6/cachetime/99400/subjectlen/40/subjectdot/1/cachename/hotnews3/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotnews3'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!--图片资讯显示-->
		<div id="picnews">
			<h3>图片资讯</h3>
			<!--{block name="spacenews" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/limit/0,5/cachetime/8000/cachename/picnews/tpl/data"}-->
			<ul id="scroller" class="imgthumblist">
				<!--{loop $_SBLOCK['picnews'] $value}-->
				<li class="list1line">
					<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[a_thumbpath]" alt="$value[subjectall]" /></a></div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--{block name="announcement" parameter="order/displayorder/limit/0,1/cachetime/96400/subjectlen/30/subjectdot/1/cachename/announce/tpl/data"}-->
		<div id="announcement">
			<strong>公告:</strong>
			<!--{if empty($_SBLOCK['announce'])}-->
				暂时没有公告
			<!--{else}-->
			<!--{loop $_SBLOCK['announce'] $value}-->
				<a href="$value[url]" target="_blank">$value[subject]</a>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--各分类最新资讯列表-->
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spacenews" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/subjectlen/36/subjectdot/1/cachename/newslist/tpl/data"}-->
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newslist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">更多……</a></li>
			</ul>
		</div>
		<!--{/loop}-->
		</div>
	</div>
	
	<!-- 右侧版块 -->
	<div class="side">
		
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,30/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>热门TAG</h3>
			<div>
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
		
		<!--最新评论资讯显示-->
		<!--{block name="spacenews" parameter="order/i.lastpost DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/7500/cachename/newnews/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>评论更新</h3>
			<ul>
				<!--{loop $_SBLOCK['newnews'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">#date("m-d", $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--月度评论热点-->
		<!--{block name="spacenews" parameter="lastpost/2592000/order/i.replynum DESC/limit/0,10/cachetime/75400/subjectlen/30/subjectdot/1/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>月度评论热点</h3>
			<ul>
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">#date("m-d", $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>

	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}