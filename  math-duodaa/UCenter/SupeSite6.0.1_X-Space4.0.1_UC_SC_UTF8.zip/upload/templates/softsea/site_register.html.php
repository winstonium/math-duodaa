<?exit?>
{template site_header}

<div id="menu"><h1>欢迎 $_SGLOBAL[supe_username_show], 升级自己的个人空间</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>

<style>
#signform { margin: 1em 0; }
	#signform fieldset { margin: 0; border: 0; padding: 10px; }
		#signform legend { display: none; }
#signform p { border-bottom: 1px solid #EEE; zoom: 1; overflow: hidden; margin: 0; padding: 0.3em; line-height: 20px; }
	#signform p strong { float: left; width: 10em; }
		#signform li p { height: auto; border: none; }
	#signform button { line-height: 30px; height: 30px; padding: 0 5em; }
</style>

<script language="javascript">
function submitcheck() {
	var catid = getbyid("catid");
	if (catid.value<1) {
		alert("请为自己的空间选择一个合适的分类");
		catid.focus();
		return false;
	}
	return true;
}
</script>

<div style="zoom: 1; overflow: hidden; margin: 0 2em;" class="block topblock">
	<form id="signform" method="post" action="#action/register/php/1#" onsubmit="return submitcheck();">
		<fieldset>
			<legend>升级空间</legend>
			<p><strong>个人空间名:</strong><input type="text" id="spacename" name="spacename" size="40" value="$_SGLOBAL[supe_username_show]的个人空间" /></p>
			<p><strong>空间分类:</strong>
			<select id="catid" name="catid">
			<option value="">选择空间分类</option>
			$catstr
			</select>
			</p>
			<p><strong>所在地区:</strong>
			<script type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<script type="text/javascript">
			<!--
				showprovince('province', 'city', '');
				showcity('city', '');
			//-->
			</script>
			</p>
			
			<!--{if !empty($channels['menus']['blog'])}-->
			<p><strong>空间模式:</strong>根据个人的喜欢，给自己挑选一个空间模式吧：</p>
			<div style="margin-left: 10em;">
			<input type="radio" id="spacemode" name="spacemode" value="bbs" checked /> <b>论坛模式</b><br>
			如果你经常逛论坛，很少有时间来写点日志的话，那就选择论坛模式吧，你的空间首页大部分区域显示的是你在论坛上面的帖子。<br>
			<input type="radio" id="spacemode" name="spacemode" value="blog" /> <b>日志模式</b><br>
			准备使用博客写日志了吗？如果你要升级自己的空间主要用来写日志的话，就选择日志模式吧，你的空间首页大部分区域会显示你的最新日志。<br>
			更多模式...<br />升级空间后，您还可以选择更多的空间模式。
			</div>
			<!--{else}-->
			<input type="hidden" name="spacemode" value="bbs">
			<!--{/if}-->
			
			<p><strong>选择模板:</strong></p>
			<ul class="imagelist">
			<!--{loop $tpllist $tplkey $tplvalue}-->
			<li><div><a href="$tplvalue[a_filepath]" target="_blank"><img src="$tplvalue[a_thumbpath]" alt="$tplvalue[tplname]" /></a></div><p><input type="radio" id="tplid$tplvalue[tplid]" name="tplid" value="$tplvalue[tplid]" style="vertical-align: text-bottom;" /><label for="tplid$tplvalue[tplid]">$tplvalue[tplname]</label></p></li>
			<!--{/loop}-->
			</ul>
			<p><strong>&nbsp;</strong><button type="submit" value="true" name="registersubmit"> 确　　定 </button></p>
		</fieldset>
	</form>
</div>
</div>
<div class="side">
	<!--{block name="userspace" parameter="order/u.dateline DESC/limit/0,20/cachetime/44000/cachename/newspace/tpl/data"}-->
	<div id="newspace" class="block">
		<h3>新空间</h3>
		<ul>
		<!--{loop $_SBLOCK['newspace'] $value}-->
			<li><a href="$value[url]">$value[spacename]</a></li>
		<!--{/loop}-->
		</ul>
	</div>
</div>
</div>
{template site_footer}