<?exit?>
{template site_header}
<div id="menu"><h1>登录</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div class="block">
			<div class="loginpanel">
				<form id="loginform" action="{S_URL}/batch.login.php?action=login" method="post">
					<fieldset>
						<legend>登录</legend>
						<p><label for="username">用户名</label><input type="text" name="username" id="username" /></p>
						<p><label for="password">密　码</label><input type="password" name="password" id="password" /></p>
						<p><label for="cookietime">有效期</label><select id="cookietime" name="cookietime">
						<option value="0" >浏览器进程</option>
						<option value="315360000" >永久</option>
						<option value="2592000" >一个月</option>
						<option value="86400" >一天</option>
						<option value="3600" >一小时</option>
						</select></p>
						<p><button type="submit" id="loginsubmit" name="loginsubmit" value="true">登录</button></p>
						<input type="hidden" name="refer" value="$refer" />
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<div class="side">
		<div class="block blockG">
			<h3>提示</h3>
			<ul>
				<li>游客可以<a href="{B_URL}/register.php?referer={S_URL}/index.php?action/login">点击此处</a>注册成为本站会员！</li>
				<li>如果您忘记了帐号密码，您可以<a href="{B_URL}/member.php?action=lostpasswd" target="_blank">申请找回密码</a>。</li>
				<li>如果您已经拥有了自己的论坛帐号，您可以使用论坛会员名登录站内系统后，<a href="#action/register#">免费升级</a>属于您的个人空间。</li>
			</ul>
		</div>
	</div>
</div>
{template site_footer}