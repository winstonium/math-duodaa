<?exit?>
{template site_header}
<div id="menu"><h1>安全提问</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div class="block">
			<div class="loginpanel">
				<form id="loginform" action="{S_URL}/batch.login.php?action=login" method="post">
					<!--{if empty($_SCONFIG['ucmode']) && $member['secques']}-->
					<p><label for="questionid">问　题</label><select id="questionid" name="questionid">
					<option value="1">母亲的名字</option>
					<option value="2">爷爷的名字</option>
					<option value="3">父亲出生的城市</option>
					<option value="4">您其中一位老师名字</option>
					<option value="5">您个人计算机的型号</option>
					<option value="6">您最喜欢的餐馆名称</option>
					<option value="7">驾驶执照最后四位数</option>
					</select>
					</p>
					<p><label for="answer">答　案</label><input type="text" id="answer" name="answer" size="25" /></p>
					<!--{/if}-->
					<!--{if empty($_SCONFIG['noseccode'])}-->
					<p class="imgsecode"><label for="xspace-seccode">验证码</label><input type="text" size="5" id="xspace-seccode" name="seccode" value="" />
					<img id="imgsecode" src="{S_URL}/batch.seccode.php" onclick="javascript:newseccode(this);" alt="seccode" title="看不清？点击换一个" align="absmiddle"/>
					<!--{/if}-->
					<p><button value="true" type="submit" id="securitysubmit" name="securitysubmit">登录</button></p>
					<input type="hidden" name="uid" value="$member[uid]">
					<input type="hidden" name="password" value="$member[password]" />
					<input type="hidden" name="cookietime" value="$cookietime" />
					<input type="hidden" name="loginsubmit_secques" value="yes" />
					<input type="hidden" name="refer" value="$refer" />
				</form>
			</div>
		</div>
	</div>
	<div class="side">
		<div class="block blockG">
			<h3>提示</h3>
			<ul>
				<li>由于您启用了安全提问功能，因此需要您进行第二次安全提问验证方可登录。</li>
				<li>启用安全提问功能，可以加强帐号的安全性。</li>
			</ul>
		</div>
	</div>
</div>
{template site_footer}