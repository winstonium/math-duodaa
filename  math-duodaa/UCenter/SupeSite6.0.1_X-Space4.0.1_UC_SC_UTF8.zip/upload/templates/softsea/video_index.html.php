<?exit?>
{template video_header}
<!--{eval $ads = getad('system', 'video', '1');}-->

<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		<div class="midmain">
			<!--{block name="spacevideo" parameter="dateline/604800/order/i.replynum DESC/limit/0,4/cachetime/64400/subjectlen/30/subjectdot/1/showdetail/1/messagelen/40/messagedot/1/cachename/hotvideo/tpl/data"}-->
			<div id="video" class="block">
				<div id="videobox">
					<div id="hotvideo">
						<!--{if !empty($_SBLOCK['hotvideo'][0])}-->
						<!--{eval $value=$_SBLOCK['hotvideo'][0];}-->
						<a href="$value[url]" title="$value[subjectall]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a>
						<p><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a> <span class="smalltxt">$value[viewnum] views, $value[replynum] replies</span></p>
						<!--{/if}-->
					</div>
					<div id="hotvideolist">
						<ul>
							<!--{if !empty($_SBLOCK['hotvideo'][1])}-->
							<!--{eval $value=$_SBLOCK['hotvideo'][1];}-->
							<li>
								<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
								<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
							</li>
							<!--{/if}-->
							<!--{if !empty($_SBLOCK['hotvideo'][2])}-->
							<!--{eval $value=$_SBLOCK['hotvideo'][2];}-->
							<li>
								<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
								<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
							</li>
							<!--{/if}-->
							<!--{if !empty($_SBLOCK['hotvideo'][3])}-->
							<!--{eval $value=$_SBLOCK['hotvideo'][3];}-->
							<li>
								<div><a href="$value[url]" target="_blank" title="$value[subjectall]"><img src="$value[image]" alt="$value[subjectall]" /></a></div>
								<p><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></p>
							</li>
							<!--{/if}-->
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="midside">
			<!--最新上传 -->
			<div class="block" style="background: #F1F5F6 none; height: 270px; overflow: hidden;">
				<!--{block name="spacevideo" parameter="order/i.dateline DESC/limit/0,10/showdetail/1/subjectlen/30/subjectdot/1/cachetime/12000/cachename/newvideo/tpl/data"}-->
				<ul>
					<!--{loop $_SBLOCK['newvideo'] $value}-->
					<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div style="height: 55px;">
			<a href="{S_URL}/spacecp.php?action=spacevideos&amp;op=add" style="float: left; width: 136px; background: #FFFAF5 url({S_URL}/templates/default/images/postvideo.jpg); margin: 1px; line-height: 50px; font-weight: bold; text-indent: 50px; color: #009900;">上传视频</a>
			<a href="{S_URL}/spacecp.php?action=spacevideos&amp;op=online" style="float: left; width: 150px; background: #FFFAF5 url({S_URL}/templates/default/images/postvideo.jpg) no-repeat 0 -50px; margin: 1px; line-height: 50px;  font-weight: bold; text-indent: 50px; color: #009900;">在线录制视频</a>
		</div>
		
		<!--{block name="tag" parameter="order/spacevideonum DESC/limit/0,8/cachetime/21590/cachename/hottag/tpl/data"}-->
		<div class="block" style="height: 100px; margin: 0; overflow: hidden;">
			<h3>热门标签</h3>
			<div style="line-height: 1.9em; overflow: hidden;">
			<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacevideonum])</em></a>
			<!--{/loop}-->
			</div>
		</div>
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads['pagecenterad']
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<!--评论最多-->
		<div id="focusvideo" class="tabblock" style="height: 520px; overflow: hidden;">
			<h3 id="focusvideotabs" class="tabs">
				<a id="weektab" href="javascript:setTab('focusvideo','week')" class="tab curtab">本周焦点</a>
				<a id="monthtab" href="javascript:setTab('focusvideo','month')" class="tab">本月焦点</a>
				<a id="alltab" href="javascript:setTab('focusvideo','all')" class="tab">焦点排行</a>
			</h3>
			<div id="week" class="tabcontent">
			<!--{block name="spacevideo" parameter="dateline/604800/order/i.viewnum DESC/limit/0,10/cachetime/74400/subjectlen/20/subjectdot/1/showdetail/1/messagelen/34/messagedot/1/cachename/focusvideoweek/tpl/data"}-->
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['focusvideoweek'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								上传: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a>
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
								<!--{if $value['goodrate']}-->好评: $value[goodrate]<!--{/if}-->
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<div id="month" class="tabcontent" style="display: none;">
			<!--{block name="spacevideo" parameter="dateline/2092000/order/i.viewnum DESC/limit/0,10/cachetime/84400/subjectlen/20/subjectdot/1/showdetail/1/messagelen/34/messagedot/1/cachename/focusvideomonth/tpl/data"}-->
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['focusvideomonth'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								上传: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a>
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
								<!--{if $value['goodrate']}-->好评: $value[goodrate]<!--{/if}-->
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<div id="all" class="tabcontent" style="display: none;">
			<!--{block name="spacevideo" parameter="order/i.viewnum DESC/limit/0,10/cachetime/94400/subjectlen/20/subjectdot/1/showdetail/1/messagelen/34/messagedot/1/cachename/focusvideo/tpl/data"}-->
				<ul class="thumbmsglist thumb2col">
					<!--{loop $_SBLOCK['focusvideo'] $value}-->
					<li>
						<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[image]" alt="$value[subjectall]" /></a></p>
						<div>
							<h4><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></h4>
							<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
							<p class="msginfo">
								上传: <a href="#uid/$value[uid]/action/space#" target="_blank">$value[username]</a>
								<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a><!--{/if}-->
								<!--{if $value['goodrate']}-->好评: $value[goodrate]<!--{/if}-->
							</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<div class="side">
		<!--推荐影音 等级为4 -->
		<!--{block name="spacevideo" parameter="order/i.goodrate DESC/limit/0,21/cachetime/64400/subjectlen/30/subjectdot/1/cachename/gradevideo/tpl/data"}-->
		<div class="block" style="height: 522px; overflow: hidden;">
			<h3>推荐影音</h3>
			<ul>
				<!--{loop $_SBLOCK['gradevideo'] $value}-->
				<li><a href="$value[url]" target="_blank" title="$value[subjectall]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}