<?exit?>
{template mygroup_header}

<div id="container">
	<div class="side1">
		<div class="block topblock" style="overflow: hidden;">
			<h3>圈子介绍</h3>
			<div class="avatar"><img src="$grouparr[logo]" alt="$grouparr[groupname]" />
			<h2><a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a></h2></div>
			<p>$grouparr[intro]</p>
		</div>
		<div class="block" style="overflow: hidden;">
			<h3>圈子公告</h3>
			<p>$grouparr[announcements]</p>
		</div>
		<!--{if $_SGET['type']!='members'}-->
		<div class="block">
			<h3><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/members#" class="more">所有成员</a>最新成员</h3>
			<ul class="avatarList">
				<!--{block name="groupuser" parameter="gid/$_SGET[gid]/flag/1,2,3/order/g.dateline DESC/limit/0,9/cachetime/11980/cachename/groupuser/tpl/data"}-->
				<!--{loop $_SBLOCK['groupuser'] $value}-->
					<li><a href="#uid/$value[uid]#" target="_blank"><img src="$value[photo]" alt="$value[username]" /><span>$value[username]</span></a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
	</div>
	<div class="content2">
		
<!--{if $_SGET['type']=='recommend'}-->

		<div class="msglist linelist">
		<h3 class="topblock"><a href="{S_URL}/">$_SCONFIG[sitename]</a> &gt; <a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a> &gt; <strong><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/recommend#">成员推荐</a></strong></h3>
		<!--{block name="recommend" parameter="perpage/50/gid/$_SGET[gid]/order/g.dateline DESC/cachename/thelist/tpl/data"}-->
		<ul>
			<!--{loop $_SBLOCK['thelist'] $value}-->
			<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
			<!--{/loop}-->
		</ul>
		</div>
		
<!--{elseif $_SGET['type']=='digest'}-->

		<div class="msglist linelist">
		<div>
			<a href="{S_URL}/spacecp.php?action=spaceblogs&op=add&gid=$_SGET[gid]&openwindow=1" id="postbutton" class="post" onmouseover="showHideCatList('show', 'postbutton', 'postoption', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton', 'postoption');" style="margin-top: 6px;">发表新博文 </a>
			<div class="postoption" id="postoption" onmouseover="showHideCatList('show', 'postbutton', 'postoption', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton', 'postoption');">
				<ul>
				<!--{eval if(isset($channels['types']['news'])) unset($channels['types']['news']);}-->
				<!--{loop $channels['types'] $value}-->
				<!--{eval $spaceaction = gettypetablename($value['nameid']);}-->
				<li><a href="{S_URL}/spacecp.php?action=$spaceaction&op=add&gid=$_SGET[gid]&openwindow=1">$value[name]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
		<h3 class="topblock"><a href="{S_URL}/">$_SCONFIG[sitename]</a> &gt; <a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a> &gt; <strong><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/digest#">精华博文</a></strong></h3>
		<!--{block name="spaceblog" parameter="perpage/50/notype/1/gid/$_SGET[gid]/gdigest/1/order/i.dateline DESC/cachename/thelist/tpl/data"}-->
		<ul>
			<!--{loop $_SBLOCK['thelist'] $value}-->
			<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
			<!--{/loop}-->
		</ul>
		</div>
		
<!--{elseif $_SGET['type']=='members'}-->

		<div class="msglist linelist">
		<h3 class="topblock"><a href="{S_URL}/">$_SCONFIG[sitename]</a> &gt; <a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a> &gt; <strong><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/members#">成员列表</a></strong></h3>
		<!--{block name="groupuser" parameter="gid/$_SGET[gid]/flag/1,2,3/order/g.dateline DESC/perpage/50/cachename/thelist/tpl/data"}-->
		<ul class="thumbmsglist">
			<!--{loop $_SBLOCK['thelist'] $value}-->
			<li>
				<div><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
				<em class="smalltxt">信息数: $value[spaceallnum]</em>
				<h4><a href="$value[url]" target="_blank">$value[spacename]</a></h4>
				<p class="smalltxt"><a href="$value[url]" target="_blank" class="author">$value[username]</a>
				<!--{if $value['province']}--> $value[province]<!--{/if}-->
				<!--{if $value['city']}-->/ $value[city]<!--{/if}--> &nbsp;
				创建于: #date("Y-m-d", $value["dateline"])#<!--{if !empty($value[lastpost])}-->, 最后更新: #date("Y-m-d", $value["lastpost"])#<!--{/if}--></p>
			</li>
			<!--{/loop}-->
		</ul>
		</div>	
		
<!--{elseif empty($_SCONFIG['ucmode']) && $_SGET['type']=='bbs'}-->
		<div class="msglist">
			<h3 class="topblock"><a href="{S_URL}/">$_SCONFIG[sitename]</a> &gt; <a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a> &gt; <a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs#">交流区</a><!--{if !empty($forum['name'])}--> &gt; <strong><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs/fid/$_SGET[fid]#">$forum[name]</a></strong><!--{/if}--></h3>
		</div>
		<div class="threadList">
		<!--{if !empty($_SGET['fid'])}-->
		<!--{block name="bbsthread" parameter="perpage/50/fid/$_SGET[fid]/sgid/$_SGET[gid]/order/dateline DESC/limit/0,10/subjectlen/40/subjectdot/1/cachename/threadlist/tpl/data"}-->
		<div>
			<a href="{B_URL}/post.php?action=newthread&amp;fid=$_SGET['fid']&amp;extra=page%3D1&sgid=$_SGET['gid']" id="postbutton" class="post" onmouseover="showHideCatList('show', 'postbutton', 'postoption', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton', 'postoption');">发表新话题 </a>
			<div class="postoption" id="postoption" onmouseover="showHideCatList('show', 'postbutton', 'postoption', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton', 'postoption');">
				<ul>
					<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$_SGET['fid']&amp;extra=page%3D1&amp;poll=yes&sgid=$_SGET['gid']">投票</a></li>
					<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$_SGET['fid']&amp;extra=page%3D1&amp;trade=yes&sgid=$_SGET['gid']">交易</a></li>
					<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$_SGET['fid']&amp;extra=page%3D1&amp;reward=yes&sgid=$_SGET['gid']">提问</a></li>
					<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$_SGET['fid']&amp;extra=page%3D1&amp;activity=yes&sgid=$_SGET['gid']">活动</a></li>
				</ul>
			</div>
		</div>
		<h3><a href="{B_URL}/forumdisplay.php?fid=$forum[fid]" title="论坛大杂烩模式查看">$forum[name]</a></h3>
		<ul>
		<!--{loop $_SBLOCK['threadlist'] $value}-->
			<li>
				<strong><a href="{B_URL}/viewthread.php?tid=$value[tid]&extra=page%3D1" target="_blank">$value[subject]</a> ($value[replies]/$value[views])</strong>
				<cite><a href="#">$value[author]</a></cite>
				<em>#date("m-d", $value["dateline"])#</em>
			</li>
		<!--{/loop}-->
		</ul>
		</div>
		
		<!--{if $_SBLOCK[threadlist_multipage]}-->
		<div class="pages">
			$_SBLOCK[threadlist_multipage]
		</div>
		<!--{/if}-->
		<!--{/if}-->
				
		<!--{if empty($_SGET['fid'])}-->
		<!--{block name="bbsforum" parameter="type/forum,sub/status/2/order/displayorder/limit/0,100/cachetime/14400/cachename/forumarr/tpl/data"}-->
		<!--{else}-->
		<!--{block name="bbsforum" parameter="type/sub/status/2/fup/$_SGET[fid]/order/displayorder/limit/0,100/cachetime/14400/cachename/forumarr/tpl/data"}-->
		<!--{/if}-->
		<!--{loop $_SBLOCK['forumarr'] $ckey $cat}-->
		<div class="threadList">
			<!--{eval $ctime=300+30*$ckey;}-->
			<!--{block name="bbsthread" parameter="fid/$cat[fid]/sgid/$_SGET[gid]/order/dateline DESC/limit/0,8/cachetime/$ctime/subjectlen/40/subjectdot/1/cachename/threadlist/tpl/data"}-->
			<h3>
			<div>
				<a href="{B_URL}/post.php?action=newthread&amp;fid=$cat[fid]&amp;extra=page%3D1&sgid=$_SGET['gid']" id="postbutton$cat[fid]" class="post" onmouseover="showHideCatList('show', 'postbutton$cat[fid]', 'postoption$cat[fid]', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton$cat[fid]', 'postoption$cat[fid]');">发表新话题 </a>
				<div class="postoption" id="postoption$cat[fid]" onmouseover="showHideCatList('show', 'postbutton$cat[fid]', 'postoption$cat[fid]', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton$cat[fid]', 'postoption$cat[fid]');">
					<ul>
						<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$cat['fid']&amp;extra=page%3D1&amp;poll=yes&sgid=$_SGET['gid']">投票</a></li>
						<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$cat['fid']&amp;extra=page%3D1&amp;trade=yes&sgid=$_SGET['gid']">交易</a></li>
						<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$cat['fid']&amp;extra=page%3D1&amp;reward=yes&sgid=$_SGET['gid']">提问</a></li>
						<li><a href="{B_URL}/post.php?action=newthread&amp;fid=$cat['fid']&amp;extra=page%3D1&amp;activity=yes&sgid=$_SGET['gid']">活动</a></li>
					</ul>
				</div>
			</div>
			<a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs/fid/$cat[fid]#">$cat[name]</a>
			</h3>
			<ul>
				<!--{loop $_SBLOCK['threadlist'] $value}-->
					<li>
						<strong><a href="{B_URL}/viewthread.php?tid=$value[tid]&extra=page%3D1" target="_blank">$value[subject]</a> ($value[replies]/$value[views])</strong>
						<cite><a href="#">$value[author]</a></cite>
						<em>#date("m-d", $value["dateline"])#</em>
					</li>
				<!--{/loop}-->
			</ul>
			<p class="morethread"><a href="#action/mygroup/gid/$_SGET[gid]/op/list/type/bbs/fid/$cat[fid]#">更多讨论信息...</a></p>
		</div>
		<!--{/loop}-->
		
<!--{else}-->

		<div class="msglist linelist">
		<div>
			<a href="{S_URL}/spacecp.php?action=spaceblogs&op=add&gid=$_SGET[gid]&openwindow=1" id="postbutton" class="post" onmouseover="showHideCatList('show', 'postbutton', 'postoption', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton', 'postoption');" style="margin-top: 6px;">发表新博文 </a>
			<div class="postoption" id="postoption" onmouseover="showHideCatList('show', 'postbutton', 'postoption', 0, 20, 80);" onmouseout="showHideCatList('hide', 'postbutton', 'postoption');">
				<ul>
				<!--{eval if(isset($channels['types']['news'])) unset($channels['types']['news']);}-->
				<!--{loop $channels['types'] $value}-->
				<!--{eval $spaceaction = gettypetablename($value['nameid']);}-->
				<li><a href="{S_URL}/spacecp.php?action=$spaceaction&op=add&gid=$_SGET[gid]&openwindow=1">$value[name]</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
		<h3 class="topblock"><a href="{S_URL}/">$_SCONFIG[sitename]</a> &gt; <a href="#action/mygroup/gid/$_SGET[gid]#">$grouparr[groupname]</a> &gt; <strong>博文更新</strong></h3>
		<!--{block name="spaceblog" parameter="perpage/50/notype/1/gid/$_SGET[gid]/order/i.dateline DESC/cachename/thelist/tpl/data"}-->
		<ul>
			<!--{loop $_SBLOCK['thelist'] $value}-->
			<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></cite>[{$value[typename]}] <a href="$value[url]" target="_blank">$value[subject]</a></li>
			<!--{/loop}-->
		</ul>
		</div>
		
<!--{/if}-->

<!--{if !empty($_SBLOCK['thelist_multipage'])}-->
		<div class="pages">
			$_SBLOCK[thelist_multipage]
		</div>
<!--{/if}-->

	</div>
</div>

{template mygroup_footer}