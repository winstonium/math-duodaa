<?exit?>
{template site_header}
<div id="menu"><h1>管理模式</h1></div>
<form id="opform" name="opform" action="batch.manage.php?uid=$uid&itemid=$itemid" method="post">
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $lang[manage] &gt;&gt; <a href="batch.manage.php?uid=$theuid">$space[spacename]</a>
			<!--{if !empty($item[subject])}--> &gt;&gt; <a href="#uid/$item[uid]/action/viewspace/itemid/$item[itemid]#" target="_blank">$item[subject]</a><!--{/if}-->
		</p>

		<!--{if !empty($item)}-->
		<div class="block">
			<h3>$item[subject]</h3>
			<ul class="messagelist">
				<li>
					<p class="msginfo"><strong>IP</strong>: $iteminf[postip]</p>
					<p class="msginfo"><strong>发布时间</strong>: #date("Y-m-d H:i:s", $item["dateline"])#</p>
					<p class="msginfo">查看($item[viewnum]) / 评论($item[replynum]) / 好评($item[goodrate]) / 差评($item[badrate])</p>
					<p><strong>内容源码</strong>:</p>
					<p><textarea style="width:95%; height:20em; border: 1px solid #EEE; background: #FFF; padding: 5px; font: 12px/160% Courier New, Arial, Helvetica, sans-serif;">$iteminf[message]</textarea></p>
				</li>
			</ul>
		</div>
		<div class="block" style="padding:0.5em;">
			<button type="submit" name="actionsubmit" value="delete" onclick="this.form.action+='&actionsubmit=delete';return confirm('确定直接删除吗?');">直接删除</button> 
			<button type="submit" name="actionsubmit" value="rush" onclick="this.form.action+='&actionsubmit=rush';">放入回收站</button> &nbsp;
			<select name="catid">$catstr</select> <button type="submit" name="actionsubmit" value="category" onclick="this.form.action+='&actionsubmit=category';">更改分类</button> 
			$gradestr <button type="submit" name="actionsubmit" value="grade" onclick="this.form.action+='&actionsubmit=grade';">审核等级</button>
		</div>
		
		<!--{if !empty($commentlist)}-->
		<div id="commentlist" class="block">
			<h3>前100条评论源内容</h3>
			<ul class="messagelist">
				<!--{loop $commentlist $value}-->
				<li>
					<h4>
						<input type="checkbox" name="comments[]" value="$value[cid]">
						<!--{if empty($value[authorid])}-->$value[author]<!--{else}--><a href="batch.manage.php?uid=$value[authorid]" class="author">$value[author]</a><!--{/if}-->
					</h4>
					<div>
						<p class="msginfo">(#date("Y-n-d H:i:s", $value["dateline"])#, 评分: <strong class="price">$value[rates]</strong>, IP: $value[ip] )</p>
						<p><textarea style="width:95%; height:5em; border: 1px solid #EEE; background: #FFF; padding: 5px; font: 12px/160% Courier New, Arial, Helvetica, sans-serif;">$value[message]</textarea></p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<div class="block" style="padding:0.5em;"><input type="checkbox" id="chkall" name="chkall" onclick="checkall(this.form, 'comments')" />全选 <button type="submit" name="actionsubmit" value="deletecomment" onclick="this.form.action+='&actionsubmit=deletecomment';">删除评论</button></div>
		<!--{/if}-->
		<!--{/if}-->
		
		<!--{if !empty($itemlist)}-->
		<div class="block">
			<h3>$space[username]的信息列表</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{if $itemlist}-->
				<!--{loop $itemlist $value}-->
				<li>
					<cite>#date("m-d", $value["dateline"])#</cite>
					<input type="checkbox" name="items[]" value="$value[itemid]"> 
					{$lang[$value[type]]} / <a href="{S_URL}/batch.manage.php?itemid=$value[itemid]">$value[subject]</a> 
					($value[viewnum]/$value[replynum])
				</li>
				<!--{/loop}-->
				<!--{if $nextstart}--><li><h4><a href="{S_URL}/batch.manage.php?uid=$uid&start=$nextstart">查看下一列表信息</a></h4></li><!--{/if}-->
				<!--{else}-->
				现在还没有发布信息
				<!--{/if}-->
			</ul>
			<div>$multipage</div>
		</div>
		
		<div class="block" style="padding:0.5em;">
			<input type="checkbox" id="chkall" name="chkall" onclick="checkall(this.form, 'items')" /> 全选 &nbsp;
			<button type="submit" name="actionsubmit" value="deletelist" onclick="this.form.action+='&actionsubmit=deletelist';return confirm('确定直接删除吗?');">直接删除</button> &nbsp;
			<button type="submit" name="actionsubmit" value="rushlist" onclick="this.form.action+='&actionsubmit=rushlist';">放入回收站</button> &nbsp;
			$gradestr <button type="submit" name="actionsubmit" value="gradelist" onclick="this.form.action+='&actionsubmit=gradelist';">等级审核</button>
		</div>
	<!--{/if}-->

	</div>
	<div class="side">
		<div class="block blockG">
			<h3>作者空间</h3>
			<div class="catepic">
				<div><a href="batch.manage.php?uid=$theuid"><img src="$space[photo]" alt="$space[spacename]" border="0" /></a></div>
				<p style="text-align:center;font-weight:bold;"><a href="batch.manage.php?uid=$theuid">$space[username]</a><br><a href="batch.manage.php?uid=$theuid">$space[spacename]</a>
				<br><br>$space[status]
				</p>
			</div>

			<ul class="msgtitlelist">
				<li>总信息数: $space[spaceallnum]</li>
				<li>总浏览量: $space[viewnum]</li>
				<li><a href="{B_URL}/viewpro.php?uid=$theuid">查看论坛资料</a></li>
				<li><a href="batch.manage.php?uid=$theuid">查看作者所发信息</a></li>
				<li>成立时间: #date("Y-m-d H:i:s", $space["dateline"])#</li>
				<li>最后更新: #date("Y-m-d H:i:s", $space["lastpost"])#</li>
			</ul>
		</div>
		
	</div>

</div>
</form>
{template site_footer}