<?exit?>
{template site_header}
<div id="menu"><h1>站点地图</h1></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>

		<!-- 分类区 -->
		<div id="sitemap">
			<!--资讯根分类 开始-->
			<!--{if !empty($channels['types']['news'])}-->
			<!--{block name="category" parameter="type/news/isroot/1/limit/0,100/order/c.displayorder/cachetime/10800/cachename/newscat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['news']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['newscat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--资讯根分类 结束-->
			
			<!--日志根分类 开始-->
			<!--{if !empty($channels['types']['blog'])}-->
			<!--{block name="category" parameter="type/blog/isroot/1/limit/0,100/order/c.displayorder/cachetime/10900/cachename/blogcat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['blog']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['blogcat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--日志根分类 结束-->
		
			<!--图片根分类 开始-->
			<!--{if !empty($channels['types']['image'])}-->
			<!--{block name="category" parameter="type/image/isroot/1/limit/0,100/order/c.displayorder/cachetime/11000/cachename/imagecat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['image']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['imagecat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--图片根分类 结束-->
		
			<!--影音根分类 开始-->
			<!--{if !empty($channels['types']['video'])}-->
			<!--{block name="category" parameter="type/video/isroot/1/limit/0,100/order/c.displayorder/cachetime/21000/cachename/videocat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['video']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['videocat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--影音根分类 结束-->
		
			<!--商品根分类 开始-->		
			<!--{if !empty($channels['types']['goods'])}-->
			<!--{block name="category" parameter="type/goods/isroot/1/limit/0,100/order/c.displayorder/cachetime/11100/cachename/goodscat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['goods']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['goodscat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--商品根分类 结束-->
		
			<!--文件根分类 开始-->
			<!--{if !empty($channels['types']['file'])}-->
			<!--{block name="category" parameter="type/file/isroot/1/limit/0,100/order/c.displayorder/cachetime/11200/cachename/filecat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['file']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['filecat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--文件根分类 结束-->
		
			<!--书签根分类 开始-->
			<!--{if !empty($channels['types']['link'])}-->
			<!--{block name="category" parameter="type/link/isroot/1/limit/0,100/order/c.displayorder/cachetime/11300/cachename/linkcat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['link']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['linkcat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--书签根分类 结束-->
		
			<!--圈子根分类 开始-->
			<!--{if !empty($channels['menus']['group'])}-->
			<!--{block name="category" parameter="type/group/isroot/1/limit/0,100/order/c.displayorder/cachetime/21400/cachename/groupcat/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['group']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['groupcat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--圈子根分类 结束-->
		
			<!--个人空间根分类 开始-->
			<!--{block name="category" parameter="type/space/isroot/1/limit/0,100/order/c.displayorder/cachetime/11400/cachename/spacecat/tpl/data"}-->
			<div class="block">
				<h3>个人空间</h3>
				<ul>
					<!--{loop $_SBLOCK['spacecat'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--个人空间根分类 结束-->
			<!--模型列表开始-->
			<!--{loop $modelarr $value}-->
				<div class="block">
					<h3>$value[modelalias]</h3>
					<ul>
						<!--{loop $value['categories'] $key $val}-->
						<li><a href="{S_URL}/m.php?name={$value[modelname]}&mo_catid=$key" title="$val">$val</a></li>
						<!--{/loop}-->
					</ul>
				</div>
			<!--{/loop}-->
			<!--模型列表结束-->
			<!--论坛版块列表100个 开始-->
			<!--{if !empty($channels['menus']['bbs'])}-->
			<!--{block name="bbsforum" parameter="type/forum/limit/0,100/order/f.displayorder/cachetime/21500/cachename/bbsforum/tpl/data"}-->
			<div class="block">
				<h3>$channels['menus']['bbs']['name']</h3>
				<ul>
					<!--{loop $_SBLOCK['bbsforum'] $value}-->
					<li><a href="$value[url]" title="$value[name]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<!--论坛版块列表100个 结束-->
			
		</div>
		<!-- /类区 -->
	</div>
	<div class="side">
		<!--{block name="tag" parameter="order/spacenewsnum DESC/limit/0,18/cachetime/18000/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>热门TAG</h3>
			<div style="height: 201px;">
				<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spacenewsnum])</em></a>
				<!--{/loop}-->
			</div>
		</div>
	</div>
</div>
{template site_footer}