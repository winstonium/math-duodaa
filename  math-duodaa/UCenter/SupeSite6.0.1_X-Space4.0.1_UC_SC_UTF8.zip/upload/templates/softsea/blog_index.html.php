<?exit?>
{template blog_header}
<!--{eval $ads = getad('system', 'blog', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
	
		<!--最新日志图片幻灯片 开始-->
		<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.dateline DESC/limit/0,4/cachetime/13930/cachename/picblog/tpl/data"}-->
		<div id="slideimg">
		<!--{if !empty( $_SBLOCK['picblog'])}-->
		<script type="text/javascript" language="javascript">
		<!--			
		var xsTextBar = 1; //是否显示文字链接，1为显示，0为不显示
		var xsPlayBtn = 0; //是否显示播放按钮，1显示，0为不显示
		var xsImgSize = new Array(260,217); //幻灯图片的尺寸，格式为“宽度,高度”
	
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picblog'] $key $value}-->
		xsImgs[$i] = "$value[a_thumbpath]";
		xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		
		<!--头条阅读 条件:一周之内发布的/评论最多的-->
		<div id="headline">
			<!--{block name="spaceblog" parameter="dateline/604800/showattach/1/showdetail/1/order/i.replynum DESC/limit/0,1/subjectlen/40/subjectdot/1/messagelen/100/messagedot/1/cachetime/68600/cachename/headblog/tpl/data"}-->
			<!--{if !empty($_SBLOCK['headblog'])}-->
			<!--{loop $_SBLOCK['headblog'] $value}-->
			<strong><a href="$value[url]" target="_blank">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<div id="hotarticle" class="tabblock" style="margin-left: 274px;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="newtab" href="javascript:setTab('hotarticle','new')" class="tab curtab">最新日志</a>
				<a id="daytab" href="javascript:setTab('hotarticle','day')" class="tab">周点击榜</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week')" class="tab">月点击榜</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all')" class="tab">总点击榜</a>
			</h3>
			<!--最新发布的日志-->
			<!--{block name="spaceblog" parameter="order/i.dateline DESC/limit/0,6/showspacename/1/subjectlen/40/subjectdot/1/cachetime/14800/cachename/coolblog/tpl/data"}-->
			<div id="new" class="tabcontent">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{if !empty($_SBLOCK['coolblog'])}-->
						<!--{loop $_SBLOCK['coolblog'] $value}-->
						<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{/if}-->
				</ul>
			</div>
			<!--站内热门BLOG列表(一周)-->
			<!--{block name="spaceblog" parameter="dateline/604800/order/i.viewnum DESC/limit/0,6/cachetime/65400/subjectlen/40/subjectdot/1/cachename/hotarticleweek/tpl/data"}-->
			<div id="day" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotarticleweek'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门BLOG列表(一月)-->
			<!--{block name="spaceblog" parameter="dateline/2592000/order/i.viewnum DESC/limit/0,6/cachetime/77200/subjectlen/40/subjectdot/1/cachename/hotarticlemonth/tpl/data"}-->
			<div id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotarticlemonth'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--站内热门BLOG列表(全部)-->
			<!--{block name="spaceblog" parameter="order/i.viewnum DESC/limit/0,6/cachetime/87400/subjectlen/40/subjectdot/1/cachename/hotarticle/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist" style="height: 144px;">
					<!--{loop $_SBLOCK['hotarticle'] $value}-->
					<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<div id="spacestar">
			<h3>空间之星</h3>
			<!--{block name="userspace" parameter="isstar/1/showdetail/1/order/u.lastpost DESC/limit/0,8/cachetime/94400/cachename/spacestar/tpl/data"}-->
			<ul>
				<!--{loop $_SBLOCK['spacestar'] $value}-->
				<li>
					<div><a href="$value[url]" title="$value[username]"><img src="$value[photo]" alt="$value[spacename]" /></a></div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!-- 同城空间 -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" name="usersearch">同城空间</button>
			</form>
		</div>
	</div>

</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<!--图片日志显示-->
		<!--{block name="spaceblog" parameter="haveattach/1/showattach/1/order/i.lastpost DESC/subjectlen/16/subjectdot/1/limit/0,5/cachetime/8000/cachename/picblog/tpl/data"}-->
		<div class="block" style="padding: 0;">
			<ul class="imagelist" style="height: 133px;">
			<!--{loop $_SBLOCK['picblog'] $value}-->
				<li>
					<div><a href="$value[url]" title="$value[subject]"><img src="$value[a_thumbpath]" alt="$value[subject]" /></a></div>
					<p><a href="$value[url]">$value[subject]</a></p>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	
	<div class="side">
		<!--{block name="tag" parameter="order/spaceallnum DESC/limit/0,20/cachetime/21600/cachename/hottag/tpl/data"}-->
		<div id="hottag" class="block blockG">
			<h3>热门标签</h3>
			<div style="height: 82px; overflow: hidden;">
			<!--{loop $_SBLOCK['hottag'] $value}-->
				<a href="$value[url]">$value[tagname]<em>($value[spaceallnum])</em></a>
			<!--{/loop}-->
			</div>
		</div>		
	</div>
	
</div>

<div class="content">
	<div class="side">
		
		<!--最新用户空间名称列表-->
		<!--{block name="userspace" parameter="lastpost/604800/order/u.spaceblognum DESC/limit/0,10/cachetime/19900/cachename/newspace/tpl/data"}-->
		<div id="hotspace" class="block stat" style="height: 320px;">
			<a href="#action/spaces#" class="more">所有空间</a>
			<h3>一周热点空间</h3>
			<ol>
				<!--{loop $_SBLOCK['newspace'] $value}-->
				<li><a href="$value[url]">$value[spacename]</a></li>
				<!--{/loop}-->
			</ol>
		</div>
		
		<!--最近加入空间-->
		<!--{block name="userspace" parameter="order/u.dateline DESC/limit/0,15/cachetime/11900/cachename/lastspace/tpl/data"}-->
		<div class="block">
			<h3>最近加入空间</h3>
			<ul>
				<!--{loop $_SBLOCK['lastspace'] $value}-->
				<li><a href="$value[url]">$value[spacename]</a> <span class="smalltxt">#date("m-d", $value["dateline"])#</span></li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--站内热门BLOG列表(一周)-->
		<!--{block name="spaceblog" parameter="lastpost/604800/order/i.replynum DESC/limit/0,10/cachetime/15400/subjectlen/30/subjectdot/1/cachename/replyhot/tpl/data"}-->
		<div class="block">
			<h3>一周讨论热点</h3>
			<ul>
				<!--{loop $_SBLOCK['replyhot'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></li>
				<!--{/loop}-->
			</ul>
		</div>
	
		<!--评论更新-->
		<!--{block name="spaceblog" parameter="order/i.lastpost DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/11000/cachename/newblog/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>评论更新</h3>
			<ul>
				<!--{loop $_SBLOCK['newblog'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span></li>
				<!--{/loop}-->
			</ul>
		</div>

	</div>
	<div class="mainarea">
		<div class="blockcategorylist">
		<!--各分类最新日志列表-->
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=1800+30*$ckey;}-->
		<!--{block name="spaceblog" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/subjectlen/30/subjectdot/1/cachetime/$ctime/subjectlen/36/subjectdot/1/cachename/bloglist/tpl/data"}-->
		<div class="blockcategory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bloglist'] $value}-->
				<li><cite><a href="#uid/$value[uid]#">$value[username]</a> </cite><a href="$value[url]" title="$value[subjectall]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">更多……</a></li>
			</ul>
		</div>
		<!--{/loop}-->
		</div>
	</div>
	<!-- /Content -->
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}