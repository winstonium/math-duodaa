<?exit?>
{template bbs_header}
<!--{eval $ads = getad('system', 'bbs', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<!-- Content内容 -->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--图片附件-->
		<!--{block name="bbsattachment" parameter="filetype/image/t_lastpost/2592000/order/t.replies DESC/limit/0,10/cachetime/49900/cachename/picthread/tpl/data"}-->
		<div id="slideimg">
		<!--{if !empty( $_SBLOCK['picthread'])}-->
		<script type="text/javascript" language="javascript">
		<!--			
		var xsTextBar = 1; //是否显示文字链接，1为显示，0为不显示
		var xsPlayBtn = 0; //是否显示播放按钮，1显示，0为不显示
		var xsImgSize = new Array(260,217); //幻灯图片的尺寸，格式为“宽度,高度”
	
		var xsImgs = new Array();
		var xsImgLinks = new Array();
		var xsImgTexts = new Array();
		
		<!--{eval $i=0;}-->
		<!--{loop $_SBLOCK['picthread'] $key $value}-->
		xsImgs[$i] = "$value[attachment]";
		xsImgLinks[$i] = "<!--{eval echo url_remake($value['url']);}-->";
		xsImgTexts[$i] = "<!--{eval echo addslashes($value[subject])}-->";
		<!--{eval $i++;}-->
		<!--{/loop}-->
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="{S_URL}/include/js/slide.js"></script>
		<!--{/if}-->
		</div>
		
		<!--酷主题(2天内评论数最多的帖子)-->
		<!--{block name="bbsthread" parameter="showdetail/1/messagelen/80/subjectlen/34/dateline/172800/order/replies DESC/limit/0,1/cachetime/52400/cachename/coolthread/tpl/data"}-->
		<div id="headline">
			<!--{if !empty($_SBLOCK['coolthread'])}-->
			<!--{loop $_SBLOCK['coolthread'] $value}-->
			<strong><a href="$value[url]">$value[subject]</a></strong>
			<p>$value[message]</p>
			<!--{/loop}-->
			<!--{/if}-->
		</div>
		
		<div id="hotarticle" class="tabblock" style="margin-left: 274px; height: 176px;">
			<h3 id="hotarticletabs" class="tabs">
				<a id="newtab" href="javascript:setTab('hotarticle','new')" class="tab curtab">论坛新帖</a>
				<a id="daytab" href="javascript:setTab('hotarticle','day')" class="tab">本周热点</a>
				<a id="weektab" href="javascript:setTab('hotarticle','week')" class="tab">本月热点</a>
				<a id="alltab" href="javascript:setTab('hotarticle','all')" class="tab">热帖排行</a>
			</h3>
			<!--最新帖子-->
			<!--{block name="bbsthread" parameter="order/dateline DESC/limit/0,6/cachetime/21400/cachename/ratehot/tpl/data"}-->
			<div id="new" class="tabcontent">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['ratehot'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门帖子列表(一周)-->
			<!--{block name="bbsthread" parameter="dateline/604800/order/views DESC/limit/0,6/cachetime/72400/subjectlen/40/subjectdot/1/cachename/hotthreadweek/tpl/data"}-->
			<div id="day" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthreadweek'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门帖子列表(一月)-->
			<!--{block name="bbsthread" parameter="dateline/2592000/order/views DESC/limit/0,6/cachetime/82400/subjectlen/40/subjectdot/1/cachename/hotthreadmonth/tpl/data"}-->
			<div id="week" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthreadmonth'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--热门帖子列表(全部)-->
			<!--{block name="bbsthread" parameter="order/views DESC/limit/0,6/cachetime/92400/subjectlen/40/subjectdot/1/cachename/hotthread/tpl/data"}-->
			<div id="all" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotthread'] $value}-->
					<li><cite><a href="#uid/$value[authorid]#">$value[author]</a> </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
	</div>
	<!-- 右侧 -->
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<input type="text" id="searchkey" name="searchkey" />
				<select name="type" id="type">
					<option value="">全部</option>
					<!--{loop $channels['types'] $value}-->
						<option value="$value[nameid]">$value[name]</option>
					<!--{/loop}-->
				</select>
				<input type="hidden" name="subjectsearch" value="true" />
				<button type="submit" name="searchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<div id="bbsintro" class="block" style="height: 86px; overflow: hidden;">
			<h3>快速链接</h3>
			<ul class="msgtitlelist">
			<li><a href="{B_URL}/">访问论坛</a> <span class="smalltxt">参与交流互动</span></li>
			<li><a href="{B_URL}/register.php">注册会员</a> <span class="smalltxt">拥有个人空间</span></li>
			</ul>
		</div>

		<!-- 论坛公告 -->
		<!--{block name="bbsannouncement" parameter="order/displayorder/limit/0,1/cachetime/96400/cachename/announcelist/tpl/data"}-->
		<div id="announcement">
			<strong>公告:</strong>
			<!--{if empty($_SBLOCK['announcelist'])}-->
				暂时没有公告
			<!--{else}-->
			<!--{loop $_SBLOCK['announcelist'] $ikey $value}-->
				<a href="$value[url]" target="_blank">$value[subject]</a>
			<!--{/loop}-->
			<!--{/if}-->
		</div>


	</div>
	<!-- /右侧 -->
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">
	<div class="mainarea">
		<div class="blockcategorylist">
			<!--各板块最新列表-->
			<!--{loop $_SBLOCK['forumarr'] $ckey $cat}-->
			<!--{eval $ctime=3800+30*$ckey;}-->
			<!--{block name="bbsthread" parameter="fid/$cat[fid]/order/dateline DESC/limit/0,5/cachetime/$ctime/subjectlen/40/subjectdot/1/cachename/threadlist/tpl/data"}-->
			<div class="blockcategory" style="height: 170px;">
				<h3><a href="#action/forumdisplay/fid/$cat[fid]#">$cat[name]</a></h3>
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['threadlist'] $value}-->
					<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
					<!--{/loop}-->
					<li><a href="#action/forumdisplay/fid/$cat[fid]#" class="more">更多……</a></li>
				</ul>
			</div>
			<!--{/loop}-->
		</div>
	</div>
	<!-- 右侧版块 -->
	<div class="side">

		<!--板块根据帖子数排行-->
		<!--{block name="bbsforum" parameter="type/forum/allowblog/1/order/posts DESC/limit/0,10/cachetime/14400/cachename/hotforums/tpl/data"}-->
		<div id="hottforum" class="block" style="height: 320px;">
			<h3>论坛帖子数排行</h3>
			<ol>
				<!--{loop $_SBLOCK['hotforums'] $value}-->
				<li><a href="$value[url]">$value[name] <span class="smalltxt">$value[posts]</span></a></li>
				<!--{/loop}-->
			</ol>
		</div>

		<!--会员排行-->
		<div id="hotmembers" class="tabblock" style="height: 260px; overflow: hidden;">
			<h3 id="hotmemberstabs" class="tabs">
				<a id="poststab" href="javascript:setTab('hotmembers','posts')" class="tab curtab">发帖排行</a>
				<a id="onlinetab" href="javascript:setTab('hotmembers','online')" class="tab">在线排行</a>
			</h3>
			<!--{block name="bbsmember" parameter="order/m.posts DESC/limit/0,10/cachetime/86400/cachename/hotmembers/tpl/data"}-->
			<div id="posts" class="tabcontent">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['hotmembers'] $value}-->
					<li><cite style="text-align: right; margin-right: 5px;">$value[posts]</cite><a href="$value[url]">$value[username]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{block name="bbsmember" parameter="order/m.oltime DESC/limit/0,10/cachetime/86400/cachename/toponline/tpl/data"}-->
			<div id="online" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['toponline'] $value}-->
					<li><cite style="width: 80px; text-align: right;">$value[oltime]小时</cite><a href="$value[url]">$value[username]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		
		<!--最新更新帖子-->
		<!--{block name="bbsthread" parameter="order/lastpost DESC/limit/0,14/subjectlen/30/subjectdot/1/cachetime/11460/cachename/newpost/tpl/data"}-->
		<div id="newpost" class="block">
			<h3>最新评论</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['newpost'] $value}-->
				<li><a href="$value[url]">$value[subject]</a> <span class="smalltxt">($value[replies])</span></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!-- /Content -->
<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}