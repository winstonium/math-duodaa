<?exit?>
{template site_header}
<div id="menu"><h2>TAG</h2></div>
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：
			<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			&gt;&gt; $title
		</p>
		<div class="block">
			<h3>TAG信息列表</h3>
			<ul class="msgtitlelist linelist articlelist">
				<!--{loop $iarr $value}-->
				<li><cite><a href="#action/$value[type]#">{$value[typename]}</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<div class="pagediv">
			$multi
		</div>
	</div>
	<div class="side">
		<div class="block blockG">
			<h3>TAG信息</h3>
			<h1 id="tagname">$tag[tagname]</h1>
			<ul class="msgtitlelist">
				<li>创建者: <a href="$tag[spaceurl]" target="_blank" class="author">$tag[username]</a></li>
				<li>创建时间: #date("Y-m-d H:i:s",$tag["dateline"])#</li>
				<li>总信息数: $tag[spaceallnum]</li>
				<li><a href="#action/tag/tagid/$tag[tagid]#">分类列表</a></li>
			</ul>
		</div>
		<div class="block">
			<h3>相关TAG</h3>
			<ul class="msgtitlelist">
				<!--{if $tag[relativetags]}-->
				<!--{loop $tag[relativetags] $key $value}-->
				<li><a href="#action/tag/tagname/$key#">$value</a></li>
				<!--{/loop}-->
				<!--{else}-->
				<li>暂无相关TAG</li>
				<!--{/if}-->
			</ul>
		</div>
	</div>
</div>

{template site_footer}