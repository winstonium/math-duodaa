<?exit?>
{template spaces_header}

<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>

		<div class="block">
			<h3><strong>留下脚印</strong></h3>
			<ul class="thumbmsglist thumb2col">
				<!--{if empty($trackarr)}-->
				<li>现在还没有人留下脚印</li>
				<!--{else}-->
				<!--{loop $trackarr $value}-->
				<li>
					<p class="thumb"><a href="$value[url]" target="_blank"><img src="$value[photo]" alt="$value[username]曾经在 #date("Y-n-d", $value["dateline"])# 访问过该主题" /></a></p>
					<div>
					<p><a href="$value[url]" target="_blank">$value[username]</a></p>
					<p>#date("Y-n-d", $value["dateline"])#</p>
					</div>
				</li>
				<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
	</div>
	<div class="side">
		
		<div class="block blockG">
			<h1>同城空间</h1>
		</div>

		<!-- 同城空间 -->
		<div id="cityspace" class="block cleanblock">
			<script language="javascript" type="text/javascript" src="{S_URL}/include/js/city.js"></script>
			<form action="{S_URL}/batch.search.php" method="post">
				<script language="javascript" type="text/javascript">showprovince('province', 'city', '');</script><script language="javascript" type="text/javascript">showcity('city', '');</script>
				<button value="true" type="submit" name="usersearch">同城空间</button>
			</form>
		</div>
		
		<!--一周更新排行榜-->
		<!--{block name="userspace" parameter="lastpost/604800/limit/0,10/order/u.viewnum DESC/cachetime/29800/cachename/hotlist/tpl/data"}-->
		<div class="block">
			<h3>一周更新排行榜</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['hotlist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[spacename]</a>
					<span class="smalltxt"><a href="$value[url]" target="_blank" title="$value[spacename]">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>
<!-- /Content -->

{template site_footer}