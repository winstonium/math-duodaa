<?exit?>
{template group_header}
<!--{eval $ads = getad('system', 'group', '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--最近更新-->
		<!--{block name="group" parameter="order/g.lastpost DESC/limit/0,5/cachetime/9900/cachename/updategroup/tpl/data"}-->
		<div class="block topblock">
			<h3>最近更新</h3>
			<ul class="imagelist" style="height: 140px; overflow: hidden;">
				<!--{loop $_SBLOCK['updategroup'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<p><a href="$value[url]" target="_blank" title="$value[groupname]">$value[groupname]</a></p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<div id="infos" class="tabblock" style="height: 240px; overflow: hidden;">
			<h3 id="infostabs" class="tabs">
				<a id="newinfotab" href="javascript:setTab('infos','newinfo');" class="tab curtab">最新圈子文章</a>
				<a id="hotinfotab" href="javascript:setTab('infos','hotinfo');" class="tab">周点击榜</a>
			</h3>
			<!--最新文章-->
			<!--{block name="spaceblog" parameter="notype/1/allgroup/1/showgroupname/1/order/i.dateline DESC/limit/0,18/cachetime/9880/cachename/newinfo/tpl/data"}-->
			<div id="newinfo" class="tabcontent">
				<ul class="msgtitlelist list2col linelist">
					<!--{if $_SBLOCK['newinfo']}-->
						<!--{loop $_SBLOCK['newinfo'] $value}-->
							<li><cite><a href="#action/mygroup/gid/$value[gid]#" target="_blank">$value[g_groupname]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{else}-->
						<li>暂无信息</li>
					<!--{/if}-->
				</ul>
			</div>
			<!--最热文章-->
			<!--{block name="spaceblog" parameter="notype/1/allgroup/1/showgroupname/1/dateline/604800/order/i.viewnum DESC/limit/0,18/cachetime/61980/cachename/hotinfo/tpl/data"}-->
			<div id="hotinfo" class="tabcontent" style="display: none;">
				<ul class="msgtitlelist list2col linelist">
					<!--{if $_SBLOCK['hotinfo']}-->
						<!--{loop $_SBLOCK['newinfo'] $value}-->
							<li><cite><a href="#action/mygroup/gid/$value[gid]#" target="_blank">$value[g_groupname]</a></cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
						<!--{/loop}-->
					<!--{else}-->
						<li>暂无信息</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>

	</div>
	<div class="side">
		<div id="searchdiv">
			<form id="searchform" action="{S_URL}/batch.search.php" method="post">
				<label for="searchkey2">圈子名</label><input type="text" name="searchkey" id="searchkey2" />&nbsp;
				<input type="hidden" name="groupsearch" value="true" />
				<button type="submit" name="groupsearchbtn" value="true">搜索</button>
				<a href="{S_URL}/batch.search.php">高级搜索</a>
			</form>
		</div>
		<!-- 用户面板 -->
		<div id="userpanel">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		
		<!--最新成立圈子-->
		<!--{block name="group" parameter="order/g.dateline DESC/limit/0,12/cachetime/13900/cachename/newgroup/tpl/data"}-->
		<div class="block" style="height: 310px;">
			<h3>最新成立</h3>
			<ul>
				<!--{loop $_SBLOCK['newgroup'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[groupname]</a></dt>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / 成员:$value[usernum]</span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<!--{if !empty($ads['pagecenterad'])}-->
<div class="adbox">
	$ads[pagecenterad]
</div>
<!--{/if}-->

<div class="content">

	<div class="side">
		<!--{block name="group" parameter="lastpost/604800/order/g.usernum DESC/limit/0,3/showdetail/1/cachetime/29900/cachename/weekhotgroup/tpl/data"}-->
		<div class="block blockG">
			<h3>周热门圈子</h3>
			<ul class="thumblist">
				<!--{loop $_SBLOCK['weekhotgroup'] $value}-->
				<li>
					<div><a href="$value[url]" target="_blank"><img src="$value[logo]" alt="$value[groupname]" /></a></div>
					<h6><a href="$value[url]" target="_blank">$value[groupname]</a></h6>
					<p>圈主: <a href="#uid/$value[uid]#" target="_blank" class="author">$value[username]</a> / 成员: $value[usernum]</p>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
		<!--{block name="group" parameter="order/g.usernum DESC/limit/0,10/cachetime/91900/cachename/hotgrouplist/tpl/data"}-->
		<div class="block" style="height: 320px;">
			<h3>圈子排行</h3>
			<ol>
				<!--{loop $_SBLOCK['hotgrouplist'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[groupname]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> / 成员:$value[usernum]</span>
				</li>
				<!--{/loop}-->
			</ol>
		</div>
	</div>
	<div class="mainarea">
		
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['category'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
			<div class="blockcategory">
				<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
				<!--{block name="group" parameter="catid/$cat[subcatid]/order/g.lastpost DESC/limit/0,10/cachetime/$ctime/cachename/catgroup/tpl/data"}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['catgroup'] $key $value}-->
					<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[groupname]</a></li>
					<!--{/loop}-->
					<li><a href="#action/category/catid/$cat[catid]#" class="more">更多……</a></li>
				</ul>
			</div>
		<!--{/loop}-->
		</div>
	</div>
</div>

<!-- /Content -->

<!--{if !empty($ads['pagefootad'])}-->
<div class="adbox">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->
{template site_footer}