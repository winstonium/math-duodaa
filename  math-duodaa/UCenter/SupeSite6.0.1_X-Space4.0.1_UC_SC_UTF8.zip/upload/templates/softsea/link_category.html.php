<?exit?>
{template link_header}
<!--{eval $ads2 = getad('system', 'link', '2');}-->
<!--{if !empty($ads2['pageheadad'])}-->
<div class="adbanner">$ads2[pageheadad]</div>
<!--{/if}-->
<div class="content topcontent">
	<div class="mainarea">
		<p id="nav">您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</p>
		
		<!--当前分类最新列表-->
		<!--{if $_SGET['page']<2 || empty($_SGET['mode'])}-->
		<!--{block name="spacelink" parameter="catid/$thecat[subcatid]/order/i.dateline DESC/perpage/15/cachetime/12220/showdetail/1/messagelen/150/messagedot/1/cachename/newlist/tpl/data"}-->
		<!--{if $_SBLOCK['newlist']}-->
		<div class="block">
			<h3>$thecat[name]</h3>
			<ul class="messagelist">
			<!--{loop $_SBLOCK['newlist'] $value}-->
				<li>
					<h4><a href="$value[url]" target="_blank">$value[subject]</a></h4>
					<p class="msginfo">
						<a href="#uid/$value[uid]#" target="_blank">$value[username]</a>, 发布于 #date("Y-m-d", $value["dateline"])# 
						<!--{if $value[replynum]}--><a href="$value[url]" target="_blank" class="replynum">评论: $value[replynum]</a> <!--{/if}-->
						<!--{if $value[goodrate]}-->好评: $value[goodrate] <!--{/if}-->
					</p>
					<!--{if $value['message']}--><p>$value[message]</p><!--{/if}-->
					<p class="msginfo">
						<a href="#uid/$value[uid]/action/viewspace/itemid/$value[itemid]#" target="_blank">评论</a> |
						<a href="{S_URL}/batch.viewlink.php?action=snapshot&itemid=$value[itemid]" target="_blank">快照</a> |
						<a href="{S_URL}/batch.viewlink.php?action=copy&itemid=$value[itemid]" target="_blank">复制</a> |
						<a href="{S_URL}/batch.viewlink.php?action=domain&itemid=$value[itemid]" target="_blank">同站点</a> |
						<a href="{S_URL}/batch.viewlink.php?action=subject&itemid=$value[itemid]" target="_blank">同标题</a> 
					</p>
				</li>
			<!--{/loop}-->
			</ul>

			<!--{if $_SBLOCK[newlist_multipage]}--><div class="pages">
			$_SBLOCK[newlist_multipage]
			</div><!--{/if}-->
			
		</div>
		<!--{/if}-->
		<!--{/if}-->

		<!--论坛资源列表-->
		<!--{if !empty($thecat['bbsmodel'])}-->
		<!--{if $_SGET['page']<2 || !empty($_SGET['mode'])}-->
		<!--{eval $_SGET['mode']='bbs';}-->
		<!--{block name="bbsthread" parameter="perpage/20/$thecat[blockparameter]/cachename/bbsthreadlist/tpl/data"}-->
		<!--{if $_SBLOCK['bbsthreadlist']}-->
		<div class="block">
			<h3>论坛资源</h3>
			<ul class="msgtitlelist">
				<!--{loop $_SBLOCK['bbsthreadlist'] $value}-->
				<li><cite>#date("m-d", $value["dateline"])# </cite><a href="$value[url]">$value[subject]</a></li>
				<!--{/loop}-->
			</ul>
			
			<!--{if $_SBLOCK[bbsthreadlist_multipage]}-->
			<div class="pages">
			$_SBLOCK[bbsthreadlist_multipage]
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->

		<!--子分类最新列表-->
		<!--{block name="category" parameter="upid/$thecat[catid]/order/c.displayorder/limit/0,100/cachetime/10900/cachename/subarr/tpl/data"}-->
		<!--{if $_SGET['page']<2}-->
		<div class="blockcategorylist">
		<!--{loop $_SBLOCK['subarr'] $ckey $cat}-->
		<!--{eval $ctime=2800+30*$ckey;}-->
		<!--{block name="spacelink" parameter="catid/$cat[subcatid]/order/i.dateline DESC/limit/0,10/cachetime/$ctime/showdetail/1/messagelen/150/messagedot/1/cachename/sublist/tpl/data"}-->
		<!--{if $_SBLOCK['sublist']}-->
		<div class="blockcatrgory">
			<h3><a href="#action/category/catid/$cat[catid]#">$cat[name]</a></h3>
			<ul class="messagelist">
			<!--{loop $_SBLOCK['sublist'] $value}-->
				<li><cite><a href="#uid/$value[uid]#" target="_blank">$value[username]</a> </cite><a href="$value[url]" target="_blank">$value[subject]</a></li>
			<!--{/loop}-->
				<li><a href="#action/category/catid/$cat[catid]#" class="more">更多……</a></li>
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		</div>
		<!--{/if}-->
	</div>

	<div class="side">
	
		<div class="block blockG">
			<h1>$thecat[name]</h1>
			<!--{if $thecat['thumb'] || $thecat['note']}-->
			<div class="catepic">
				<!--{if $thecat['thumb']}-->
				<div><img src="{A_URL}/$thecat[thumb]" alt="" /></div>
				<!--{/if}-->
				<!--{if $thecat['note']}-->
				<p>$thecat[note]</p>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			
			<!--{if $_SBLOCK['subarr']}-->
				<ul class="msgtitlelist">
					<!--{loop $_SBLOCK['subarr'] $value}-->
					<li><a href="$value[url]">$value[name]</a></li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		
		<!--站内推荐书签-->
		<!--{block name="spacelink" parameter="catid/$thecat[subcatid]/dateline/2592000/order/i.viewnum DESC/limit/0,15/subjectlen/30/subjectdot/1/cachetime/15400/cachename/hotlink/tpl/data"}-->
		<div class="block">
			<h3>月度点击排行榜</h3>
			<ul>
				<!--{loop $_SBLOCK['hotlink'] $value}-->
				<li>
					<a href="$value[url]" target="_blank">$value[subject]</a>
					<span class="smalltxt"><a href="#uid/$value[uid]#" target="_blank">$value[username]</a></span>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		
	</div>
</div>
<!-- /Content -->

<!--{if !empty($ads2['pagefootad'])}-->
<div class="adbox">$ads2[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads2['pagemovead']) || !empty($ads2['pageoutad'])}-->
<!--{if !empty($ads2['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads2[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads2['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads2[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads2['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads2['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

{template site_footer}