<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	���˿ռ���ҳ�ļ�

	$RCSfile: space.php,v $
	$Revision: 1.100 $
	$Date: 2007/06/05 13:19:37 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

$uid = $_SGET['uid'] = empty($_SGET['uid'])?0:intval($_SGET['uid']);
if(empty($uid)) messagebox('error', 'not_found', S_URL);

dbconnect();

//ģ�鲼��
$leftblock = $mainblock = $rightblock = $detailblock = '';

//����
$guidearr = array();

//��ȡ�ռ���Ϣ
$space = getuserspace($uid);
if(empty($space)) {
	dbconnect(1);
	$query = $_SGLOBAL['db_bbs']->query("SELECT m.uid, m.groupid, m.username, m.regdate, m.lastvisit, m.posts, mf.avatar FROM ".tname('members', 1)." m LEFT JOIN ".tname('memberfields', 1)." mf ON mf.uid=m.uid WHERE m.uid='$uid'");
	if($space = $_SGLOBAL['db']->fetch_array($query)) {

		//�ж��Ƿ���Ȩ���Զ�ӵ�пռ�/û����ת����������
		if(!empty($blackgroupids) && in_array($space['groupid'], $blackgroupids)) sheader(B_URL.'/viewpro.php?uid='.$uid);
		
		include_once(S_ROOT.'./include/common.inc.php');
		
		//�ж��Ƿ���
		@include_once(S_ROOT.'./data/system/group.cache.php');
		
		$space['spacename'] = $space['username'].$lang['personal_space'];
		$space['othernum'] = 10;
		
		$space['group'] = array();
		if(!empty($_SGLOBAL['grouparr'][$space['groupid']])) $space['group'] = $_SGLOBAL['grouparr'][$space['groupid']];
		
		getcookie();
		
		$space['showcp'] = 0;
		if($uid == $_SGLOBAL['supe_uid']) {
			if(!empty($space['group']['allowspace'])) $space['showcp'] = 1;
		}
		
		$space['photo'] = $space['avatar'];
		if(empty($space['photo'])) {
			$space['photo'] = S_URL.'/images/base/space_noface.gif';
		} elseif(!strexists($space['photo'], '://')) {
			$space['photo'] = B_URL.'/'.$space['photo'];
		}

		$space['sightml'] = '';
		
		//ҳ�����
		$title = $space['spacename'].' - '.$_SCONFIG['sitename'].' '.$_SCONFIG['seotitle'].' - Powered by X-Space';

		include_once(S_ROOT.'./include/space_nospace.inc.php');
		
		ob_out();
		exit();
	} else {
		messagebox('error', 'not_found');//�����ڵ��û�
	}
} else {
	$musicmsgs = unserialize($space['music']);
	$musicload = empty($_SGET['notloaded'])?1:0;
	if(!empty($musicmsgs['mp3list']) && $musicload) {
		if(empty($musicmsgs['config']['passpage'])){
			if(empty($_SGET['noframe'])) {
				echo '<script language="javascript" type="text/javascript">parent.window.location.href="'.S_URL.'/iframe.php?uid='.$uid.'&passpage=1";</script>';
			}
		}else {
			$_SCONFIG['htmlspace'] = 0;
			if(empty($_SGET['noframe'])) {
				echo '<script language="javascript" type="text/javascript">parent.window.location.href="'.S_URL.'/iframe.php?uid='.$uid.'";</script>';
			}
		}
	}
	//�ռ�����
	if($space['islock']) {
		$_SCONFIG['htmlspace'] = 0;
		getcookie(1);
		if($uid != $_SGLOBAL['supe_uid'] && $_SGLOBAL['member']['groupid'] != 1) messagebox('error', 'space_lock');
	} else {
		getcookie();
	}

	$isupdate = freshcookie('u'.$uid);

	//����
	$spaceself = 0;
	if($uid == $_SGLOBAL['supe_uid']) {
		$spaceself = 1;
		$space['showcp'] = 1;
		$_SGET['php'] = 1;
	} else {
		$space['showcp'] = 0;
		//���½�ӡ
		if($isupdate && $_SGLOBAL['supe_uid']) $_SGLOBAL['db']->query("REPLACE INTO ".tname('visitors')." (uid, visitoruid, dateline) VALUES ('$uid', '$_SGLOBAL[supe_uid]', '$_SGLOBAL[timestamp]')");
	}
	
	//CSSԤ��
	if(!empty($_SGET['css'])) $_SCONFIG['htmlspace'] = 0;
	
	//html��̬
	if(!empty($_SCONFIG['htmlspace'])) {
		$_SHTML['uid'] = $uid;
		$_SHTML['action'] = 'space';
		$_SHTML['noframe'] = $_SGET['noframe'];
		$_SGLOBAL['htmlfile'] = gethtmlfile($_SHTML);
		ehtml('get', $_SCONFIG['htmlspacetime']);
		$_SCONFIG['debug'] = 0;
		$space['showcp'] = 0;//����ʾ��ݹ���
	}

	//���¿ռ�鿴��
	if($isupdate || !$_SCONFIG['updateview']) updatespaceviewnum($uid);

	include_once(S_ROOT.'./include/common.inc.php');
	
	//ҳ�����
	$title = $space['spacename'].' - '.$_SCONFIG['sitename'].' '.$_SCONFIG['seotitle'].' - Powered by X-Space';
	$keywords = $space['username'].','.$space['province'].','.$space['city'];
	$description = $space['announcement'];
	$turl = empty($musicmsgs['config']['passpage'])?geturl("uid/$uid"):geturl("uid/$uid/notloaded/1");
	$thepagename = '<a href="'.$turl.'">'.$lang['front_page_space'].'</a>';
	
	//ҳ����Ч
	$effect = '';
	if(!empty($space['flash'])) {
		@include_once(S_ROOT.'./data/system/effect.cache.php');
		if(isset($_SGLOBAL['effect'][$space['flash']])) {
			$flashurl = $_SGLOBAL['effect'][$space['flash']]['file'];
			$flashurl = str_replace('SITEURL', S_URL, $flashurl);
		} else {
			$flashurl = $space['flash'];
		}
		$flashurl = shtmlspecialchars($flashurl);//��html��
		$effect .= '<!--[if IE]><object id="flashplay" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="700" height="400" style="left: 50%; margin-left:-350px; position: absolute; top: -5px">
			<param name="movie" value="'.$flashurl.'" />
			<param name="quality" value="high" />
			<param name="wmode" value="transparent" />
			<embed src="'.$flashurl.'" id="theflash" style="left: 50%; margin-left:-350px; position: absolute; top: -5px" align="right" width="700" height="400" type="application/x-shockwave-flash" wmode="transparent" quality="high"></embed>
			</object><![endif]-->';
	}
	
	//ҳ�湫��
	if (strpos('str_'.$_SCONFIG['allowannounce'], 'front')) {
		@include_once(S_ROOT.'./data/system/announcement.cache.php');
		$sitemsg = '';
		if (empty($_SGLOBAL['announcement'])) {
			$_SGLOBAL['announcement'] = array();
		}
		foreach ($_SGLOBAL['announcement'] as $key => $listvalue) {
			$sitemsg .= '<p><a href=\"'.geturl('action/announcement/id/'.$listvalue['id']).'\" target=\"_blank\">' .cutstr($listvalue['subject'], 26, 1).'<\/a><\/p>';
		}
		if(!empty($sitemsg)) {
			$effect .= '<script type="text/javascript" language="javascript">
			<!--
			var siteMsg = "'.$sitemsg.'";
			getMsg();
			//-->
			</script>';
		}
	}

	//ģ�鲼��
	//�ռ�ģʽ
	$leftblock = 'search,archive,comment,favorite';
	if($space['spacemode'] == 'diy') {
		//�Զ���
		$leftblock = $space['choiceblockleft'];
		$mainblock = $space['choiceblockmain'];
		$rightblock = $space['choiceblockright'];
		if($space['blogmod']) $detailblock = 'newblog,newimage,group';
	} elseif($space['spacemode'] == 'bbs') {
		//��̳ģʽ
		$leftblock = 'bbsreply,bbsfavorite,bbsforum';
		$mainblock = 'mythread,myblog,group,newitem';
		$detailblock = 'mythread,group';
	} elseif ($space['spacemode'] == 'blog') {
		//��־ģʽ
		$mainblock = 'newblog,group,newitem,mythread';
		//�Ƿ�ѡ��ֻ��ʾ����
		if(empty($space['blogmod'])) {
			$detailblock = 'group';
		} else {
			$detailblock = 'newblog,group';
		}
	} elseif ($space['spacemode'] == 'image') {
		//ͼƬģʽ
		$mainblock = 'newimage,group,newitem,mythread';
		$detailblock = 'newimage,group';
	} elseif ($space['spacemode'] == 'video') {
		//Ӱ��ģʽ
		$mainblock = 'newvideo,group,newitem,mythread';
		$detailblock = 'newvideo,group';
	} elseif ($space['spacemode'] == 'goods') {
		//��Ʒģʽ
		$mainblock = 'newgoods,group,newitem,mythread';
		$detailblock = 'newgoods,group';
	} elseif ($space['spacemode'] == 'file') {
		//�ļ�ģʽ
		$mainblock = 'newfile,group,newitem,mythread';
		$detailblock = 'newfile,group';
	} elseif ($space['spacemode'] == 'link') {
		//��ǩģʽ
		$mainblock = 'newlink,group,newitem,mythread';
		$detailblock = 'newlink,group';
	} elseif ($space['spacemode'] == 'group') {
		//Ȧ��ģʽ
		$mainblock = 'group,newitem,mythread';
		$detailblock = 'group';
	} elseif ($space['spacemode'] == 'fav') {
		//�ղ�ģʽ
		$mainblock = 'favorite,group,newitem,mythread';
		$detailblock = 'favorite,group';
	} elseif ($space['spacemode'] == 'track') {
		//�㼣ģʽ
		$mainblock = 'track,group,newitem,mythread';
		$detailblock = 'track,group';
	} elseif ($space['spacemode'] == 'all') {
		//�ۺ�ģʽ
		$leftblock = 'search,archive,guestbook,comment,favorite,bbsreply,bbsforum,bbsfavorite';
		$mainblock = 'newblog,newimage,newvideo,newgoods,newfile,newlink,group,mythread,myblog';
	} else {
		//Ĭ��ģʽ
		$leftblock = 'search,comment';
		$mainblock = 'group,newitem';
	}

	$space['showside'] = 1;
	if($space['spacemode'] != 'diy') {
		$leftblock = 'photo,action,calendar,'.(empty($leftblock)?'':$leftblock.',').'visitor,track,friend,userlink,music,information,rss';
	}

	$showtplfile = '';
	include_once(S_ROOT.'./include/space_template.inc.php');
	
	ob_out();
	
	//html��̬
	if(!empty($_SCONFIG['htmlspace'])) {
		ehtml('make');
	}
}

?>