<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	��ʾ�������

	$RCSfile: batch.ad.php,v $
	$Revision: 1.17 $
	$Date: 2007/08/07 08:25:22 $
*/

define('IN_SUPESITE', TRUE);

$adid = empty($_GET['id'])?0:intval($_GET['id']);
if(empty($adid)) exit();
$_SGLOBAL = array();

@include_once('./data/system/aduser.cache.php');
@include_once('./function/main.func.php');

if(empty($_SGLOBAL['ad'][$adid])) exit();
$thead = $_SGLOBAL['ad'][$adid];

$parameters = $thead['parameters'];
if($thead['adtype'] == 'iframe') {
	$thead['adiframecontent'] = $parameters['adiframecontent'];
	print<<<END
	<div>$thead[adiframecontent]</div>
END;

} elseif($thead['adtype'] == 'js') {
	$code = $parameters['adjscontent'];
	$code = str_replace(array('<!--', '//-->'), '', $code);
	$code = preg_replace("/(\r|\n)/s", '', $code);
	$code = addcslashes($code, '\'"\\');
	echo "document.write('$code')";
}
?>