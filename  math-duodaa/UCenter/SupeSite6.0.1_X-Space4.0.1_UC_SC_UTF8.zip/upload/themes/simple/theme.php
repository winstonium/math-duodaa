<?php

$themes = array(
	'name'		=> '简单又简单',
	'preview'	=> 'preview.jpg',
	'css'		=> 'style.css',
	'thumb'		=> 'thumb_preview.jpg'
);

?>