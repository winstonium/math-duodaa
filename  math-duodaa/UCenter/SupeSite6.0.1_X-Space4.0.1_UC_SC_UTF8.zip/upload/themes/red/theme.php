<?php

$themes = array(
	'name'		=> '红色激情',
	'preview'	=> 'preview.jpg',
	'css'		=> 'style.css',
	'thumb'		=> 'thumb_preview.jpg'
);

?>