<?php

$themes = array(
	'name'		=> '蓝色经典',
	'preview'	=> 'preview.jpg',
	'css'		=> 'style.css',
	'thumb'		=> 'thumb_preview.jpg'
);

?>