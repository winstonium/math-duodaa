<?php

$themes = array(
	'name'		=> 'default风格<br />列表页有图片<br />适用于大多数模型',
	'preview'	=> 'preview.jpg',
	'thumb'		=> 'thumb_preview.jpg'
);

?>