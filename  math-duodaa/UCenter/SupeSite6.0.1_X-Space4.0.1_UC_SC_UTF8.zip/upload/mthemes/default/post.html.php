<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->

<link href="$siteurl/images/edit/edit.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="$siteurl/images/edit/edit.js"></script>
<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>

<div id="content">
	<div id="navigation">
    	<em>
        <!--{if $modelsinfoarr[allowpost]}-->
        <a href="$posturl" title="在线投稿" class="vote">在线投稿</a>
        <!--{/if}-->
        <!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
        <a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="信息管理" class="admin">信息管理</a>
        <!--{/if}-->
        </em>
        您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
        <!--{loop $guidearr $value}-->
        &gt;&gt; <a href="$value[url]">$value[name]</a>
        <!--{/loop}-->
		&gt;&gt; <a href="#">在线投稿</a>
    </div>
	<div id="main">
		<div id="post" class="block topblock">
		$formstr
		</div>
	</div>

	<div id="side">
		<!-- 用户面板 -->
		<div id="model-login" class="block topblock">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>
		<!--{if !empty($gatherarr)}-->
		<!--{loop $gatherarr $key $value}-->
		<!--{if !empty($value)}-->
		<div class="types block">
			<h3>$cacheinfo[columns][$key][fieldcomment]</h3>
			<ul>
				<!--{loop $value $tmpvalue}-->
				<li><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$key=<!--{eval echo rawurlencode($tmpvalue);}-->">$tmpvalue</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
	</div>

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->