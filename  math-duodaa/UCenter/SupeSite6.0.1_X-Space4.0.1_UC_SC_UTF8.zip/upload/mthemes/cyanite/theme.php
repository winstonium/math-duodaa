<?php

$themes = array(
	'name'		=> '蓝色调为主<br />列表页无图片<br />适用招聘、人才、活动等',
	'preview'	=> 'preview.jpg',
	'thumb'		=> 'thumb_preview.jpg'
);

?>