<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads = getad('system', $modelsinfoarr[modelname], '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div class="models-content">
	<div class="models-main">
		<div class="models-nav">
			您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
			<!--{loop $guidearr $value}-->
			&gt;&gt; <a href="$value[url]">$value[name]</a>
			<!--{/loop}-->
		</div>
		<fieldset>
			<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
			<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>
			<legend>搜索</legend>
			<form method="get" name="modelsearch" id="modelsearch" action="{S_URL}/m.php">
			<ul class="models-fieldset">
			<!--{loop $searchtable $value}-->
				<li>$value</li>
			<!--{/loop}-->
			</ul>
			<p class="models-btnframe">
				<input name="name" type="hidden" id="name" value="$_GET[name]" />
				<input type="submit" value="搜索" class="btnsearch"> 
				<input type="reset" value="重置" class="btnreset">
			</p>
			$linkagestr
			</form>
		</fieldset>
		<fieldset>
			<legend>$lang[system_catid]</legend>
			<ul class="models-fieldset">
				<!--{if !empty($categories)}-->
				<!--{loop $categories $key $value}-->
				<li><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$key" title="$value">$value</a></li>
				<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</fieldset>
		<!--{if !empty($ads['pagecenterad'])}-->
		<div class="admiddle">
			$ads[pagecenterad]
		</div>
		<!--{/if}-->
		<div class="models-articlelist">
			<!--{if !empty($listarr)}-->
			<!--{loop $listarr $key $value}-->
			<div class="models-article">
				<p class="thumb"><a href="$value[ss_url]" target="_blank" title="$value[subject]"><img src="$value[ss_imgurl]" alt="$value[subject]" /></a></p>
				<div class="models-articlelistinfo">
					<p class="title"><a href="$value[ss_url]" target="_blank">$value[subject]</a></p>
					<!--{if !empty($columnsinfoarr)}-->
					<ul>
					<!--{loop $columnsinfoarr $tmpkey $tmpvalue}-->
						<!--{if !is_array($value[$tmpkey])}-->
						<!--{if strlen($value[$tmpkey]) > 0}-->
							<li><em>$tmpvalue[fieldcomment]:</em>
							<!--{if $tmpvalue[formtype]!='timestamp' }-->
							<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$tmpkey=<!--{eval echo rawurlencode($value[$tmpkey]);}-->">$value[$tmpkey]</a>
							<!--{else}-->
							#date("m月d日 H:i", $value[$tmpkey])#
							<!--{/if}-->
							</li>
						<!--{/if}-->
						<!--{else}-->
							<li class="maxcontent"><em>$tmpvalue[fieldcomment]:</em>
							<!--{loop $value[$tmpkey] $dkey $dvalue}-->
								<!--{if $tmpvalue[formtype]=='textarea' }-->
								$dvalue 
								<!--{else}-->
								<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$tmpkey=<!--{eval echo rawurlencode($dvalue);}-->">$dvalue</a>
								<!--{/if}-->
							<!--{/loop}-->
							</li>
						<!--{/if}-->
					<!--{/loop}-->
					</ul>
					<!--{/if}-->
				</div>
			</div>
			<!--{/loop}-->
			<!--{/if}-->
		</div>

		<!--{if $multipage}-->
		<div class="pages">
			<div class="models-page">
				$multipage
			</div>
		</div>
		<!--{/if}-->
	</div>
	<div class="models-side">
		<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
		<div class="models-sideblock">
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="信息管理"><img src="$siteurl/$tpldir/images/models_btn_admin.jpg" title="信息管理" /></a>
		</div>
		<!--{/if}-->
		<!--{if $modelsinfoarr[allowpost]}-->
		<div class="models-sideblock">
			<a href="$posturl" title="在线投稿"><img src="$siteurl/$tpldir/images/models_btn_vote.jpg" alt="在线投稿"/></a>
		</div>
		<!--{/if}-->
		<!-- 用户面板 -->
		<div class="models-sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--{if !empty($childcategories)}-->
		<div class="models-sidesort">
			<h3>$cacheinfo[categoryarr][$_GET[mo_catid]][name]</h3>
			<ul>
				<!--{loop $childcategories $value}-->
				<li><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$value[catid]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<!--{if !empty($gatherarr)}-->
		<!--{loop $gatherarr $key $value}-->
		<!--{if !empty($value)}-->
		<div class="models-sidetags">
			<h3>$cacheinfo[columns][$key][fieldcomment]</h3>
			<p>
				<!--{loop $value $tmpvalue}-->
				<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$key=<!--{eval echo rawurlencode($tmpvalue);}-->">$tmpvalue</a>
				<!--{/loop}-->
			</p>
		</div>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
	</div>
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adfooter">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->