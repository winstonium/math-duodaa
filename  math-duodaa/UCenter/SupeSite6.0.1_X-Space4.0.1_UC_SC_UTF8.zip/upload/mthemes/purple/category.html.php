<?exit?>
<!--{eval include template($tpldir.'/header.html.php', 1);}-->
<!--{eval $ads = getad('system', $modelsinfoarr[modelname], '1');}-->
<!--{if !empty($ads['pageheadad'])}-->
<div class="adbanner">$ads[pageheadad]</div>
<!--{/if}-->
<div id="title">
	<em>
		您的位置：<a href="{S_URL}/">$_SCONFIG[sitename]</a>
		<!--{loop $guidearr $value}-->
		&gt;&gt; <a href="$value[url]">$value[name]</a>
		<!--{/loop}-->
	</em>
	<h2>$value[name]</h2>
</div>
<div id="main">
	<div id="loverlist">
		<!--{if !empty($ads['pagecenterad'])}-->
		<div class="admiddle">
			$ads[pagecenterad]
		</div>
		<!--{/if}-->

		<!--{if !empty($listarr)}-->
		<!--{loop $listarr $key $value}-->
		<div class="lover">
			<p class="loverthumb"><a href="$value[ss_url]" target="_blank" title="$value[subject]"><img src="$value[ss_imgurl]" alt="$value[subject]" /></a></p>
			<div class="loverinfo">
				<div class="author"><em><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$value[catid]">$categories[$value[catid]]</a></em>
				<h3><a href="$value[ss_url]" target="_blank">$value[subject]</a></h3></div>
				<!--{if !empty($columnsinfoarr)}-->
				<ul>
				<!--{loop $columnsinfoarr $tmpkey $tmpvalue}-->
					<!--{if !is_array($value[$tmpkey])}-->
					<!--{if strlen($value[$tmpkey]) > 0}-->
						<li>
						<!--{if $tmpvalue[formtype]!='timestamp' }-->
						<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$tmpkey=<!--{eval echo rawurlencode($value[$tmpkey]);}-->">$value[$tmpkey]</a>
						<!--{else}-->
						#date("m月d日 H:i", $value[$tmpkey])#
						<!--{/if}-->
						</li>
					<!--{/if}-->
					<!--{else}-->
						<li class="maxcontent">
						<!--{loop $value[$tmpkey] $dkey $dvalue}-->
							<!--{if $tmpvalue[formtype]=='textarea' }-->
							$dvalue 
							<!--{else}-->
							<a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_$tmpkey=<!--{eval echo rawurlencode($dvalue);}-->">$dvalue</a>
							<!--{/if}-->
						<!--{/loop}-->
						</li>
					<!--{/if}-->
				<!--{/loop}-->
				</ul>
				<!--{/if}-->
				<p class="more"><a href="$value[ss_url]" target="_blank" class="info">详细资料</a></p>
			</div>
		</div>
		<!--{/loop}-->
		<!--{else}-->
		<div class="errframe">
			<div class="error">抱歉没有找到相关信息！</div>
		</div>
		<!--{/if}-->
		<!--{if $multipage}-->
		<div id="page">
			$multipage
		</div>
		<!--{/if}-->
	</div>
	<div id="listside">
		<div class="control">
			<!--{if !empty($cacheinfo[perms][$_SGLOBAL[supe_uid]])}-->
			<a href="javascript:;" onclick="javascript:OpenWindow('$siteurl/admincp.php?action=modelmanages&mid=$modelsinfoarr[mid]','check',770,500);" title="信息管理" class="admin">信息管理</a>
			<!--{/if}-->
			<!--{if $modelsinfoarr[allowpost]}-->
			<a href="$posturl" title="立即加入" class="join">立即加入</a>
			<!--{/if}-->
		</div>
		<div id="sidelogin">
			<script src="{S_URL}/batch.panel.php?rand={eval echo rand(1, 999999)}" type="text/javascript" language="javascript"></script>
		</div>

		<!--{if !empty($childcategories)}-->
		<div class="sidesort">
			<h3>$cacheinfo[categoryarr][$_GET[mo_catid]][name]</h3>
			<ul>
				<!--{loop $childcategories $value}-->
				<li><a href="$siteurl/m.php?name=$modelsinfoarr[modelname]&mo_catid=$value[catid]">$value[name]</a></li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

		<div id="search">
			<h4>高级搜索</h4>
			<script type="text/javascript" src="{S_URL}/model/data/$modelsinfoarr[modelname]/images/validate.js"></script>
			<script type="text/javascript" src="{S_URL}/include/js/selectdate.js"></script>
			<form method="get" name="modelsearch" id="modelsearch" action="{S_URL}/m.php">
			<ul>
				<!--{loop $searchtable $value}-->
				<li>$value</li>
				<!--{/loop}-->
			</ul>
			$linkagestr
			<p>
				<input name="name" type="hidden" id="name" value="$_GET[name]" />
				<input type="submit" value="搜索" class="btnsearch"> 
				<input type="reset" value="重置" class="btnreset">
			</p>
			</form>
		</div>
	</div>
</div>

<!--{if !empty($ads['pagefootad'])}-->
<div class="adfooter">$ads[pagefootad]</div>
<!--{/if}-->

<!--{if !empty($ads['pagemovead']) || !empty($ads['pageoutad'])}-->
<!--{if !empty($ads['pagemovead'])}-->
<div id="coupleBannerAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div style="position: absolute; left: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
	<div style="position: absolute; right: 6px; top: 6px;">
		$ads[pagemovead]
		<br />
		<img src="{S_URL}/images/base/advclose.gif" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('coupleBannerAdv');">
	</div>
</div>
<!--{/if}-->
<!--{if !empty($ads['pageoutad'])}-->
<div id="floatAdv" style="z-index: 10; position: absolute; width:100px;left:10px;top:10px;display:none">
	<div id="floatFloor" style="position: absolute; right: 6px; bottom:-700px">
		$ads[pageoutad]
	</div>
</div>
<!--{/if}-->
<script type="text/javascript" src="{S_URL}/include/js/floatadv.js"></script>
<script type="text/javascript">
<!--{if !empty($ads['pageoutad'])}-->
var lengthobj = getWindowSize();
lsfloatdiv('floatAdv', 0, 0, 'floatFloor' , -lengthobj.winHeight).floatIt();
<!--{/if}-->
<!--{if !empty($ads['pagemovead'])}-->
lsfloatdiv('coupleBannerAdv', 0, 0, '', 0).floatIt();
<!--{/if}-->
</script>
<!--{/if}-->

<!--{if !empty($ads['pageoutindex'])}-->
$ads[pageoutindex]
<!--{/if}-->

<!--{eval include template($tpldir.'/footer.html.php', 1);}-->