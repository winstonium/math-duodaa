<?php

$themes = array(
	'name'		=> '粉色调为主<br />列表页有图片<br />适用交友、女性、宠物等',
	'preview'	=> 'preview.jpg',
	'thumb'		=> 'thumb_preview.jpg'
);

?>