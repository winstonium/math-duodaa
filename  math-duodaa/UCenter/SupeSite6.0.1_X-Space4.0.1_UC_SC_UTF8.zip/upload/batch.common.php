<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	ϵͳ���õ���һЩ����

	$RCSfile: batch.common.php,v $
	$Revision: 1.175 $
	$Date: 2007/08/01 09:21:56 $
*/

include_once('./include/main.inc.php');
include_once(S_ROOT.'./language/batch.lang.php');

$action = empty($_GET['action'])?'':$_GET['action'];

if($action == 'rightclick') {
	
	//��ǩ�Ҽ�
	print<<<END
	<script language="JavaScript">
	if (external.menuArguments) {
		var parentwin = external.menuArguments;
		if (parentwin.document.selection) {
			var sel = parentwin.document.selection.createRange().text;
		}
		if (!sel) {
			var sel = '';
		}
		var url = parentwin.location.href;
		var title = parentwin.document.title;
		var charset = document.charset;
		if (parentwin.event.srcElement.tagName == "A") {
			url = parentwin.event.srcElement.getAttribute("HREF");
			title = parentwin.event.srcElement.innerText;
		}
		void(window.open('$siteurl/spacecp.php?action=spacelinks&op=add&openwindow=1&charset='+charset+'&title='+title+'&url='+url+'&message='+sel,'_blank','height=660,width=800,left=0,top=0,resizable=1,scrollbars=1'));
	} else {
		history.go(-1);
	}
	</script>
END;
	
} elseif($action == 'joinfavorite') {

	//�����ղ�
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	if(empty($itemid)) showxml($blang['message_favorate_none']);

	getcookie(1);
	
	if(empty($_SGLOBAL['supe_uid'])) showxml($blang['message_need_login_fav']);

	include_once('./include/common.inc.php');
	
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spaceitems')." WHERE itemid='$itemid' AND folder='1'");
	if($item = $_SGLOBAL['db']->fetch_array($query)) {
		replacetable('favorites', array('uid'=>$_SGLOBAL['supe_uid'], 'itemid'=>$itemid, 'dateline'=>$_SGLOBAL['timestamp']));
		clearspacecache($_SGLOBAL['supe_uid'], 'favorite');
		showxml($blang['message_fav_ok']);
	} else {
		showxml($blang['message_favorate_none']);
	}

} elseif ($action == 'emailfriend') {

	//�Ƽ�������
	if(submitcheck('submitemailfriend')) {
		//���ʹ���
		$_POST['sendtoemail'] = str_replace(array(' ', '|', ';'), ',', $_POST['sendtoemail']);
		$email_to = $_POST['sendtoemail'];
		$email_from = $adminemail;
		$email_subject = $blang['mail_title'];
		$email_message = $_POST['message'];
		if(!empty($email_to) && !empty($email_message)) {
			include_once(S_ROOT.'./include/common.inc.php');
			include_once(S_ROOT.'./include/sendmail.inc.php');
		}
		echo '
		<script language="javascript">
		var ajaxdiv = parent.document.getElementById("xspace-ajax-div");
		ajaxdiv.style.display="none";
		alert("'.$blang['message_mail_ok'].'");
		</script>';
		exit;
	}
	
	include_once(S_ROOT.'./data/system/config.cache.php');
	
	$item = array();
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	getcookie();
	if($itemid) {
		dbconnect();
		$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spaceitems')." WHERE itemid='$itemid' AND folder='1'");
		$item = $_SGLOBAL['db']->fetch_array($query);
	}
	if(empty($item)) {
		$message = "{$blang[mail_c1]}\n\n$_SSCONFIG[sitename]\n{$blang[mail_c2]} ".S_URL_ALL."\n\n{$blang[mail_c3]}";
	} else {
		if($item['type'] == 'news') {
			$url = S_URL_ALL.'/?viewnews-'.$item[itemid];
		} else {
			$url = S_URL_ALL.'/?viewspace-'.$item[itemid];
		}
		$message = "{$blang[mail_c4]} $_SSCONFIG[sitename] {$blang[mail_c5]} $item[subject]\n{$blang[mail_c2]}: $url\n\n{$blang[mail_c6]}";
	}

	$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';" target="_self">'.$blang['mail_close'].'</a>'.$blang['mail_submit'].'</h5>
	<div class="xspace-ajaxcontent">
		<form method="post" action="'.S_URL.'/batch.common.php?action=emailfriend" target="phpframe_emailfriend">
			<table width="100%" summary="" cellpadding="5" cellspacing="0" border="0">
				<tr>
					<td width="60">'.$blang['mail_add'].'</td>
					<td><input type="text" name="sendtoemail" style="width: 98%;" value=""></td>
				</tr>
				<tr>
					<td valign="top">'.$blang['mail_content'].'</td>
					<td valign="top"><textarea rows="8" name="message" style="width: 98%;">'.$message.'</textarea></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><button type="submit" name="submitemailfriend" value="true">'.$blang['mail_submit'].'</button></td>
				</tr>
			</table>
		</form>
	</div>
	<iframe id="phpframe_emailfriend" name="phpframe_emailfriend" width="0" height="0" marginwidth="0" frameborder="0" src="about:blank"></iframe>';

	showxml($html);

} elseif ($action == 'price') {
	
	//������Ʒ����
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	if(empty($itemid)) messagebox('error', 'system_error');
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) messagebox('error', 'no_login', geturl('action/login'));
	
	$query = $_SGLOBAL['db']->query('SELECT i.*, g.* FROM '.tname('spaceitems').' i LEFT JOIN '.tname('spacegoods').' g ON i.itemid=g.itemid WHERE i.itemid=\''.$itemid.'\' AND i.subtype=\'auction\'');
	if(!$item = $_SGLOBAL['db']->fetch_array($query)) messagebox('error', 'system_error');
	if($item['uid'] == $_SGLOBAL['supe_uid']) messagebox('error', 'no_self');

	if(empty($item['term'])) $item['term'] = 7;
	$item['endtime'] = $item['starttime'] + $item['term']*24*3600;
	
	if(($item['endtime'] < $_SGLOBAL['timestamp']) && empty($item['status'])) {
		include_once(S_ROOT.'./include/common.inc.php');
		updatetable('spaceitems', array('folder'=>3), array('itemid'=>$item['itemid']));
		messagebox('error', 'no_auction');
	}

	if ($item['stocknum'] <= 0 || $_SGLOBAL['timestamp'] > $item['endtime'] || $_SGLOBAL['timestamp'] < $item['starttime']) {
		messagebox('error', 'no_auction');
	}
	
	$query = $_SGLOBAL['db']->query('SELECT price FROM '.tname('goodsprice').' WHERE itemid=\''.$itemid.'\' ORDER BY price DESC LIMIT 0,1');
	if(!$price = $_SGLOBAL['db']->result($query, 0)) {
		$price = $item['price'] + $item['markup'];
	} else {
		$price = $price + $item['markup'];
	}
	
	if(submitcheck('pricesubmit')) {
		include_once(S_ROOT.'./include/common.inc.php');
		
		$_POST['price'] = intval($_POST['price']);
		$_POST['buynum'] = intval($_POST['buynum']);
		if($_POST['price'] < $price) messagebox('error', $blang['message_price1'].' '.$price.' '.$blang['price_unit']);
		if($_POST['buynum'] < 1) messagebox('error', $blang['message_input_price']);
		if($_POST['buynum'] > $item['stocknum']) messagebox('error', $blang['message_buynum1'].' '.$item['stocknum']);
		
		$insertsqlarr = array();
		$insertsqlarr['itemid'] = $itemid;
		$insertsqlarr['price'] = intval($_POST['price']);
		$insertsqlarr['buynum'] = intval($_POST['buynum']);
		$insertsqlarr['uid'] = $_SGLOBAL['supe_uid'];
		$insertsqlarr['username'] = $_SGLOBAL['supe_username'];
		$insertsqlarr['dateline'] = $_SGLOBAL['timestamp'];
		inserttable('goodsprice', $insertsqlarr);
		
		$_SGLOBAL['db']->query('UPDATE '.tname('spacegoods').' SET price = \''.$insertsqlarr['price'].'\' WHERE itemid=\''.$itemid.'\'');
		
		messagebox('ok', 'succeed', geturl('action/viewspace/itemid/'.$itemid.'/php/1'));
	}
	
	$showtext = "
	<form method=\"post\" name=\"thevalueform\" id=\"thevalueform\" action=\"$siteurl/batch.common.php?action=price&itemid=$itemid\">
		<p>$blang[give_price]:<input name=\"price\" type=\"text\" id=\"price\" size=\"30\" value=\"$price\" /></p>
		<p>$blang[buy_num]:<input name=\"buynum\" type=\"text\" id=\"buynum\" size=\"30\" value=\"1\" /></p>
		<p><center><input type=\"submit\" name=\"pricesubmit\" value=\"$blang[give_price]\" class=\"submit\"></center></p>
	</form>";
	
	messagebox('ok', $showtext);

} elseif ($action == 'auction') {
	
	//��������
	$code = empty($_GET['code'])?'':$_GET['code'];
	$priceid = intval(authcode($code, 'DECODE'));
	if(empty($priceid)) messagebox('error', 'system_error');
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) messagebox('error', 'no_login', geturl('action/login'));
	
	$query = $_SGLOBAL['db']->query('SELECT p.*, i.*, ii.* FROM '.tname('goodsprice').' p INNER JOIN '.tname('spaceitems').' i ON i.itemid=p.itemid AND i.uid=\''.$_SGLOBAL['supe_uid'].'\' LEFT JOIN '.tname('spacegoods').' ii ON ii.itemid=p.itemid WHERE p.priceid=\''.$priceid.'\' LIMIT 1');
	if(!$price = $_SGLOBAL['db']->fetch_array($query)) messagebox('error', 'system_error');

	if($price['uid'] != $_SGLOBAL['supe_uid']) messagebox('error', 'no_permission');
	if($price['buynum'] > $price['stocknum']) messagebox('error', $blang['message_no_num']);

	$_SGLOBAL['db']->query('UPDATE '.tname('goodsprice').' SET status = 1 WHERE priceid=\''.$priceid.'\'');
	$_SGLOBAL['db']->query('UPDATE '.tname('spacegoods').' SET status = 1, stocknum=stocknum-'.$price['buynum'].' WHERE itemid=\''.$price['itemid'].'\'');

	messagebox('ok', 'succeed', geturl('action/viewspace/itemid/'.$price['itemid'].'/php/1'));
	
} elseif ($action == 'joinfriend') {

	//��Ϊ����
	$uid = empty($_GET['uid'])?0:intval($_GET['uid']);
	if(empty($uid)) showxml($blang['message_friend_no_choice']);
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) showxml($blang['message_need_login_friend']);
	if($uid == $_SGLOBAL['supe_uid']) showxml($blang['message_no_self_friend']);
	
	include_once(S_ROOT.'./include/common.inc.php');
	replacetable('friends', array('uid'=>$_SGLOBAL['supe_uid'], 'frienduid'=>$uid, 'dateline'=>$_SGLOBAL['timestamp'], 'grade'=>'1'));
	$parameterarr = array(
		'touid' => $uid
	);
	sendpm('addfriend', $parameterarr);
	clearspacecache($_SGLOBAL['supe_uid'], 'friend');
	showxml($blang['message_friend_ok']);

} elseif ($action == 'viewnews') {

	//�鿴����ǰһ��/��һ��
	if(!empty($_GET['op']) && !empty($_GET['itemid']) && !empty($_GET['catid'])) {
		$itemid = intval($_GET['itemid']);
		$catid = intval($_GET['catid']);
		$newitemid = 0;
		if($itemid && $catid && $_GET['op'] == 'up') {
			dbconnect();
			$newitemid = $_SGLOBAL['db']->result($_SGLOBAL['db']->query('SELECT itemid FROM '.tname('spaceitems').' WHERE itemid <\''.$itemid.'\' AND catid=\''.$catid.'\' AND folder=\'1\' AND type=\'news\' ORDER BY itemid DESC LIMIT 1'), 0);
		} elseif($itemid && $catid) {
			dbconnect();
			$newitemid = $_SGLOBAL['db']->result($_SGLOBAL['db']->query('SELECT itemid FROM '.tname('spaceitems').' WHERE itemid >\''.$itemid.'\' AND catid=\''.$catid.'\' AND folder=\'1\' AND type=\'news\' ORDER BY itemid LIMIT 1'), 0);
		}
		if(!empty($newitemid)) {
			sheader(geturl('action/viewnews/itemid/'.$newitemid));
		} else {
			sheader(geturl('action/viewnews/itemid/'.$itemid));
		}
	}

} elseif ($action == 'viewspace') {

	//�鿴���˿ռ�ǰһ��/��һ��
	if(!empty($_GET['op']) && !empty($_GET['itemid']) && !empty($_GET['uid'])) {
		$itemid = intval($_GET['itemid']);
		$uid = intval($_GET['uid']);
		$newitemid = 0;
		if($itemid && $uid && $_GET['op'] == 'up') {
			dbconnect();
			$newitemid = $_SGLOBAL['db']->result($_SGLOBAL['db']->query('SELECT itemid FROM '.tname('spaceitems').' WHERE itemid <\''.$itemid.'\' AND uid=\''.$uid.'\' AND folder=\'1\' AND type != \'news\' ORDER BY itemid DESC LIMIT 1'), 0);
		} elseif($itemid && $uid) {
			dbconnect();
			$newitemid = $_SGLOBAL['db']->result($_SGLOBAL['db']->query('SELECT itemid FROM '.tname('spaceitems').' WHERE itemid >\''.$itemid.'\' AND uid=\''.$uid.'\' AND folder=\'1\' AND type != \'news\' ORDER BY itemid LIMIT 1'), 0);
		}
		if(!empty($newitemid)) {
			sheader(geturl('uid/'.$uid.'/action/viewspace/itemid/'.$newitemid));
		} else {
			sheader(geturl('uid/'.$uid.'/action/viewspace/itemid/'.$itemid));
		}
	}

} elseif ($action == 'back') {
	
	$code = empty($_GET['code'])?'':$_GET['code'];
	$code = authcode($code, 'DECODE');
	$carr = explode("\t", $code);
	if(count($carr) != 3) messagebox('error', 'change_user_error', S_URL.'/admincp.php?action=spaces');

	$uid = intval($carr[0]);
	$subuid = intval($carr[1]);
	$thetime = intval($carr[2]);

	getcookie();
	if($subuid != $_SGLOBAL['supe_uid']) messagebox('error', 'change_user_error', S_URL.'/admincp.php?action=spaces');
	if($_SGLOBAL['timestamp'] - $thetime > 1800) messagebox('error', 'change_user_error', S_URL.'/admincp.php?action=spaces');

	dbconnect(1);
	$query = $_SGLOBAL['db_bbs']->query('SELECT * FROM '.tname('members', 1).' WHERE uid=\''.$uid.'\'');
	if($member = $_SGLOBAL['db_bbs']->fetch_array($query)) {
		$uid = $member['uid'];
		$password = $member['password'];
		$secques = $member['secques'];
	
		ssetcookie('sid', '', $cookietime);
		ssetcookie('auth', authcode("$password\t$secques\t$uid", 'ENCODE'), $cookietime);
		setcookie('_refer', '');
		messagebox('ok', 'change_user', S_URL.'/admincp.php?action=spaces');
	}

} elseif ($action == 'trackback') {

	//��ȡtrackback����
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	$code[$_SCONFIG['charset']] = rawurlencode(authcode("$itemid\t$_SCONFIG[charset]\t$_SGLOBAL[timestamp]", 'ENCODE', md5(md5($_SCONFIG['sitekey']))));
	$code['utf8'] = rawurlencode(authcode("$itemid\tutf-8\t$_SGLOBAL[timestamp]", 'ENCODE', md5(md5($_SCONFIG['sitekey']))));

	$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['mail_close'].'</a>'.$blang['trackback_title'].'</h5>';
	$html .= '<div class="xspace-ajaxcontent" style="padding: 1.5em;">'.$blang['page_encode'].': ';
	$html .= '<a href="'.S_URL.'/trackback.php?code='.$code[$_SCONFIG['charset']].'" onclick="setCopy(this.href);return false;" target="_self">'.$_SCONFIG['charset'].'('.$blang['click_copy'].')</a>';
	if($_SCONFIG['charset'] != 'utf-8') $html .= ' | <a href="'.S_URL.'/trackback.php?code='.$code['utf8'].'" onclick="setCopy(this.href);return false;" target="_self">utf-8('.$blang['click_copy'].')</a>';
	$html .= '</div>';
	
	showxml($html);

} elseif ($action == 'uploadx') {
	
	//���ļ��ϴ�
	getcookie();
	@header("Expires: -1");
	@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
	@header("Pragma: no-cache");

	include_once(S_ROOT.'./class/upload.class.php');
	$step = intval($_GET['step']);
	$step = $step<1?1:$step;

	$upload = new upload();
	switch($step) {
		case 1:
			$fileInfo = $upload->getFileInfo();
			if(!empty($fileInfo[0])) {
				if($fileInfo[0] == 'error') {
					$upload->delFileInfo();
					echo 'gotoEnd();alert("'.$fileInfo[1].'")';
				} else {
					echo 'setUpload("'.$fileInfo[0].'");';
				}
			}
			break;
		case 2:
			$fileInfo = $upload->getFileInfo();
			if(empty($fileInfo[0])) {
				$upload->delFileInfo();
				echo 'gotoEnd();';
			} elseif($fileInfo[0] == 'error') {
				$upload->delFileInfo();
				echo 'gotoEnd();alert("'.$fileInfo[1].'")';
			} elseif(!empty($fileInfo[1]) && !empty($fileInfo[2])) {
				echo 'fileext="'.$fileInfo[1].'";fileLength="'.$fileInfo[2].'";setFileInfo();';
			} else {
				$upload->delFileInfo();
				echo 'gotoEnd();';
			}
			break;
		case 3:
			$uploadLength = $upload->getUploadSize();
			echo 'uploadLength="'.$uploadLength.'";Process();';
			break;
		default:
			echo 'clearInterval(proInter);';
			break;
	}
	
} elseif ($action == 'flashimage') {

	//��Ƶ�Զ���ȡ��ͼ
	getcookie();
	if(empty($_SGLOBAL['supe_uid'])) exit('Access Denied');
	if(empty($_SERVER['HTTP_FLASHMAKER']) && $_SERVER['HTTP_FLASHMAKER'] != 'SupeSite5.5') {
		exit('Access Denied');
	}
	if(empty($GLOBALS['HTTP_RAW_POST_DATA'])) {
		$GLOBALS['HTTP_RAW_POST_DATA'] = file_get_contents("php://input");
	}
	$flashimg = S_ROOT.'./video/onlinevideo/'.$_SGLOBAL['supe_uid'].'_flashimage.jpg';
	$flashfile = fopen($flashimg, 'wb');
	fwrite($flashfile, $GLOBALS['HTTP_RAW_POST_DATA']);
	fclose($flashfile);

} elseif ($action == 'group') {

	//�Ƽ���Ȧ��
	$allow = false;
	$grouparr = $itemarr = array();
	$html = '';
	$itemid = empty($_GET['itemid'])?intval($_POST['itemid']):intval($_GET['itemid']);
	if(!empty($itemid)) {
		getcookie(1);
		if(!empty($_SGLOBAL['supe_uid'])) {
			include_once(S_ROOT.'./include/common.inc.php');
			$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spaceitems')." WHERE itemid='$itemid' AND folder='1'");
			if($itemarr = $_SGLOBAL['db']->fetch_array($query)) {
				$allow = true;
			}
		}
	}

	if(!$allow) showxml('<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['mail_close'].'</a>'.$blang['group_title'].'</h5><div class="xspace-ajaxcontent" style="text-align: center; padding: 3em 0;">'.$blang['message_null_group'].'</div>');

	//�ύ����
	if(submitcheck('groupsubmit')) {
		
		$existgrouparr = array();
		//���Ȧ��id
		if(count($_POST['gid']) >10) {
			messagebox('ok', 'one_can_only_push_10_below_the_group', geturl("uid/$itemarr[uid]/action/viewspace/itemid/$itemarr[itemid]/php/1"));
		}
		$gidstr = empty($_POST['gid'])?0:simplode($_POST['gid']);
		
		$count = 0;
		if(!empty($gidstr)) {
			$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('groupuid')." WHERE gid IN ($gidstr) AND uid='$_SGLOBAL[supe_uid]'");
			while($item = $_SGLOBAL['db']->fetch_array($query)) {
				$grouparr[] = $item['gid'];
			}
			$count = count($grouparr);
			$gidstr = simplode($grouparr);
		}
		if(empty($count)) messagebox('ok', 'message_null_group', geturl("uid/$itemarr[uid]/action/viewspace/itemid/$itemarr[itemid]/php/1"));
		$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('groupitems')." WHERE  gid IN ($gidstr) AND itemid='$itemid'");
		while($item = $_SGLOBAL['db']->fetch_array($query)) {
			$existgrouparr[] = $item['gid'];
		}
		$resultarr = array_diff($grouparr, $existgrouparr);
		$sqlvaluestr = $comma = '';
		foreach($resultarr as $key => $value) {
			$sqlvaluestr .= $comma."('$value','$itemid','$_SGLOBAL[supe_uid]','$_SGLOBAL[supe_username]','$_SGLOBAL[timestamp]')";
			$comma = ',';
		}
		if(count($resultarr)) {
			//�����Ƽ�����
			$_SGLOBAL['db']->query("INSERT INTO ".tname('groupitems')." (gid,itemid,uid,username,dateline) VALUES $sqlvaluestr ");
			$msgstr = $blang['pushed_to_the_group_of_success_0'].count($resultarr).$blang['pushed_to_the_group_of_success_1'];
			if(count($existgrouparr)) {
				$msgstr .= $blang['pushed_to_the_group_of_success_2'].count($existgrouparr).$blang['pushed_to_the_group_of_success_3'];
			}
			messagebox('ok', $msgstr, geturl("uid/$itemarr[uid]/action/viewspace/itemid/$itemarr[itemid]/php/1"));
		} else {
			messagebox('ok', 'message_exist_group', geturl("uid/$itemarr[uid]/action/viewspace/itemid/$itemarr[itemid]/php/1"));
		}
		exit;
	} else {
		//Ȧ����ʾ
		include_once(S_ROOT.'./function/spacecp.func.php');
		$groupsarr = getgroups(1);
		if(empty($groupsarr)) {
			$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['mail_close'].'</a>'.$blang['group_title'].'</h5>
				<div class="xspace-ajaxcontent" style="padding: 1em;line-height:160%;">
				'.$blang['apply_or_adding_group'].'<br>
				'.$blang['apply_or_adding_group_0'].':<br>
				<a href="'.S_URL.'/spacecp.php?action=groups&op=add&openwindow=1" target="_blank">'.$blang['apply_or_adding_group_1'].'</a><br>
				<a href="'.geturl('action/group').'" target="_blank">'.$blang['apply_or_adding_group_2'].'</a>
				</div>';
		} else {
			$groupstr = getselectstr('gid[]', $groupsarr, 0, ' size="5" multiple="multiple"');
		
			$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['mail_close'].'</a>'.$blang['group_title'].'</h5>
				<div class="xspace-ajaxcontent">
				<form method="post" action="'.S_URL.'/batch.common.php?action=group" target="_self">
				<table width="100%" summary="" cellpadding="0" cellspacing="0" border="0" style="height: 100%; text-align: center;">
				<tr>
				<td style="padding: 3em 0;">'.$groupstr.'&nbsp;&nbsp;<button type="submit" name="groupsubmit" value="true">'.$blang['group_title'].'</button></td>
				</tr>
				</table><input type="hidden" name="itemid" value="'.$itemid.'" /></form>
				</div>';
		}
		showxml($html);
	}

} elseif ($action == 'quote') {
	
	//��������
	$cid = empty($_GET['cid'])?0:intval($_GET['cid']);
	$html = false;
	if($cid) {
		dbconnect();
		$item = array();
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spacecomments').' WHERE cid=\''.$cid.'\'');
		if($item = $_SGLOBAL['db']->fetch_array($query)) {
			include_once(S_ROOT.'./function/common.func.php');
			$item['message'] = preg_replace("/<blockquote.+?<\/blockquote>/is", '',$item['message']);
			$html = '[quote]'.$blang['from_the_original_note'].$item['author'].$blang['at'].sgmdate($item['dateline']).$blang['released']."\n".cuthtml($item['message'], 100).'[/quote]';
			showxml($html);
		}
	}
	showxml($html);
	
	
} elseif ($action == 'checkgwd') {
	
	//���Ȧ�ӵ�¼����
	if(submitcheck('pwdsubmit')) {
		$gid = intval($_POST['gid']);
		$check = false;
		if($gid) {
			dbconnect();
			$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groups ').' WHERE gid=\''.$gid.'\' AND password=\''.md5($_POST['pwd']).'\'');
			if($_SGLOBAL['db']->result($query, 0)) {
				ssetcookie('gidpw'.$gid, md5($_POST['pwd']), 0);
				$check = true;
			}
		}
		if($check) {
			messagebox('ok', 'check_grouppwd_ok', geturl('action/mygroup/gid/'.$gid));
		} else {
			messagebox('ok', 'check_grouppwd_error', geturl('action/mygroup/gid/'.$gid));
		}
	}

} elseif ($action == 'checkinfopwd') {
	//�����Ϣ�鿴����
	if(submitcheck('pwdsubmit')) {
		$itemid = intval($_POST['itemid']);
		$passwd = $_POST['pwd'];
		$check = false;
		if($itemid) {
			dbconnect();
			$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' WHERE itemid=\''.$itemid.'\'');
			if($item = $_SGLOBAL['db']->fetch_array($query)) {
				if($item['password'] == $passwd) {
					ssetcookie('viewpwd', md5($item['password'].$item['itemid']), 0);
					$check = true;
				}
			}
		}
		if($check) {
			sheader(geturl('action/viewspace/itemid/'.$itemid));
		} else {
			messagebox('ok', 'check_grouppwd_error', geturl('action/viewspace/itemid/'.$itemid));
		}
	}

} elseif ($action == 'joingroup') {
	
	//����Ȧ��
	$gid = empty($_GET['gid'])?0:intval($_GET['gid']);
	$referer = empty($_GET['referer'])?'':$_GET['referer'];
	if(empty($gid)) empty($referer)?showxml($blang['message_group_no_choice']):messagebox('ok', $blang['message_group_no_choice'], $referer);
	
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) empty($referer)?showxml($blang['message_need_login_group']):messagebox('ok', $blang['message_need_login_group'], $referer);
	
	include_once(S_ROOT.'./include/common.inc.php');
	$groupnum = $exist = $count = 0;
	$userarr = $setgroupsqlarr = $grouparr = array();
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('groups')." WHERE gid='$gid'");
	$grouparr = $_SGLOBAL['db']->fetch_array($query);
	if($grouparr['mode'] == 0) {
		empty($referer)?showxml($blang['allow_only_invited_to_join']):messagebox('ok', $blang['allow_only_invited_to_join'], $referer);
	}
	$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('userspaces').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
	$exist = $_SGLOBAL['db']->result($query, 0);
	if(empty($exist)) {
		empty($referer)?showxml($blang['message_need_register_group']):messagebox('ok', $blang['message_need_register_group'], $referer);
	}
	if($_SGLOBAL['group']['allowjoinnum']) {
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groupuid').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
		$count = $_SGLOBAL['db']->result($query, 0);
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('groups').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
		$groupnum = $_SGLOBAL['db']->result($query, 0);
		if($count - $groupnum > $_SGLOBAL['group']['allowjoinnum']) {
			$message = $blang['message_allow_join_group_0'].$_SGLOBAL['group']['allowjoinnum'].$blang['message_allow_join_group_1'];
			empty($referer)?showxml($message):messagebox('ok', $message, $referer);
		}
	}
	$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('groupuid').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\' AND gid=\''.$gid.'\'');
	//$count = $_SGLOBAL['db']->result($query, 0);
	$userarr = $_SGLOBAL['db']->fetch_array($query);
	if(empty($userarr)) {
		
		$flag = $grouparr['mode']==2?1:0;
		$setgroupsqlarr = array(
			'uid' => $_SGLOBAL['supe_uid'],
			'gid' => $gid,
			'groupname' => saddslashes($grouparr['groupname']),
			'flag' => $flag,
			'dateline' => $_SGLOBAL['timestamp']
		);
		inserttable('groupuid', $setgroupsqlarr, 1);
		if($flag) {
			$_SGLOBAL['db']->query('UPDATE '.tname('groups').' SET usernum=usernum+1  WHERE gid=\''.$gid.'\'');
			empty($referer)?showxml($blang['message_join_group_succeed_0']):messagebox('ok', $blang['message_join_group_succeed_0'], $referer);
		} else {
			empty($referer)?showxml($blang['message_join_group_succeed_1']):messagebox('ok', $blang['message_join_group_succeed_1'], $referer);
		}
	} else if($userarr['flag'] == 0) {
		empty($referer)?showxml($blang['message_join_group_error_0']):messagebox('ok', $blang['message_join_group_error_0'], $referer);
	} else if($userarr['flag'] == -1) {
		empty($referer)?showxml($blang['message_join_group_error_1']):messagebox('ok', $blang['message_join_group_error_1'], $referer);
	} else if($userarr['flag'] > 0) {
		empty($referer)?showxml($blang['message_join_group_error_2']):messagebox('ok', $blang['message_join_group_error_2'], $referer);
	}
	exit;
	
} elseif ($action == 'random') {

	dbconnect();
	$result = 0;
	if(!empty($_POST['username'])) {
		$_POST['username'] = trim($_POST['username']);
		$query = $_SGLOBAL['db']->query('SELECT uid FROM '.tname('members').' WHERE username=\''.$_POST['username'].'\'');
		$result = $_SGLOBAL['db']->result($query,0);
	}
	
	if(empty($result)) {
		//�ռ�����
		$count = $randnum = 0;
		$query = $_SGLOBAL['db']->query('SELECT COUNT(*) FROM '.tname('members'));
		$count = $_SGLOBAL['db']->result($query, 0);
		$randnum = rand(0, $count-1);
		$query = $_SGLOBAL['db']->query('SELECT uid FROM '.tname('members').' LIMIT '.$randnum.', 1');
		$result = $_SGLOBAL['db']->result($query, 0);
	}
	sheader(geturl('uid/'.$result));

} elseif ($action == 'paymail') {
	
	//������email
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	$item = array();
	if(!empty($itemid)) {
		dbconnect();
		$query = $_SGLOBAL['db']->query("SELECT ii.alipay, i.itemid, i.username, i.subject FROM ".tname('spaceitems')." i LEFT JOIN ".tname('spacegoods')." ii ON ii.itemid=i.itemid WHERE i.itemid='$itemid' AND i.type='goods' AND i.subtype='goods' AND i.folder='1'");
		$item = $_SGLOBAL['db']->fetch_array($query);
	}
	
	$email_from = '';
	if(submitcheck('emailsubmit')) {
		$email_from = empty($_POST['email_from'])?'':trim($_POST['email_from']);
		if(empty($item['alipay']) || empty($email_from) || !strexists($email_from, '@')) {
			messagebox('error', 'leave_your_correct_email_link');
		}
	}

	if(empty($item['alipay'])) {
		showxml('<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['close'].'</a>'.$blang['unable_to_contact_by_mail'].'</h5><div class="xspace-ajaxcontent" style="text-align: center; padding: 3em 0;">'.$blang['email_each_other_not_linked'].'</div>');
	}

	
	//����email
	if(!empty($email_from)) {

		$url = geturl("uid/$item[uid]/action/viewspace/itemid/$itemid", 1);
		$email_dateline = sgmdate($_SGLOBAL['timestamp']);

		$email_subject = $blang['buy_merchandise'].'<<'.$item['subject'].'>>,'.$blang['buy_reply'];
		$email_message = "hi, $item[username] :\r\n\r\n $blang[purchase_information_content_0] <<$item[subject]>>,\r\n$blang[purchase_information_content_1]:$url\r\n\r\n$blang[purchase_information_content_2]\r\n\r\n$email_from\r\n$email_dateline";
		$email_to = $item['alipay'];
		include_once(S_ROOT.'./include/sendmail.inc.php');
		messagebox('ok', 'mail_has_been_sent_to_the_seller');
	}
	
	$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['close'].'</a>email'.$blang['contact_sellers'].'</h5>
	<div class="xspace-ajaxcontent">
		<form method="post" action="'.S_URL.'/batch.common.php?action=paymail&itemid='.$itemid.'" target="_self">
		<table width="100%" summary="" cellpadding="2" cellspacing="2" border="0" style="height: 100%;">
			<tr>
				<td colspan="2">'.$blang['box_restore_ties'].'</td>
			</tr>
			<tr>
				<td><strong>'.$blang['common_type_goods'].'</strong>:</td><td>'.$item['subject'].'</td>
			</tr>
			<tr>
				<td><strong>'.$blang['sellers'].'</strong>:</td><td>'.$item['username'].'</td>
			</tr>
			<tr>
				<td><strong>'.$blang['email_you_the_link'].'</strong>:</td><td><input type="text" name="email_from" value="@"></td>
			</tr>
			<tr><td colspan="2" align="center">
			<input type="hidden" name="itemid" value="'.$itemid.'">
			<button type="submit" name="emailsubmit" value="true">'.$blang['contact_sellers'].'</button></td></tr>
		</table>
		</form>
	</div>';
	
	showxml($html);
	
} elseif ($action == 'friendupdate') {
	
	//�鿴���Ѹ���
	$uid = empty($_GET['uid'])?0:intval($_GET['uid']);
	$itemlist = array();
	$username = $htmlstr = '';
	if($uid) {
		dbconnect();
		$query = $_SGLOBAL['db']->query("SELECT uid, itemid, username, subject, dateline, viewnum FROM ".tname('spaceitems')." WHERE uid='$uid' AND folder='1' ORDER BY dateline DESC LIMIT 0,10");
		while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			if(empty($username)) $username = $value['username'];
			$value['dateline'] = sgmdate($value['dateline'], 'Y-m-d');
			$htmlstr .= "<tr><td><a href=\"".geturl("uid/$value[uid]/action/viewspace/itemid/$value[itemid]")."\" target=\"_blank\">$value[subject]</a>($value[viewnum])</td><td align=\"right\">$value[dateline]</td></tr>";
		}
	}
	if(empty($htmlstr)) $htmlstr .= "<tr><td colspan=\"2\">$blang[no_information_update]</td></tr>";
	
	$html = '<h5><a href="javascript:;" onclick="getbyid(\'xspace-ajax-div\').style.display=\'none\';">'.$blang['close'].'</a>'.(empty($username)?'':$username.' - ').$blang['personal_space_update'].'</h5>
		<div class="xspace-ajaxcontent">
		<table width="100%" summary="" cellpadding="3" cellspacing="2" border="0" style="height: 100%;">
		'.$htmlstr.'
		<tr><td colspan="2"><a href="'.geturl("uid/$uid/action/spacelist").'" target="_blank">'.$blang['see_more'].'</a></td></tr>
		</table>
		</div>';
	
	showxml($html);

} elseif ($action == 'forbidreply') {
	
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	if(empty($itemid)) {
		messagebox('error', 'commenting_on_the_failure_to_prohibit_operation');
	}
	getcookie(1);
	if($_SGLOBAL['group']['groupid'] != 1) {
		messagebox('error', 'no_authority_for_this_operation');
	}
	
	include_once(S_ROOT.'./include/common.inc.php');
	updatetable('spaceitems', array('allowreply'=>'-1'), array('itemid'=>$itemid));
	$theurl = geturl("uid/$thevalue[uid]/action/viewspace/itemid/$itemid");
	messagebox('ok', 'commenting_on_the_successful_operation_against', $theurl);

} elseif ($action == 'videorelative') {
	//echo 'OK';
	$itemid = empty($_POST['itemid'])?0:intval($_POST['itemid']);
	$itemlist = array();
	if($itemid) {
		include_once(S_ROOT.'./include/common.inc.php');
		$outxml = '<?xml version="1.0" encoding="UTF-8"?><root>';
		$relativeitemids = '';
		$relativeitemarr = array();
		
		dbconnect();
		$query = $_SGLOBAL['db']->query("SELECT relativeitemids FROM ".tname('spacevideos')." WHERE itemid='$itemid'");
		$relativeitemids = $_SGLOBAL['db']->fetch_array($query);
		if($relativeitemids['relativeitemids']) {
			$relativeitemarr = explode(',', $relativeitemids['relativeitemids']);
			$relativeitemarr = array_map("intval", $relativeitemarr);
			$relativeitemids = implode('\', \'', $relativeitemarr);
			$query = $_SGLOBAL['db']->query("SELECT i.itemid, i.uid, i.username, i.subject, ii.image FROM ".tname('spaceitems')." i LEFT JOIN ".tname('spacevideos')." ii ON ii.itemid=i.itemid WHERE i.itemid IN ('$relativeitemids')");
			while($item = $_SGLOBAL['db']->fetch_array($query)) {
				$item['subject'] = encodeconvert("UTF-8", $item['subject'], 1);
				$item['username'] = encodeconvert("UTF-8", $item['username'], 1);
				$outxml .= '<items>';
				$outxml .= '<itemname><![CDATA['.$item['subject'].']]></itemname>';
				$outxml .= '<itemauthor><![CDATA['.$item['username'].']]></itemauthor>';
				$outxml .= '<itempic>'.S_URL_ALL.'/'.$item['image'].'</itempic>';
				$outxml .= '<itemurl>'.S_URL_ALL.'/?uid/'.$item['uid'].'/action/viewspace/itemid/'.$item['itemid'].'</itemurl>';
				$outxml .= '</items>';
			}
		}
		$outxml .= '</root>';
		header("Content-type:text/xml");
		echo $outxml;
		exit();
	}
} elseif ($action == 'videoad') {

	$addarr = empty($_SSCONFIG['videoadarr']['ad'])?array():$_SSCONFIG['videoadarr']['ad'];
	$addlogoarr = empty($_SSCONFIG['videoadarr']['logo'])?array(3,'images/base/videologo.gif'):$_SSCONFIG['videoadarr']['logo'];
	$addcount = count($addarr);
	$outxml = '<?xml version="1.0"?><root>';
	$outxml .= '<logo>';
	$outxml .= '<position>'.$addlogoarr[0].'</position>';
	if(strrpos($addlogoarr[1], 'http://') === false) {
		$addlogoarr[1] = S_URL_ALL.'/'.$addlogoarr[1];
	}
	$outxml .= '<logourl>'.$addlogoarr[1].'</logourl>';
	$outxml .= '</logo>';
	if($addcount > 0) {
		$adindexf = rand(0, $addcount-1);
		$adindexl = rand(0, $addcount-1);
		
		if(strrpos($addarr[$adindexf], 'http://') === false) {
			$addarr[$adindexf] = S_URL_ALL.'/'.$addarr[$adindexf];
		}
		if(strrpos($addarr[$adindexl], 'http://') === false) {
			$addarr[$adindexl] = S_URL_ALL.'/'.$addarr[$adindexl];
		}
		$outxml .= '<videoad>'.$addarr[$adindexf].'</videoad>';
		$outxml .= '<videoad>'.$addarr[$adindexl].'</videoad>';
	}
	$outxml .= '</root>';
	@header("Content-type:text/xml");
	echo $outxml;
	exit();

} elseif ($action == 'getrobotmsg') {
	include_once(S_ROOT.'./include/common.inc.php');
	include_once(S_ROOT.'./function/robot.func.php');
	
	$arrayrobotmeg = array();
	if(isset($_POST['referurl']) && !empty($_POST['referurl'])){
		//��ȡ����
		$robotlevel = intval(postget('robotlevel'));
		if($robotlevel > 2 || $robotlevel < 1) exit;
	
		$arrayrobotmeg = getrobotmeg($_POST['referurl'], $robotlevel);
	}
	//����Ƿ��ȡ����Ϣ
	if(!empty($arrayrobotmeg['leachmessage'])) {
		$pagebreak = isset($_POST['itemid']) && intval($_POST['itemid']) == 0 ? 1 : 0;
		$arrayrobotmeg['leachsubject'] = preg_replace("/\r/", '', $arrayrobotmeg['leachsubject']);
		$arrayrobotmeg['leachmessage'] = addslashes($arrayrobotmeg['leachmessage']);

		print <<<EOF
			<script type="text/javascript">
			parent.document.getElementById("subject").value = '{$arrayrobotmeg['leachsubject']}';
			parent.document.getElementById("message").innerHTML = '';
			function init() {
				parent.et = new parent.word("message", "{$arrayrobotmeg['leachmessage']}", 0, {$pagebreak});
			}
			init();
			objCharset = parent.document.getElementById('scharset');
			objCharsetOption = parent.document.getElementById('charset').getElementsByTagName("option");
			for(i = 0; i < objCharsetOption.length; i++){
				if(objCharsetOption[i].value == '{$arrayrobotmeg['charset']}')
					objCharsetOption[i].selected = true;
			}
			objCharset.style.display = "";
			</script>
EOF;
		showrobotmsg($blang['extract_the_contents_of_success'], 'ok');
	} else {
		showrobotmsg($blang['extract_the_contents_of_failure']);
	}

} elseif ($action == 'musicconfig') {
	$_GET['uid'] = intval($_GET['uid']);
	if(empty($_GET['uid'])) {
		exit();
	}
	$reauthcode = md5($_SCONFIG['sitekey'].$_GET['uid']);
	if($reauthcode == $_GET['hash']) {
		include_once(S_ROOT.'./include/common.inc.php');
		dbconnect();
		$query = $_SGLOBAL['db']->query('SELECT `music` FROM '.tname('userspacefields').' WHERE uid = \''.$_GET['uid'].'\'');
		$musicmsgs = unserialize($_SGLOBAL['db']->result($query, 0));
		$outxml = '<?xml version="1.0" encoding="UTF-8" ?>'."\n";
		$outxml .= '<playlist version="1">'."\n";
		$outxml .= '<mp3config>'."\n";
		if('big' == $musicmsgs['config']['showmod']) {
			$outxml .= '<showdisplay>true</showdisplay>'."\n";
		} else {
			$outxml .= '<showdisplay>false</showdisplay>'."\n";
		}
		$outxml .= '<autostart>'.$musicmsgs['config']['autorun'].'</autostart>'."\n";
		$outxml .= '<showplaylist>true</showplaylist>'."\n";
		$outxml .= '<shuffle>'.$musicmsgs['config']['shuffle'].'</shuffle>'."\n";
		$outxml .= '<repeat>all</repeat>'."\n";
		$outxml .= '<volume>100</volume>';		
		$outxml .= '<linktarget>_top</linktarget> '."\n";
		$outxml .= '<backcolor>0x'.substr($musicmsgs['config']['crontabcolor'], -6).'</backcolor> '."\n";
		$outxml .= '<frontcolor>0x'.substr($musicmsgs['config']['buttoncolor'], -6).'</frontcolor>'."\n";
		$outxml .= '<lightcolor>0x'.substr($musicmsgs['config']['fontcolor'], -6).'</lightcolor>'."\n";
		$outxml .= '<jpgfile>'.$musicmsgs['config']['crontabbj'].'</jpgfile>'."\n";
		$outxml .= '<callback></callback> '."\n"; 
		$outxml .= '</mp3config>'."\n";
		$outxml .= '<trackList>'."\n";
		foreach ($musicmsgs['mp3list'] as $value){
			$outxml .= '<track><annotation>'.$value['mp3name'].'</annotation><location>'.$value['mp3url'].'</location><image>'.$value['cdbj'].'</image></track>'."\n";
		}
		$outxml .= '</trackList></playlist>';
		$outxml = encodeconvert("UTF-8", $outxml, 1);
		obclean();
		@header("Expires: -1");
		@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
		@header("Pragma: no-cache");
		@header("Content-type: application/xml");
		echo $outxml;
	}
	exit();
} elseif ($action == 'musicpasspage') {
	$_GET['uid'] = intval($_GET['uid']);
	if(empty($_GET['uid'])) {
		exit();
	}
	$reauthcode = md5($_SCONFIG['sitekey'].$_GET['uid']);
	if($reauthcode == $_GET['hash']) {
		include_once(S_ROOT.'./include/common.inc.php');
		dbconnect();
		$query = $_SGLOBAL['db']->query('SELECT `music` FROM '.tname('userspacefields').' WHERE uid = \''.$_GET['uid'].'\'');
		$musicmsgs = unserialize($_SGLOBAL['db']->result($query, 0));
		if(0 == $musicmsgs['config']['passpage']){
			echo '<script language="javascript" type="text/javascript">parent.window.location.href="./?'.$_GET['uid'].'"</script>';
			exit();
		}
		$swfurl = S_URL_ALL.'/images/base/mp3player.swf?site='.S_URL_ALL.'&uid='.$_GET['uid'].'&hash='.$reauthcode.'&rand='.rand(100, $_SGLOBAL['timestamp']);
		$outxml .= '<html>'."\n";
		$outxml .= '<body style="margin:0;background:url('.rawurldecode($musicmsgs['config']['bgimg']).')">'."\n";
		$outxml .= '<object codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" height="300" width="192">'."\n";
		$outxml .= '<param name="movie" value="'.$swfurl.'" />'."\n";
		$outxml .= '<param name="AllowScriptAccess" value="always" />'."\n";
		$outxml .= '<param name="AllowFullScreen" value="true" />'."\n";
		$outxml .= '<embed src="'.$swfurl.'" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" pluginspage="http://www.macromedia.com/go/getflashplayer" height="300" width="192" />'."\n"; 
		$outxml .= '</object>'."\n";
		$outxml .= '</body></html>';
		obclean();
		echo $outxml;
	} 
	exit();
} elseif ($action == 'showimg') {
	$itemid = empty($_POST['itemid'])?0:intval($_POST['itemid']);
	$hash = empty($_POST['hash'])?'':$_POST['hash'];
	$remote = empty($_POST['remote'])?0:$_POST['remote'];
	$bgmusicurl = '';
	$outxml1 = '';
	$refuse = false;
	$outxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	$outxml .= "<items>\n";
	if(!empty($itemid)) {
		include_once(S_ROOT.'./include/common.inc.php');
		dbconnect();
		$attachmentdir = '';
		if(substr($_SSCONFIG['attachmentdir'], 0, 2) == './' && empty($_SSCONFIG['attachmenturl'])) {
			$attachmentdir = S_URL_ALL.substr($_SSCONFIG['attachmentdir'], 1);
		} else {
			$attachmentdir = $_SSCONFIG['attachmenturl'];
		}

		$item = array();
		$item['attachcount'] = 0;
		//��������ͼƬ
		if(!empty($remote)) {
			$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceimages').' WHERE itemid=\''.$itemid.'\'');
			if($itemarr = $_SGLOBAL['db']->fetch_array($query)) {
				$bgmusicurl = $itemarr['bgmusic'];
				$itemarr = unserialize($itemarr['remoteurl']);
				foreach ($itemarr as $key => $value) {
					$value['subject'] = encodeconvert("UTF-8", $value['remoteurlname'], 1);
					$value['attachtype'] = fileext($value['remoteurl']);
					$outxml1 .= "<item>\n";
					$outxml1 .= "<aid>0</aid>\n";
					$outxml1 .= "<type>$value[attachtype]</type>\n";
					$outxml1 .= "<size>0KB</size>\n";
					$outxml1 .= "<subject><![CDATA[$value[subject]]]></subject>\n";
					$outxml1 .= "<thumb>".$value['remoteurl']."</thumb>\n";
					$outxml1 .= "<original>".$value['remoteurl']."</original>\n";
					$outxml1 .= "</item>\n";
				}
			}
		}
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('attachments').' WHERE itemid=\''.$itemid.'\'');
		while($value = $_SGLOBAL['db']->fetch_array($query)) {
			if(md5($itemid.$value['uid'].$_SCONFIG['sitekey']) != $hash) {
				$refuse = true;
				break;
			}
			$value['subject'] = encodeconvert("UTF-8", $value['subject'], 1);
			$outxml .= "<item>\n";
			$outxml .= "<aid>$value[aid]</aid>\n";
			$outxml .= "<type>$value[attachtype]</type>\n";
			$outxml .= "<size>".formatsize($value['size'])."</size>\n";
			$outxml .= "<subject><![CDATA[$value[subject]]]></subject>\n";
			$outxml .= "<thumb>".$attachmentdir.'/'.$value['thumbpath']."</thumb>\n";
			$outxml .= "<original>".$attachmentdir.'/'.$value['filepath']."</original>\n";
			$item['attach'][] = $value;
			if(empty($item['attachcount'])) {
				$outxml .= "<url>".geturl("uid/$value[uid]/action/viewspace/itemid/$itemid", 1)."</url>\n";
				if(!empty($bgmusicurl)) {
					$outxml .= "<music>".$bgmusicurl."</music>\n";
				}
			}
			$item['attachcount']++;
			$outxml .= "</item>\n";
		}
		if(!empty($outxml1) && !$refuse) {
			$outxml .= $outxml1;
		}
		
	
	}
	$outxml .= "</items>\n";
	obclean();
	@header("Expires: -1");
	@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
	@header("Pragma: no-cache");
	@header("Content-type: application/xml");
	echo $outxml;
	exit();

} elseif ($action == 'report') {
	
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	if(!empty($itemid)) {
		dbconnect();
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname('spaceitems').' WHERE itemid=\''.$itemid.'\'');
		if($item = $_SGLOBAL['db']->fetch_array($query)) {
			$query = $_SGLOBAL['db']->query('SELECT itemid, status FROM '.tname('reports').' WHERE itemid=\''.$itemid.'\'');
			$reportitem = $_SGLOBAL['db']->fetch_array($query);
			if($reportitem) {
				if($reportitem['status'] == '0') {
					showxml($blang['information_has_been_reported']);
				} else {
					showxml($blang['not_a_malicious_report']);
				}
			} else {
				include_once(S_ROOT.'./include/common.inc.php');
				getcookie(1);
				if(empty($_SGLOBAL['supe_username'])) {
					$_SGLOBAL['supe_username'] = 'Guest';
				}
				$insertsqlarr = array(
					'itemid' => $itemid,
					'reportuid' => $_SGLOBAL['supe_uid'],
					'reporter' => empty($_SGLOBAL['supe_username'])?'Guest':$_SGLOBAL['supe_username'],
					'reportdate' => $_SGLOBAL['timestamp'],
					'status' => 0
				);
				inserttable('reports', $insertsqlarr);
				showxml($blang['reported_success']);
			}
		}
	}
} elseif ($action == 'process') {
	
	@header("Expires: -1");
	@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
	@header("Pragma: no-cache");
	print <<<HTML
	<script type="text/javascript">
		var siteUrl = "$siteurl";

	</script>
	<script type="text/javascript" src="$siteurl/include/js/ajax.js"></script>
	<script type="text/javascript" src="$siteurl/include/js/upload.js"></script>
	<script type="text/javascript">
		parent.setServer();
		proInter = setInterval("send()", 1000);
	</script>
HTML;

} elseif ($action == 'alipay') {
	
	include_once(S_ROOT.'./include/common.inc.php');
	
	$item = array();
	$itemid = empty($_GET['itemid'])?0:intval($_GET['itemid']);
	if(!empty($itemid)) {
		dbconnect();
		$query = $_SGLOBAL['db']->query("SELECT i.*, ii.* FROM ".tname('spaceitems')." i LEFT JOIN ".tname('spacegoods')." ii ON ii.itemid=i.itemid WHERE i.itemid='$itemid' AND i.type='goods' AND i.folder='1'");
		$item = $_SGLOBAL['db']->fetch_array($query);
	}
	if(empty($item)) messagebox('error', 'alipay_error');
	
	//��������
	$item['buynum'] = 1;//Ĭ��Ϊ1��

	//��������
	$item['chargetype'] = 'EXPRESS';//Ĭ�Ͽ�� POST EMS
	
	//��������
	$item['chargeprice'] = $item['chargeexpress'];//��ݷ���
	
	//����֧����ʽ
	if($item['paymenttype'] == 'goods') {
		$item['chargepayment'] = 'BUYER_PAY_AFTER_RECEIVE';//��������
	} else {
		if($item['chargemode'] == 'buy') {
			$item['chargepayment'] = 'BUYER_PAY';//���֧��
		} else {
			$item['chargepayment'] = 'SELLER_PAY';//����֧��
		}
	}
	
	$payurl = trade_payurl($item);
	
	header("Location: $payurl");
	exit();
} elseif($action == 'front') {
	include_once(S_ROOT.'./include/common.inc.php');
	$path = $catname = '';
	$directory = camreaddir(S_ROOT.'./images/foreground');
	
	$outxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	$outxml .= "<parameter>\n";
	$outxml .= "<images>\n";
	foreach($directory as $key => $value) {
		$dirstr = S_ROOT.'./images/foreground/'.$value;
		if(is_dir($dirstr)) {
			$filearr = camreaddir($dirstr, array('jpg','jpeg','gif','png'));
			if(!empty($filearr)) {
				if(function_exists("iconv") && is_file($dirstr.'/categories.txt')) {
					$catfile = @file($dirstr.'/categories.txt');
					$catname = iconv($_SCONFIG['charset'], 'UTF-8', trim($catfile[0]));
				} else {
					$catname = trim($value);
				}
				$path = trim('image/foreground/'.$value.'/');
				$outxml .= "<categories name=\"$catname\" directory=\"images/foreground/$value/\">\n";
				foreach ($filearr as $key => $val) {
					$outxml .= "<img name=\"$val\"/>\n";
				}
				$outxml .= "</categories>\n";
			}
		}
	}

	$outxml .= "</images>\n";
	$outxml .= "</parameter>\n";
	obclean();
	@header("Expires: -1");
	@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
	@header("Pragma: no-cache");
	@header("Content-type: application/xml");
	echo $outxml;
	exit();
} elseif($action == 'savescreen') {
	getcookie(1);
	if(empty($_SGLOBAL['supe_uid'])) exit('Access Denied');
	include_once(S_ROOT.'./include/common.inc.php');
	include_once(S_ROOT.'./function/upload.func.php');

	$filemain = $_SGLOBAL['supe_uid'].'_'.sgmdate($_SGLOBAL['timestamp'], 'YmdHis').$_SERVER['HTTP_IMGID'];
		
	//debug �õ��洢Ŀ¼
	$dirpath = getattachdir();
	if(!empty($dirpath)) $dirpath .= '/';
	$filename = $dirpath.$filemain.'.jpg';
	$newfilename = A_DIR.'/'.$filename;
	if(empty($GLOBALS['HTTP_RAW_POST_DATA'])) {
		$GLOBALS['HTTP_RAW_POST_DATA'] = file_get_contents("php://input");
	}
	if($handle = fopen($newfilename, 'wb')) {
		if(fwrite($handle, $GLOBALS['HTTP_RAW_POST_DATA']) !== FALSE) {
			$size = filesize($newfilename);
			if(!empty($_SGLOBAL['group']['attachsize']) && ($attachsize + $size > $_SGLOBAL['group']['attachsize'])) {
				$query = $_SGLOBAL['db']->query('SELECT spacesize FROM '.tname('userspaces').' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
				$spacesize = $_SGLOBAL['db']->result($query, 0);
				$spacesize = ($spacesize + $_SGLOBAL['group']['attachsize'])*1024*1024;
				if($attachsize + $size > $spacesize){
					@unlink($newfilename);
					exit('Access Denied');
				}
			}
			$insertsqlarr = array(
				'uid' => $_SGLOBAL['supe_uid'],
				'dateline' => $_SGLOBAL['timestamp'],
				'filename' => saddslashes($filemain.'.jpg'),
				'subject' => trim(shtmlspecialchars($filemain)),
				'attachtype' => 'jpg',
				'type' => 'image',
				'isimage' => 1,
				'size' => $size,
				'filepath' => $filename,
				'thumbpath' => $filename,
				'isavailable' => 1,
				'hash' => $_SGLOBAL['supe_uid']
			);
			inserttable('attachments', $insertsqlarr);
			$_SGLOBAL['db']->query('UPDATE '.tname('userspacefields').' SET attachsize=attachsize+'.$size.' WHERE uid=\''.$_SGLOBAL['supe_uid'].'\'');
    	}
	}
	fclose($handle);
} elseif ($action == 'modelquote') {
	
	//ģ����������
	$name = empty($_GET['name'])?'':trim($_GET['name']);
	$cid = empty($_GET['cid'])?0:intval($_GET['cid']);
	$html = false;
	if(!empty($name) && !empty($cid)) {
		dbconnect();
		$item = array();
		$query = $_SGLOBAL['db']->query('SELECT * FROM '.tname($name.'comments').' WHERE cid=\''.$cid.'\'');
		if($item = $_SGLOBAL['db']->fetch_array($query)) {
			include_once(S_ROOT.'./function/common.func.php');
			$item['message'] = preg_replace("/<blockquote.+?<\/blockquote>/is", '',$item['message']);
			$html = '[quote]'.$blang['from_the_original_note'].$item['author'].$blang['at'].sgmdate($item['dateline']).$blang['released']."\n".cuthtml($item['message'], 100).'[/quote]';
			showxml($html);
		}
	}
	showxml($html);
	
	
} elseif($action == 'relatekw') {
	
	$subjectenc = rawurlencode(strip_tags($_GET['subjectenc']));
	$messageenc = rawurlencode(strip_tags($_GET['messageenc']));
	$return = '';
	$data = @implode('', file("http://keyword.discuz.com/related_kw.html?title=$subjectenc&content=$messageenc&ics=$charset&ocs=$charset"));
	if($data) {
		include_once(S_ROOT.'./include/common.inc.php');
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $values, $index);
		xml_parser_free($parser);
	
		$kws = array();
	
		foreach($values as $valuearray) {
			if($valuearray['tag'] == 'kw' || $valuearray['tag'] == 'ekw') {
				if(PHP_VERSION > '5' && $charset != 'utf-8') {
					$valuearray['value'] = encodeconvert("UTF-8", $valuearray['value']);
				} else {
					$valuearray['value'] = trim($valuearray['value']);
				}
				$kws[] = $valuearray['value'];
			}
		}

		if($kws) {
			foreach($kws as $kw) {
				$kw = htmlspecialchars($kw);
				$return .= $kw.' ';
			}
			$return = htmlspecialchars($return);
		}
	
	}
	showxml($return);
}


//��ȡĿ¼
function camreaddir($dir, $extarr=array()) {
	$dirs = array();
	if($dh = opendir($dir)) {
		while (($file = readdir($dh)) !== false) {
			if(!empty($extarr) && is_array($extarr)) {
				if(in_array(strtolower(fileext($file)), $extarr)) {
					$dirs[] = $file;
				}
			} else if($file != '.' && $file != '..') {
				$dirs[] = $file;
			}
		}
		closedir($dh);
	}
	return $dirs;
}
?>