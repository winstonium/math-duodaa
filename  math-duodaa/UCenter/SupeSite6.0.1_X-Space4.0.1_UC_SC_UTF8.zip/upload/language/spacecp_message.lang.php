<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	X-Space后台提示窗口语言包

	$RCSfile: spacecp_message.lang.php,v $
	$Revision: 1.31 $
	$Date: 2007/07/18 18:38:13 $
*/

if(!defined('IN_SUPESITE')) exit('Access Denied');

$smlang = array(

	'pre_operational_pages'=>'点击此处返回操作前的页面',
	'jump_page'=>'页面跳转中......',
	
	'no_authority_for_this_operation'=>'出错了，您没有权限进行本操作',
	'no_use_of_the_functional_competence'=>'您所在的用户组现在还没有权限使用该功能',
	'did_not_provide_the_function'=>'系统现在还没有提供该功能',
	
	//spacecp_blogimport
	'no_authority_to_use_log'=>'您所在的用户组现在还没有权限使用日志功能',
	'log_functions_not_open'=>'日志功能没有开启',
	'no_access_to_the_contents'=>'没有获取到任何内容，请输入其他订阅rss信息源的url试试',
	'inconsistent_coding'=>'信息源内容编码与系统当前编码不一致，无法获取有用信息',
	'no_access_to_the_log_table'=>'没有获取到任何日志列表，请输入其他订阅rss信息源的url试试',
	'introduction_to_choose_to_log_information'=>'您至少选择一个要导入为日志的信息',
	'introduction_to_choose_the_classification_system'=>'请选择要导入的系统分类',
	'no_introduction_to_information'=>'已经没有信息来进行导入操作',

	//spacecp_bloginput
	'blog_input_suss'=>'迁入选中的文章成功，请进入管理平台，手动添加关键字以及日至分类。',
	'blog_input_fault'=>'以下文章迁入失败，需要重新迁入或者手动发布',
	'blog_input_permit_url'=>'不是合法的URL地址',
	'blog_input_return_error'=>'对方返回数据格式错误，请确认对方支持WordPress或者metaWeblog，确认对方xmlrpc的url存在',
	'blog_input_server_result_code'=>'对方返回的错误代码：',
	'blog_input_data_time_out'=>'数据过期了，请重新抓取。',
	'blog_input_into_no_id'=>'您没有选择要搬入的文章ID',
	
	//spacecp_corpus
	'unopened_iconv_functions'=>'由于服务器未开启iconv功能,本功能暂时未开启',
	'please_name_the_importation_collection'=>'请输入文集名称',
	'please_log_content_choices'=>'请选择日志内容',
	'please_input_the_name_of_the_author'=>'请输入作者名字',
	'please_input_preamble_title'=>'请输入序言标题',

	//spacecp_customfields
	'renewing_the_order_shows'=>'操作完成，自定义信息显示顺序更新成功了',
	'add_self_defined_success'=>'操作完成，添加自定义信息成功了',
	'update_self_defined_success'=>'操作完成，自定义信息更新成功了',
	'delete_self_defined_success'=>'操作完成，删除自定义信息成功了',
	
	//spacecp_itemtypes
	'itemtype_changes_to_the_order_of_successful_shows'=>'恭喜,分类显示顺序更改成功了',
	'itemtype_name_should_be_between_2_to_30_characters'=>'您输入的分类名字应该在2~30个字符之间',
	'add_itemtype_success'=>'操作完成，添加分类成功了',
	'update_itemtype_success'=>'操作完成，更新分类成功了',
	'delete_itemtype_success'=>'操作完成，删除分类成功了',

	//spacecp_linkmove
	'choose_a_local_paper_clip_collection'=>'您需要选择一个本地收藏夹文件进行导入',
	'lack_of_access_to_local_collections_clip'=>'系统现在无法获取本地收藏夹文件',
	'no_introduction_to_the_web_site'=>'您指定的本地收藏夹文件没有要导入的网址',
	'introduction_to_choose_a_site_bookmarks'=>'您应该选择一个要导入书签的网址',
	'choice_of_a_classification_system'=>'请选择一个系统分类',
	'bookmark_folder_into_collections_success'=>'操作完成，从收藏夹导入书签成功了',

	//spacecp_manage
	'operating_without_proper_management'=>'您没有正确进行管理操作',
	'no_choice_but_to_delete_comments'=>'您没有选择要删除的评论',
	'delete_comments_success'=>'操作完成，删除评论成功了',
	'no_choice_but_to_delete_the_message'=>'您没有选择要删除的留言',
	'delete_messages_success'=>'操作完成，删除留言成功了',
	'no_choice_but_to_remove_the_footprints'=>'您没有选择要删除的足迹',
	'successfully_deleted_tracks'=>'操作完成，删除足迹成功了',
	'no_choice_but_to_remove_the_collections'=>'您没有选择要删除的收藏',
	'delete_collections_success'=>'操作完成，删除收藏成功了',
	'no_choice_but_to_remove_the_annex'=>'您没有选择要删除的附件',
	'complete_deletion'=>'操作完成，删除附件完成了',
	'deletion_of_failure'=>'抱歉，删除附件失败了',
	'links_to_update_successful_sequence'=>'操作完成，更新链接顺序成功了',
	'links_that_do_not_meet_the_requirements_length_of_the_name'=>'您输入的链接名称长度不符合要求',
	'links_logo_address_long'=>'您输入的链接logo地址太长了',
	'link_addresses_long'=>'您输入的链接地址太长了',
	'successful_operation'=>'操作完成，操作成功了',
	'the_right_to_delete_friendship_links'=>'您无权执行友情链接删除操作',
	'friendly_link_successfully_deleted'=>'操作完成，友情链接删除成功',
	'in_error' => '您要存入的数额不正确(最少为10个,且不能超过自己拥有的数额)，请检查',
	'out_error' => '您要取出的数额不正确(最少为10个,且不能超过自己存入的数额)，请检查',
	'topspace_error' => '对不起，现在不能进行指定的转入操作',
	'formspace_error' => '对不起，现在不能进行指定的转出操作',

	//spacecp_mybbs
	'choose_to_operate_at_least_one_of_the_articles'=>'请选择至少一个您要操作的帖子',
	'introduction_of_a_message_can_not'=>'没有可以导入的帖子了',
	'the_articles_did_not_meet_the_requirements'=>'没有找到符合条件的帖子',
	
	//spacecp_friends.php
	'not_adding_to_their_friends' => '抱歉，您不能添加自己为好友',
	'add_friend_ok' => '操作完成，添加好友成功了',
	'did_not_find_the_designated_users' => '抱歉，没有找到您指定的用户',
	'successful_grading_change_friends' => '操作完成，更改好友分组成功了',
	'please_fill_in_the_friends_to_send_mail' => '请填写要发送的好友邮箱，多个邮箱之间用 , 隔开',
	'mail_has_been_sent_to_friends' => '操作完成，邮件已经发送给好友了',
	'simultaneous_completion_of_friends' => '操作完成，与论坛同步好友完成了',
	'friends_delete_success' => '操作完成，好友删除成功',
	
	//spacecp_groups.php
	'no_authority_to_create_group' => '您所在的用户组目前没有权限创建圈子',
	'length_does_not_meet_the_requirements' => '您输入的圈子名称长度不符合要求，标题长度应该为2～40个字符',
	'choice_of_types_of_group' => '请为圈子选择一个所属分类',
	'number_of_applications_for_permit' => '出错了，您允许创建的圈子个数已达到上限',
	'has_been_applied' => '您创建的圈子已存在，请换个圈子名称',
	'applications_awaiting_review' => '操作完成，圈子创建成功了，请等待管理员审核！',
	'successful_applicants_group' => '操作完成，圈子创建成功了',
	'failure_to_dissolve_the_wrong_parameters' => '出错了，参数错误解散圈子失败',
	'the_right_to_dissolve_groups' => '出错了，您无权解散其他人的圈子',
	'kwan_has_been_dissolved' => '操作完成，指定的圈子已被解散',
	'parameter_error' => '出错了，参数错误,请返回',
	'directly_from_the_group' => '出错了，您不能直接退出自已创建的圈子，请选择解散圈子的功能来完成退出操作',
	'not_to_withdraw_from_the_group' => '出错了，不存在您要退出的圈子记录',
	'from_the_group_has_successfully' => '操作完成,您已成功退出该圈子！',
	'the_records_do_not_exist_to_operate' => '出错了，不存在您要操作的圈子记录',
	'successful_refused_to_invite' => '操作完成,您已成功拒绝该圈子邀请！',
	'successful_delete_to_invite' => '操作完成,您已成功删除该圈子邀请！',
	'successful_accepted_to_invite' => '操作完成,您已成功接受该圈子邀请！',
	'group_name_system_has_been_retained' => '您输入的圈子名称已经被系统保留',
	'successful_repeal_to_invite' => '操作完成,您已成功撤消邀请记录！',
	
	//spacecp_mygroups.php
	'no_authority_to_use_group' => '您所在的用户组目前没有权限创建圈子',
	'the_right_to_operate_the_group' => '出错了，您无权操作该圈子！',
	'operation_theme_chosen' => '您应该选择一个或者多个要操作的主题',
	'group_notice_added_success' => '操作完成，圈子公告添加成功',
	'group_style_update_success' => '操作完成，圈子风格更新成功',
	'info_deleted_from_the_selected_group' => '操作完成，选定的信息已从圈子中删除',
	'info_essence_of_successful_operation' => '操作完成，选定的信息精华操作成功',
	'please_visit_the_input_of_group_passwords' => '出错了，请输入圈子访问密码',
	'group_config_parameters_success' => '操作完成，圈子参数配置成功，请返回',
	'not_invited_to_join_the_group' => '您想要邀请的人还未升级个人空间，无法邀请加入本圈子',
	'success_has_sent_invitation_letters' => '邀请函已发送，请等待对方确认',
	'members_have_been_invited' => '邀请失败,对方拒绝邀请如需通过邀请,则需要对方删除相关的邀请记录',
	'the_other_is_the_group_members' => '邀请失败,对方已经是该圈子成员,当前成员状态为未审核或未经成员确认',
	'not_delete_their_own' => '出错了，不能删除自已',
	'members_choose_to_operate' => '您应该选择一个或者多个要操作的成员',
	'users_has_been_removed' => '恭喜,指定用户已被删除',
	'members_can_amend_their_own_state' => '出错了，不能修改自已的成员状态',
	'users_examine_successful_operation' => '恭喜,指定用户审核操作成功',
	'info_successful_operation' => '恭喜,信息操作成功！请返回',
	'info_removed_from_the_designated_groups' => '操作完成,指定信息已从圈内删除！',
	'please_choose_to_manage_the_plate' => '出错了，请选择要管理的版块！',
	'users_do_not_exist' => '出错了，您要操作的用户不存在',
	'group_being_audited' => '圈子未开通，正在审核中',
	'can_be_transferred_to_a_user' => '圈子只能转让给一个用户',
	'unable_to_transfer_the_circle' => '您想要转让的人还未升级个人空间，无法转让本圈子',
	'successful_transfer_of_groups' => '操作完成,圈子已成功转让给指定用户',
	'enough_authority_to_operate_failure' => '权限不足,操作失败',
	'circle_members_of_the_other_side_is_not' => '对方还不是圈内成员，转让失败',
	'since_the_definition_of_style_is_empty' => '自定义圈子风格为空不能共享圈子风格',
	'non_style_sharing_group' => '操作失败，非共享圈子风格',
	'style_has_amended_return_to_the_preview' => '风格已修改请返回预览',
	'under_the_right_to_delete_more_than_members_of_the_ring' => '您无权删除副圈主以上的成员',
	
	//spacecp_spaceblogs.php
	'has_been_selected_to_delete_the_blog' => '操作完成，选定的日志已经被删除了',
	'aiming_personal_success' => '操作完成，个人分类设定成功了',
	'successful_type_system_set' => '操作完成，更新分类操作成功了',
	'log_successful_release' => '操作完成，日志发布成功了',
	're_released_by_the_authority' => '出错了，您没有将删除信息重新发布的权限',
	'log_was_placed_in_bins' => '操作完成，选定的日志已经被删除到垃圾箱',
	'which_has_been_transformed_into_a_message_log' => '帖子已经被导入到日志里面了',
	'parameters_wrong_emptied_failure' => '清空失败，参数错误',
	'results_found_no_correlation' => '没有找到相关结果<br>
				为了获得准确的搜索结果，您输入的搜索关键字应该至少包含1个汉字，或者2个英文字母<br>
				系统每次搜索最多返回100条记录，您应该选择合适的关键词已便搜索到自己需要的信息',
	'password_length_can_not_exceed_10_characters' => '密码长度不能大于10个字符',
	'background_music_only_supports_mp3' => '当前填写的背景音乐只支持mp3请重新填写完整的mp3网络地址',
	
	//spacecp_spacefiles.php
	'renewing_themes_document' => '操作完成，文件主题分类更新成功了',
	'selected_documents_have_been_deleted' => '操作完成，选定的文件已经被删除了',
	'selected_documents_have_been_completely_erased' => '操作完成，选定的文件已经被彻底删除',
	'no_specific_theme_to_the_editor' => '您没有正确指定要编辑的文件主题',
	
	//spacecp_spacegoods.php
	'successfully_updated_goods_type' => '操作完成，商品分类更新成功了',
	'goods_has_been_completely_erased' => '操作完成，商品已经被彻底删除了',
	'successful_goods_devices' => '操作完成，商品上架成功了',
	'goods_have_been_deleted' => '操作完成，商品已经被删除了',
	
	//spacecp_spaceimages.php
	'photo_subject_type_successfully_updated' => '操作完成，图片主题分类更新成功了',
	'photo_theme_has_been_deleted' => '操作完成，选定的图片主题已经被删除了',
	'photo_theme_length_that_do_not_meet_the_request' => '您输入的图片主题长度不符合要求(应该为2～80个字符)',
	'please_designated_theme_operation_photo' => '请正确指定一个图片主题后再进行添加图片操作',
	'photo_theme_has_been_completely_erased' => '操作完成，选定的图片主题已经被彻底删除',
	'photo_editor_right_to_designated_theme' => '您没有正确指定要编辑的图片主题',
	'photo_has_no_choice' => '出错了，您还没有选择图片或者选择的图片不符合系统要求',
	'upload_full_space' => '您目前拥有的上传空间已满，已经没有权限继续上传附件',
	
	//spacecp_spacelinks.php
	'subject_type_success_updated_bookmark' => '操作完成，书签主题分类更新成功了',
	'has_been_selected_to_delete_the_bookmarks' => '操作完成，选定的书签已经被删除了',
	'no_specific_theme_bookmarks_to_the_editor' => '您没有正确指定要编辑的书签主题',
	
	//spacecp_spacevideos.php
	'type_success_updated_videos' => '操作完成，影音分类更新成功了',
	'has_been_selected_to_delete_the_videos' => '操作完成，选定的影音已经被删除了',
	'the_system_was_not_operational_functions' => '出错了，系统没有启用该功能',
	'add_url_not_broadcast' => '出错了，您没有添加播放URL，或者添加的播放URL均与指定的影音类型不符，请返回重新修正',
	'no_video_recording_of_any' => '出错了，系统检测不到可用视频或者录制失败，请返回重新录制，如再次出现此类问题，请联系管理员',
	'upload_another_video' => '您上一次上传影音的时候可能没有正常结束，建议等待30分钟后再重试<br><a href="spacecp.php?action=spacevideos&op=readd">您可以点击此处进行强制重新上传</a>(注意，这样会强制中断未停止的上传)',
	
	//spacecp_userspaces.php
	'modify_success' => '操作完成，修改成功了',
	'britain_and_the_figure_includes_only_crossed' => '您输入的域名只能包含英文和数字',
	'who_must_start_to_the_english_alphabetical_suffix' => '您输入的后缀名必须以英文字母开头',
	'length_of_the_domain_name_wrong' => '您输入的域名长度不符合要求',
	'domain_name_system_has_been_retained' => '您输入的域名已经被系统保留',
	'domain_names_have_been_applied' => '您输入的域名已经被其他人申请使用',
	'successfully_installed_the_domain_name' => '操作完成，域名设置成功了',
	'successfully_installed_flash_magic' => '操作完成，页面flash特效设置成功了',
	'music_box_successfully_installed' => '操作完成，页面音乐盒设置成功了',
	'successfully_installed_menu' => '操作完成，菜单设置成功了',
	'attribute_set_up_successful_space' => '操作完成，空间属性设置成功了',
	'nicknamed_requested_input' => '请输入昵称!',
	'personal_data_amendment_is_successful' => '个人资料修改成功',
	'spacemode_change_successful' => '空间模式切换成功了',
	'music_config_successful' => '音乐盒配置更新成功',
	'music_mp3_add_successful' => 'mp3文件添加完毕',
	'music_mp3_add_error' => '添加格式失败，请检查MP3地址是否符合要求',
	'music_mp3_delete_successful' => 'mp3文件列表编辑完毕',
	'no_safe_post_data_into' => '非法的POST数据提交',

	//spacecp_spacemodels.php
	'modelsitems_have_been_delete' => '模型投稿删除成功！',
	'modelsitems_have_been_delete_faild' => '操作失败！请检查数据库连接',
	'models_items_restore_success' => '模型投稿还原成功',
	
	//spacecp_usertemplates.php
	'module_successfully_updated' => '操作完成，我的模块更新成功了',
	'css_style_can_only_keep_10' => '出错了，您最多只能保持10个css样式表，请先删除之前的css，再进行另存为操作',
	'lack_of_access_to_the_designated_theme' => '无法获取指定的主题样式，请选择其他主题',
	'css_document_to_the_correct_choice_editor' => '出错了，您没有正确选择要编辑的css文件',
	'without_a_correct_choice_to_use_css_document' => '出错了，您没有正确选择要使用的css文件',
	'css_document_to_delete_the_correct_choice' => '出错了，您没有正确选择要删除的css文件',
	'diy_can_not_operate_layout_templates' => '出错了，您空间目前现在使用的不是日志模式，不能进行模板布局DIY操作',
	'background_rolling_type' => '请正确选择"整个页面"背景滚动类型',
	'fill_in_the_correct_name_of_the_mouse' => '请正确填写鼠标名称或鼠标文件地址',
	
	//function/item.func.php
	'operation_of_the_info_can_not_be_selected' => '出错了，您无法对选定的信息进行操作',
	'please_select_the_operating_information' => '请正确选择要操作的信息',
	'words_can_not_publish_the_shield' => '出错了，您输入的内容中因为含有被屏蔽的词语而不能发布',
	'you_no_authority_to_operate' => '出错了，您没有权限对指定的信息进行操作',
	'space_suject_length_error' => '您输入的标题长度不符合要求，标题长度应该为2～80个字符',
	'please_choose_classification_system' => '请为信息选择一个系统分类',
	//function/spacecp.func.php
	'user_groups_have_no_competence' => '出错了，您所在的用户组目前没有权限使用本功能',
	'the_closed_system_function' => '出错了，系统关闭该功能',

);

?>