<?php

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	Feed模板语言包

	$RCSfile: $
	$Revision: 7080 $
	$Date: 2008-03-19 13:09:21$
*/

if(!defined('IN_SUPESITE')) exit('Access Denied');

$flang = array
(
	'feed_link_title' =>			'<b>{actor} 添加了新书签</b>',
	'feed_link_message' =>			'<b>{subject}</b><br />网址：{url}<br />{message}',

	'feed_reply_title' =>			'{actor} 评论了 {author} 的{type} {subject}',

	'feed_guestbook_title' =>		'{actor} 在 {host} 的留言板留言了',

	'feed_model_title' =>			'<b> {actor} 在 {modelname} 发布了新信息</b>',
	'feed_model_message' =>			'<b>{subject}</b><br />{message}',
	'feed_model_comment_title' =>	'{actor} 在 {modelname} 评论了 {author} 的信息 {modelpost}',

	'feed_file_title' =>			'<b>{actor} 添加了新文件</b>',
	'feed_file_message' =>			'<b>{subject}</b><br />{message}',

	'feed_blog_title' =>			'<b>{actor} 发布了新日志</b>',
	'feed_blog_message' =>			'<b>{subject}</b><br />{message}',

	'feed_image_title' =>			'<b>{actor} 创建了新相册</b>',
	'feed_image_message' =>			'<b>{subject}</b><br />共 {num} 张图片<br />',

	'feed_good_title' =>			'<b>{actor} 发布了新商品</b>',
	'feed_good_message' =>			'<b>{subject}</b><br />{message}<br />售价 {price} 元',

	'feed_video_title' =>			'<b>{actor} 上传了新视频</b>',
	'feed_video_message'=>			'{subject}<br />',

	'feed_player_title' =>			'<b>{actor} 添加了新网络影音</b>',
	'feed_player_message'=>			'<b>{subject}</b><br />{message}',

	'feed_online_title' =>			'<b>{actor} 在线录制了新视频</b>',
	'feed_online_message'=>			'<b>{subject}</b><br />{message}',
);


?>