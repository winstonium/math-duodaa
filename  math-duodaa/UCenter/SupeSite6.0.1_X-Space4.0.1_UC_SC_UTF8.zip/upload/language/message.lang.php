<?

/*
	[SupeSite/X-Space] (C)2001-2006 Comsenz Inc.
	前台跳转窗口语言包

	$RCSfile: message.lang.php,v $
	$Revision: 1.41 $
	$Date: 2007/05/10 15:06:34 $
*/

if(!defined('IN_SUPESITE')) {
	exit('Access Denied');
}

$mlang = array (

	'title' => '提示消息',
	'back' => '返回上一页',
	'index' => '进入首页',
	'confirm' => '确定',
	'close' => '关闭',
	
	'site_close' => '站点临时关闭，请稍后再访问',
	'not_found' => '出错了，您请求的页面没有找到',
	'not_found_msg' => '出错了，您要查看的页面内容信息没有找到',
	'not_view' => '出错了，您要查看的信息没有公开发布',
	'not_friend' => '出错了，您要查看的信息只允许作者的好友查看',
	'space_register' => '您现在还没有升级个人空间，现在引导您进入空间升级页面',
	'space_lock' => '出错了，您所查看的空间已经被锁定，现在跳转到站点首页',
	'no_permission' => '出错了，您现在没有权限进行本操作',
	'seccode_error' => '出错了，您输入的验证码不正确，请确认',
	'no_login' => '出错了，请您先登录系统后再进行本操作',
	'system_error' => '出错了，您的操作不正确，请检查您的操作',
	'message_length_error' => '出错了，您输入的内容长度不符合要求，请返回检查',
	'no_reply' => '出错了，您没有权限对该主题进行评论，请返回',
	'rates_repeat' => '出错了，您已经对该主题评过分了，不能重复评分，请返回检查',
	'succeed' => '操作完成，您进行的操作成功完成了',
	'login_error' => '出错了，您输入的账号信息不正确，请尝试重新登录',
	'login_succeed' => '操作完成，您已经成功登录站点系统了',
	'logout_succeed' => '操作完成，您已经成功退出站点系统了',
	'no_self' => '出错了，您本人不能进行该操作',
	'no_snaptext' => '出错了，该站点没有快照',
	'no_auction' => '出错了，现在无法进行出价交易，可能已经停止拍卖或者暂时未开始拍卖',
	'space_no_popedom' => '出错了，您现在还没有权限升级自己的个人空间',
	'poll_repeat' => '出错了，您已经投过票了，不能重复投票',
	'no_votekey' => '出错了，您没有选择要投票的选项',
	'user_exists_error' => '用户名存在重名的问题，请先去论坛登陆改名',
	
	'the_system_does_not_allow_searches'=>'您未登录，系统不允许搜索',
	'inquiries_about_the_short_time_interval'=>'出错了，您两次查询的时间间隔太短，请稍后再继续搜索',
	'not_find_relevant_data'=>'没有找到相关数据，请更换查询关键字试试',
	'search_types_of_incorrect_information'=>'出错了，搜索信息类型不正确',
	'at_least_one_of_the_conditions_for_inquiry'=>'出错了，请至少选择一个条件进行查询',
	'keyword_import_inquiry'=>'出错了，请输入您要查询的关键字',
	'kwyword_import_short' => '出错了,输入的关键字长度需大于2个字符',

	
	'bookmark_has_successfully'=>'操作完成，您指定的书签已经成功复制了',
	
	'after_the_first_entry_management'=>'请先登录后再进行个人空间管理操作',
	'no_personal_space'=>'您还没有升级个人空间，现在引导您进入空间升级页面',
	'personal_space_lock'=>'您的个人空间已经被管理员锁定，如果有疑问，请联系管理员',
	'no_authority_to_open_personal_space'=>'抱歉，您所在的用户组目前没有权限开启个人空间',

	'the_author_can_be_edited'=>'出错了，只有作者本人才可以进行编辑操作',

	'connection_failure'=>'出错了，与服务器连接失败，请稍后重试',
	'message_group_ok' => '操作完成，推送到圈子成功完成了',
	'message_null_group' => '出错了，您未登陆或本信息未公开，所以无法推荐到任何圈子',
	'message_exist_group' => '出错了，您的推荐失败,已经有人推荐过本信息到该圈子',
	'guestbooks_reply_error' => '出错了，您未登陆或者不是空间主人，所以无法使用回复功能',
	'guestbooks_reply_succeed' => '操作完成，对留言回复成功',
	'guestbooks_reply_failing' => '出错了，您未登陆或者不是空间主人，<br>或者您请求的参数有误，所以无法使用回复功能',
	'check_grouppwd_ok' => '操作完成，密码验证通过',
	'check_grouppwd_error' => '出错了，您输入的密码不正确',
	//admincp.php
	'admincp_no_popedom' => '您没有权限进行本操作，请返回',
	'admincp_safety_install' => '安全问题:您没有删除安装文件 install.php ，请删除安装文件后再进入后台操作。',
	'admincp_login' => '您没有登录站内系统，请先登录',
	'background_logging_in_success' => '操作完成，管理后台登录成功了',
	'background_logging_in_failure' => '出错了，登录失败，请检查您的管理密码',
	'exists_install_file' => '请将根目录下的install.php、installuc.php删除后方可登陆后台',

	//batch.comment.php
	'words_can_not_publish_the_shield' => '出错了，您输入的内容中因为含有被屏蔽的词语而不能发布',
	'comment_succeed' => '完成，对指定的信息评论成功了',
	'comment_too_much' => '您评论太快了，稍等半分钟再试试',

	//batch.common.php
	'no_authority_for_this_operation'=>'出错了，您没有权限进行本操作',
	'please_delete_the_successful_closure' => '操作完成，删除操作完成，请关闭本页面',
	'successfully_recovered' => '操作完成，回收成功了',
	'successfully_updated_classification_system' => '操作完成，更新系统分类成功了',
	'information_examine_successful' => '操作完成，对信息进行等级审核成功了',
	'not_lock_their_own_space' => '出错了，您不能锁定自己的空间',
	'leave_your_correct_email_link' => '请正确留下您的联系email，便于卖家跟你联系',
	'mail_has_been_sent_to_the_seller' => '已经发送邮件到卖家了，请注意查收卖家的回复邮件',
	'no_choice_but_to_delete_comments' => '出错了，您没有选择要删除的评论',
	'commenting_on_the_success_of_the_deletion' => '恭喜您，成功删除指定的评论',
	'commenting_on_the_successful_operation_against' => '恭喜您，禁止评论操作成功',
	'commenting_on_the_failure_to_prohibit_operation' => '出错了，参数错误禁止评论操作失败',
	'alipay_error' => '出错了，通过支付宝购买商品失败，请尝试其他方式',
	'one_can_only_push_10_below_the_group' => '一次只能推送10个以下的圈子',
	
	
	//mygroup.php
	'group_being_audited' => '圈子未开通，正在审核中',
	'not_allowed_to_recommend_group' => '出错了,本圈不允许推荐外部信息',
	'open_to_restrictions' => '出错了，此圈子仅对圈内人员开放<br>您未加入本圈或未审核通过……',
	
	//batch.manage.php
	'please_specify_the_information_management' => '请指定要管理的信息',
	'conducting_management_operations_posted_first' => '出错了，请您先登录再进行管理操作',
	'management_information_has_been_deleted' => '出错了，你要管理的信息已经被删除了',
	'no_normal_management_operation' => '出错了，您没有进行正常的管理操作',
	'information_not_released' => '出错了，你要管理的信息还没有正常发布',
	'the_only_information_on_their_operations' => '出错了，您只能对自己发布的信息进行管理操作',
	'the_management_of_the_space_does_not_exist' => '出错了，你要管理的空间不存在',
	'info_has_been_completely_erased_designated' => '恭喜，指定的信息已经彻底删除',
	'info_was_placed_in_the_collection_points' => '恭喜，指定的信息已经被放入回收站',
	'info_updated_type_system_completed' => '恭喜，更新信息的系统分类完成了',
	'info_completion_of_the_examination_grades' => '恭喜，对指定信息的审核等级完成了',
	'info_has_been_designated_to_delete_comments' => '恭喜，指定的评论信息已经被删除',
	'space_has_been_set_up_for_the_space_star' => '恭喜，指定的空间已经被设置为空间之星',
	'star_has_been_canceled_designated_space' => '恭喜，指定的空间之星已经被取消了',
	'space_has_been_designated_lock' => '恭喜，指定的空间已经被锁定了',
	're_opening_of_the_designated_space_success' => '恭喜，指定的空间重新开放成功了',
	
	'page_limit' => '出错了，您要查看页数太大了，请选择其他条件查看列表',

	//blogpost.php
	'itemid_not_exists' => '导入的日志不存在',
	'resource_have_imported_into_forum' => '不能重复导入',
	'resource_is_not_of_you' => '该日志不是您所发布，您没有权力操作他人的资源。请返回。',
	'forum_not_exists' => '您所选择导入的版块不存在',
	'imported_succeed' => '你所选择的日志已经成功导入论坛！',
	'thread_not_exists' => '您所评论的帖子不存在',
	'forum_not_import' => '您所选择的版块不允许导入',
	
	//spacecp_usertemplates.php
	'diy_successful_space_preservation' => '操作完成，我的空间DIY保存成功了',
	
	//space_onspace.inc.php
	'change_theme' => '正在更换皮肤中，请稍等...',
	
	//register.php
	'space_no_open' => '出错了，本站点个人空间升级功能尚未开放',
	
	'start_listcount_error' => '出错了，您要查看页数不存在',
	'not_found_tag' => '暂时没有找到指定的tag信息',
	
	//admin_spaces.php
	'change_user' => '操作完成，登录空间管理平台成功了',
	'space_management_is_not_able_to' => '对不起，指定的用户空间暂时无法管理',
	
	//batch.epitome.php,batch.thumb.php
	'parameter_chenged' => '禁止篡改参数',
	'GD_lib_no_load' => '没有加载GD库。',
	'image_little' => '图片太小，无法裁切',
	
	//batch.modeldownload.php
	'visit_the_channel_does_not_exist' => '您访问的频道不存在,请返回首页.',
	'downloading_short_time_interval' => '出错了，您下载的时间间隔太短,请稍后再继续下载.',
	
	//modelpost.php
	'this_channel_does_not_allow_contributions' => '此频道不允许投稿.',
	'parameter_error' => '出错了，参数错误,请返回',
	'space_suject_length_error' => '您输入的标题长度不符合要求(2~80个字符)',
	'admin_func_catid_error' => '您没有正确指定分类，请返回确认',
	'document_types_can_only_upload_pictures' => '标题图片只能上传图片类型文件(.jpg .jpeg .gif .png).',
	'online_contributions_success' => '在线投稿成功.',
	'writing_success_online_please_wait_for_audit' => '提交成功,请等待审核通过.',
	
	
	
	

);

?>